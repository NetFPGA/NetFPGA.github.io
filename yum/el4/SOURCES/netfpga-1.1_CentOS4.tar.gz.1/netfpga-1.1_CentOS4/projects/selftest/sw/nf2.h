/* ****************************************************************************
 * $Id: nf2.h 2033 2007-07-25 03:28:36Z jnaous $
 *
 * Module: nf2.h
 * Project: NetFPGA 2 Linux Kernel Driver
 * Description: Header file for kernel driver
 *
 * Change history:
 *
 */

#ifndef _NF2_H
#define _NF2_H	1

#define NF2_DEV_NAME	"nf2"

/* Include for socket IOCTLs */
#include <linux/sockios.h>

/* Maximum number of interfaces */
#ifndef MAX_IFACE
#define MAX_IFACE	4
#endif

/* 
 * Register names and locations.
 *
 * Note that these names are not necessarily identical to 
 * those in NF2/hw/common/src/defines
 */

#define UNET_REG_BASE			0x400000

#define UNET_ID				(UNET_REG_BASE + 0x000)
#define UNET_RESET			(UNET_REG_BASE + 0x004)
#define UNET_MAC_RESET			(UNET_REG_BASE + 0x008)
#define UNET_MAC_ENABLE			(UNET_REG_BASE + 0x00c)
#define UNET_MAC_CONFIG			(UNET_REG_BASE + 0x010)
#define UNET_SCRATCH32			(UNET_REG_BASE + 0x014)

#define UNET_CPUTXFIFO_STATUS		(UNET_REG_BASE + 0x020)
#define UNET_CPUTXFIFO_DATA		(UNET_REG_BASE + 0x024)
#define UNET_CPUTXFIFO_LENGTH		(UNET_REG_BASE + 0x028)

#define UNET_CPURXFIFO_STATUS		(UNET_REG_BASE + 0x030)
#define UNET_CPURXFIFO_DATA		(UNET_REG_BASE + 0x034)
#define UNET_CPURXFIFO_LENGTH		(UNET_REG_BASE + 0x038)

#define UNET_MAC_ADDR_HI_PORT_1		(UNET_REG_BASE + 0x040)
#define UNET_MAC_ADDR_LO_PORT_1		(UNET_REG_BASE + 0x044)
#define UNET_MAC_ADDR_HI_PORT_2		(UNET_REG_BASE + 0x048)
#define UNET_MAC_ADDR_LO_PORT_2		(UNET_REG_BASE + 0x04c)
#define UNET_MAC_ADDR_HI_PORT_3		(UNET_REG_BASE + 0x050)
#define UNET_MAC_ADDR_LO_PORT_3		(UNET_REG_BASE + 0x054)
#define UNET_MAC_ADDR_HI_PORT_4		(UNET_REG_BASE + 0x058)
#define UNET_MAC_ADDR_LO_PORT_4		(UNET_REG_BASE + 0x05c)

#define UNET_USER_ENABLE		(UNET_REG_BASE + 0x070)
#define UNET_USER_RESET			(UNET_REG_BASE + 0x074)

#define UNET_IP_ADDR_PORT_1		(UNET_REG_BASE + 0x080)
#define UNET_IP_ADDR_PORT_2		(UNET_REG_BASE + 0x084)
#define UNET_IP_ADDR_PORT_3		(UNET_REG_BASE + 0x088)
#define UNET_IP_ADDR_PORT_4		(UNET_REG_BASE + 0x08c)

#define UNET_OQ_INITIALIZE		(UNET_REG_BASE + 0x090)

#define UNET_OQ_Q1_LOW_ADDR		(UNET_REG_BASE + 0x0a0)
#define UNET_OQ_Q1_HIGH_ADDR		(UNET_REG_BASE + 0x0a4)
#define UNET_OQ_Q2_LOW_ADDR		(UNET_REG_BASE + 0x0a8)
#define UNET_OQ_Q2_HIGH_ADDR		(UNET_REG_BASE + 0x0ac)
#define UNET_OQ_Q3_LOW_ADDR		(UNET_REG_BASE + 0x0b0)
#define UNET_OQ_Q3_HIGH_ADDR		(UNET_REG_BASE + 0x0b4)
#define UNET_OQ_Q4_LOW_ADDR		(UNET_REG_BASE + 0x0b8)
#define UNET_OQ_Q4_HIGH_ADDR		(UNET_REG_BASE + 0x0bc)


#define UNET_OQ_PKTS_LOST_CPU		(UNET_REG_BASE + 0x0c0)
#define UNET_OQ_PKTS_LOST_PORT_1	(UNET_REG_BASE + 0x0c4)
#define UNET_OQ_PKTS_LOST_PORT_2	(UNET_REG_BASE + 0x0c8)
#define UNET_OQ_PKTS_LOST_PORT_3	(UNET_REG_BASE + 0x0cc)
#define UNET_OQ_PKTS_LOST_PORT_4	(UNET_REG_BASE + 0x100)

#define UNET_OQ_PKTS_STORED_CPU		(UNET_REG_BASE + 0x0d0)
#define UNET_OQ_PKTS_STORED_PORT_1	(UNET_REG_BASE + 0x0d4)
#define UNET_OQ_PKTS_STORED_PORT_2	(UNET_REG_BASE + 0x0d8)
#define UNET_OQ_PKTS_STORED_PORT_3	(UNET_REG_BASE + 0x0dc)
#define UNET_OQ_PKTS_STORED_PORT_4	(UNET_REG_BASE + 0x104)

#define UNET_OQ_PKTS_REMOVED_CPU	(UNET_REG_BASE + 0x0e0)
#define UNET_OQ_PKTS_REMOVED_PORT_1	(UNET_REG_BASE + 0x0e4)
#define UNET_OQ_PKTS_REMOVED_PORT_2	(UNET_REG_BASE + 0x0e8)
#define UNET_OQ_PKTS_REMOVED_PORT_3	(UNET_REG_BASE + 0x0ec)
#define UNET_OQ_PKTS_REMOVED_PORT_4	(UNET_REG_BASE + 0x108)

#define UNET_OQ_PKTS_LOST_CPU		(UNET_REG_BASE + 0x0c0)
#define UNET_OQ_PKTS_LOST_PORT_1	(UNET_REG_BASE + 0x0c4)
#define UNET_OQ_PKTS_LOST_PORT_2	(UNET_REG_BASE + 0x0c8)
#define UNET_OQ_PKTS_LOST_PORT_3	(UNET_REG_BASE + 0x0cc)
#define UNET_OQ_PKTS_LOST_PORT_4	(UNET_REG_BASE + 0x100)

#define UNET_RTT_PORT_1			(UNET_REG_BASE + 0x110)
#define UNET_RTT_PORT_2			(UNET_REG_BASE + 0x114)
#define UNET_RTT_PORT_3			(UNET_REG_BASE + 0x118)
#define UNET_RTT_PORT_4			(UNET_REG_BASE + 0x11c)

#define UNET_RATE_PORT_1		(UNET_REG_BASE + 0x120)
#define UNET_RATE_PORT_2		(UNET_REG_BASE + 0x124)
#define UNET_RATE_PORT_3		(UNET_REG_BASE + 0x128)
#define UNET_RATE_PORT_4		(UNET_REG_BASE + 0x12c)

// SRAM test register base address
#define NF2_SRAM_TEST_REG_BASE         (UNET_REG_BASE + 0x0)

// SRAM test register addresses
#define NF2_SRAM_TEST_ERR_CNT           (NF2_SRAM_TEST_REG_BASE + 0x200)
#define NF2_SRAM_TEST_ITER_CNT          (NF2_SRAM_TEST_REG_BASE + 0x204)
#define NF2_SRAM_TEST_BAD_CNT           (NF2_SRAM_TEST_REG_BASE + 0x208)
#define NF2_SRAM_TEST_GOOD_CNT          (NF2_SRAM_TEST_REG_BASE + 0x20c)
#define NF2_SRAM_TEST_STATUS            (NF2_SRAM_TEST_REG_BASE + 0x210) 
#define NF2_SRAM_TEST_EN                (NF2_SRAM_TEST_REG_BASE + 0x220)
#define NF2_SRAM_TEST_CTRL              (NF2_SRAM_TEST_REG_BASE + 0x224)
#define NF2_SRAM_TEST_RAND_SEED_HI      (NF2_SRAM_TEST_REG_BASE + 0x228)
#define NF2_SRAM_TEST_RAND_SEED_LO      (NF2_SRAM_TEST_REG_BASE + 0x22c)


// Register test block addresses
#define NF2_REG_TEST_BASE		(UNET_REG_BASE + 0x400)

// PHY test register base address
#define NF2_PHY_TEST_REG_BASE           (UNET_REG_BASE + 0x800)

#define NF2_PHY_TEST_STATUS             (NF2_PHY_TEST_REG_BASE + 0x000)
#define NF2_PHY_TEST_CTRL               (NF2_PHY_TEST_REG_BASE + 0x004)
#define NF2_PHY_TEST_SIZE               (NF2_PHY_TEST_REG_BASE + 0x008)
#define NF2_PHY_TEST_PATTERN            (NF2_PHY_TEST_REG_BASE + 0x00c)
#define NF2_PHY_TEST_INIT_SEQ_NO        (NF2_PHY_TEST_REG_BASE + 0x010)

#define NF2_PHY_TEST_PORT_OFFSET 	0x80

#define NF2_PHY_TEST_TX_STATUS          (NF2_PHY_TEST_REG_BASE + 0x200)
#define NF2_PHY_TEST_TX_ITER            (NF2_PHY_TEST_REG_BASE + 0x204)
#define NF2_PHY_TEST_TX_PKTS            (NF2_PHY_TEST_REG_BASE + 0x208)
#define NF2_PHY_TEST_TX_CURR_SEQ_NO     (NF2_PHY_TEST_REG_BASE + 0x20c)
#define NF2_PHY_TEST_TX_RAND_SEED       (NF2_PHY_TEST_REG_BASE + 0x210)

#define NF2_PHY_TEST_RX_STATUS          (NF2_PHY_TEST_REG_BASE + 0x220)
#define NF2_PHY_TEST_RX_GOOD_PKTS       (NF2_PHY_TEST_REG_BASE + 0x224)
#define NF2_PHY_TEST_RX_BAD_PKTS        (NF2_PHY_TEST_REG_BASE + 0x228)
#define NF2_PHY_TEST_RX_SEQ_NO          (NF2_PHY_TEST_REG_BASE + 0x22a)
#define NF2_PHY_TEST_RX_CTRL            (NF2_PHY_TEST_REG_BASE + 0x230)

#define NF2_PHY_TEST_RX_LOG_STATUS      (NF2_PHY_TEST_REG_BASE + 0x240)
#define NF2_PHY_TEST_RX_LOG_EXP_DATA    (NF2_PHY_TEST_REG_BASE + 0x244)
#define NF2_PHY_TEST_RX_LOG_RX_DATA     (NF2_PHY_TEST_REG_BASE + 0x248)
#define NF2_PHY_TEST_RX_LOG_CTRL        (NF2_PHY_TEST_REG_BASE + 0x24c)


// DRAM test register base address
#define NF2_DRAM_TEST_REG_BASE          (UNET_REG_BASE + 0xc00)

// Log offset -- difference between each block of log registers
#define NF2_DRAM_TEST_LOG_OFFSET	0x20

// DRAM test register addresses
#define NF2_DRAM_TEST_LOG_ADDR          (NF2_DRAM_TEST_REG_BASE + 0x000)
#define NF2_DRAM_TEST_LOG_EXP_DATA_HI   (NF2_DRAM_TEST_REG_BASE + 0x004)
#define NF2_DRAM_TEST_LOG_EXP_DATA_LO   (NF2_DRAM_TEST_REG_BASE + 0x008)
#define NF2_DRAM_TEST_LOG_RD_DATA_HI    (NF2_DRAM_TEST_REG_BASE + 0x00c)
#define NF2_DRAM_TEST_LOG_RD_DATA_LO    (NF2_DRAM_TEST_REG_BASE + 0x010)

#define NF2_DRAM_TEST_ERR_CNT           (NF2_DRAM_TEST_REG_BASE + 0x200)
#define NF2_DRAM_TEST_ITER_CNT          (NF2_DRAM_TEST_REG_BASE + 0x204)
#define NF2_DRAM_TEST_BAD_CNT           (NF2_DRAM_TEST_REG_BASE + 0x208)
#define NF2_DRAM_TEST_GOOD_CNT          (NF2_DRAM_TEST_REG_BASE + 0x20c)
#define NF2_DRAM_TEST_STATUS            (NF2_DRAM_TEST_REG_BASE + 0x210) 
#define NF2_DRAM_TEST_EN                (NF2_DRAM_TEST_REG_BASE + 0x220)
#define NF2_DRAM_TEST_CTRL              (NF2_DRAM_TEST_REG_BASE + 0x224)
#define NF2_DRAM_TEST_RAND_SEED         (NF2_DRAM_TEST_REG_BASE + 0x228)

// Register test base address
#define NF2_REG_TEST_BASE          (UNET_REG_BASE + 0x400)

// SERIAL test register base address
#define NF2_SERIAL_TEST_REG_BASE           (UNET_REG_BASE + 0x1c00)

#define NF2_REG_REF_TEST_BASE          (UNET_REG_BASE + 0x1000)

// MDIO register base
#define NF2_MDIO_REG_BASE          	(UNET_REG_BASE + 0x1800)
#define NF2_MDIO_PHY_OFFSET		(0x20 << 2)

// Clock register base
#define NF2_CLK_REG_BASE          	(UNET_REG_BASE + 0x2000)

#define NF2_CLK_TICKS          		(NF2_CLK_REG_BASE + 0x000)


// DRAM base
#define NF2_DRAM_BASE			0x4000000

#define NF2_SERIAL_CTRL_0                  (NF2_SERIAL_TEST_REG_BASE + 0x000)
#define NF2_SERIAL_STATUS_0                (NF2_SERIAL_TEST_REG_BASE + 0x004)
#define NF2_SERIAL_NUM_FRAMES_SENT_0_LO    (NF2_SERIAL_TEST_REG_BASE + 0x008)
#define NF2_SERIAL_NUM_FRAMES_RCVD_0_LO    (NF2_SERIAL_TEST_REG_BASE + 0x00c)
#define NF2_SERIAL_NUM_FRAMES_SENT_0_HI    (NF2_SERIAL_TEST_REG_BASE + 0x010)
#define NF2_SERIAL_NUM_FRAMES_RCVD_0_HI    (NF2_SERIAL_TEST_REG_BASE + 0x014)
#define NF2_SERIAL_CTRL_1                  (NF2_SERIAL_TEST_REG_BASE + 0x018)
#define NF2_SERIAL_STATUS_1                (NF2_SERIAL_TEST_REG_BASE + 0x01c)
#define NF2_SERIAL_NUM_FRAMES_SENT_1_LO    (NF2_SERIAL_TEST_REG_BASE + 0x020)
#define NF2_SERIAL_NUM_FRAMES_RCVD_1_LO    (NF2_SERIAL_TEST_REG_BASE + 0x024)
#define NF2_SERIAL_NUM_FRAMES_SENT_1_HI    (NF2_SERIAL_TEST_REG_BASE + 0x028)
#define NF2_SERIAL_NUM_FRAMES_RCVD_1_HI    (NF2_SERIAL_TEST_REG_BASE + 0x02c)
#define NF2_SERIAL_TEST_CTRL               (NF2_SERIAL_TEST_REG_BASE + 0x030)
#define NF2_SERIAL_TEST_STAT               (NF2_SERIAL_TEST_REG_BASE + 0x034)

// serial_ctrl bits
#define SERIAL_USR_RESET_BIT_NUM           0
// serial stat bits
#define SERIAL_LANE_UP_BIT_NUM             0
#define SERIAL_CHANNEL_UP_BIT_NUM          1
#define SERIAL_HARD_ERROR_BIT_NUM          2
#define SERIAL_SOFT_ERROR_BIT_NUM          3
#define SERIAL_FRAME_ERROR_BIT_NUM         4
#define SERIAL_ERROR_COUNT_BIT_NUM         8
#define SERIAL_ERROR_COUNT_MASK            0x000000ff
// serial test ctrl bits
#define SERIAL_TEST_RESTART_BIT_NUM        0
#define SERIAL_TEST_NONSTOP_BIT_NUM        1
// serial test stat bits
#define SERIAL_TEST_SUCCESSFUL_BIT_NUM     0
#define SERIAL_TEST_DONE_BIT_NUM           1
#define SERIAL_TEST_RUNNING_BIT_NUM        2
#define SERIAL_TEST_COUNT_BIT_NUM          3

/* CPCI registers */
#define CPCI_REG_ID			0x000
#define CPCI_REG_BOARD_ID		0x004
#define CPCI_REG_CTRL			0x008
#define CPCI_REG_RESET			0x00c
#define CPCI_REG_ERROR			0x010
#define CPCI_REG_DUMMY			0x020
#define CPCI_REG_INTERRUPT_MASK		0x040
#define CPCI_REG_INTERRUPT_STATUS	0x044
#define CPCI_NF2_CLK_SEL		0x050
#define CPCI_REG_PROG_DATA		0x100
#define CPCI_REG_PROG_STATUS		0x104
#define CPCI_REG_PROG_CTRL		0x108
#define CPCI_REG_DMA_I_ADDR		0x140
#define CPCI_REG_DMA_E_ADDR		0x144
#define CPCI_REG_DMA_I_SIZE		0x148
#define CPCI_REG_DMA_E_SIZE		0x14c
#define CPCI_REG_DMA_I_CTRL		0x150
#define CPCI_REG_DMA_E_CTRL		0x154
#define CPCI_REG_DMA_MAX_XFER_TIME	0x180
#define CPCI_REG_DMA_MAX_RETRIES	0x184
#define CPCI_REG_CNET_MAX_XFER_TIME	0x188
#define CPCI_REG_DMA_I_PKT_CNT		0x400
#define CPCI_REG_DMA_E_PKT_CNT		0x404
#define CPCI_REG_CPCI_REG_RD_CNT	0x408
#define CPCI_REG_CPCI_REG_WR_CNT	0x40c
#define CPCI_REG_CNET_REG_RD_CNT	0x410
#define CPCI_REG_CNET_REG_WR_CNT	0x414

/* Base address for CNET registers */
#define PHY_REG_BASE			0x600000

#define PHY_REG_CMD			(PHY_REG_BASE)
#define PHY_REG_STATUS			(PHY_REG_BASE)

/* Phy register masks */
#define PHY_RD_WR			0x80000000
#define PHY_PHY				0x03000000
#define PHY_ADDR			0x001F0000
#define PHY_DATA			0x0000FFFF

#define PHY_DONE			0x80000000
#define PHY_DONE_CNT			0x001F0000


#define GET_VERSION(x)			(x & 0xFFFF)
#define GET_DEVICE(x)			((x >> 16) & 0xFFFF)

#define GET_PORT(x)			((x >> 16) & 0xFFFF)
#define GET_LENGTH(x)			(x & 0xFFFF)

#define GET_NEARLY_FULL(x)		(x >> 31)
#define GET_FULL(x)			((x >> 16) & 0x1)
#define GET_EMPTY(x)			((x >> 8) & 0x1)
#define GET_WAITING(x)			(x & 0x1)

#define GET_SEND(x)			((x >> 1) & 0x1)
#define GET_RECEIVE(x)			(x & 0x1)

// SRAM cpu direct access base address 
#define NF2_SRAM_1_BASE                   0xC00000
#define NF2_SRAM_2_BASE                   0xE00000

// Normal function register base address 
#define NF2_REG_FUNC_BASE                (UNET_REG_BASE + 0x1400) 

// individual registers in normal function register block 
#define NF2_REG_FUNC_SRAM_1_MSB_RD        (NF2_REG_FUNC_BASE + 0x0)
#define NF2_REG_FUNC_SRAM_1_MSB_WR        (NF2_REG_FUNC_BASE + 0x4)
#define NF2_REG_FUNC_SRAM_2_MSB_RD        (NF2_REG_FUNC_BASE + 0x8)
#define NF2_REG_FUNC_SRAM_2_MSB_WR        (NF2_REG_FUNC_BASE + 0xC)

/* 
 * Structure for transferring register data via an IOCTL
 */
struct nf2reg {
	unsigned int	reg;
	unsigned int	val;
};

#endif
