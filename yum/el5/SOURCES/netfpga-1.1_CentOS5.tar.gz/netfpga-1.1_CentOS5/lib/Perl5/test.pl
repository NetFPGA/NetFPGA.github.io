#!/usr/bin/perl -w

use strict;
use NF2::TestLib;
use NF2::PacketLib;

my @interfaces = ("nf2c0", "nf2c1", "nf2c2", "nf2c3", "eth1", "eth2");
nftest_init(\@ARGV,\@interfaces,);

my $routerMAC0 = "00:ca:fe:00:00:01";
my $routerMAC1 = "00:ca:fe:00:00:02";
my $routerMAC2 = "00:ca:fe:00:00:03";
my $routerMAC3 = "00:ca:fe:00:00:04";

my $routerIP0 = "192.168.0.40";
my $routerIP1 = "192.168.1.40";
my $routerIP2 = "192.168.2.40";
my $routerIP3 = "192.168.3.40";

my $ALLSPFRouters = "224.0.0.5";

######### You should skip this section for tests with router SCONE
# Write the mac and IP addresses doesn't matter which of the nf2c0..3 you write to.
nftest_add_dst_ip_filter_entry ('nf2c0', 0, $routerIP0);
nftest_add_dst_ip_filter_entry ('nf2c0', 1, $routerIP1);
nftest_add_dst_ip_filter_entry ('nf2c0', 2, $routerIP2);
nftest_add_dst_ip_filter_entry ('nf2c0', 3, $routerIP3);
nftest_add_dst_ip_filter_entry ('nf2c0', 4, $ALLSPFRouters);

# For these it does matter which interface you write to
nftest_set_router_MAC ('nf2c0', $routerMAC0);
nftest_set_router_MAC ('nf2c1', $routerMAC1);
nftest_set_router_MAC ('nf2c2', $routerMAC2);
nftest_set_router_MAC ('nf2c3', $routerMAC3);
#########

# Put the two ports in loopback mode. Pkts going out will come back in on
# the same port
nftest_phy_loopback('nf2c2');
nftest_phy_loopback('nf2c3');

nftest_regread_expect('nf2c0', MDIO_0_CONTROL_REG(), 0x1140);
nftest_regread_expect('nf2c0', MDIO_1_CONTROL_REG(), 0x1140);
nftest_regread_expect('nf2c0', MDIO_2_CONTROL_REG(), 0x5140);
nftest_regread_expect('nf2c0', MDIO_3_CONTROL_REG(), 0x5140);

# set parameters
my $DA = $routerMAC0;
my $SA = "aa:bb:cc:dd:ee:ff";
my $TTL = 64;
my $DST_IP = "192.168.1.1";
my $SRC_IP = "192.168.0.1";;
my $len = 100;
my $nextHopMAC = "dd:55:dd:66:dd:77";

# create mac header
my $MAC_hdr = NF2::Ethernet_hdr->new(DA => $DA,
				     SA => $SA,
				     Ethertype => 0x800
				    );

#create IP header
my $IP_hdr = NF2::IP_hdr->new(ttl => $TTL,
			      src_ip => $SRC_IP,
			      dst_ip => $DST_IP
			     );

$IP_hdr->checksum(0);  # make sure its zero before we calculate it.
$IP_hdr->checksum($IP_hdr->calc_checksum);

# create packet filling.... (IP PDU)
my $PDU = NF2::PDU->new($len - $MAC_hdr->length_in_bytes() - $IP_hdr->length_in_bytes() );
my $start_val = $MAC_hdr->length_in_bytes() + $IP_hdr->length_in_bytes()+1;
my @data = ($start_val..$len);
for (@data) {$_ %= 100}
$PDU->set_bytes(@data);

# get packed packet string
my $sent_pkt = $MAC_hdr->packed . $IP_hdr->packed . $PDU->packed;

# create the expected packet
$MAC_hdr->DA($nextHopMAC);
$MAC_hdr->SA($routerMAC1);

$IP_hdr->ttl($TTL-1);
$IP_hdr->checksum(0);  # make sure its zero before we calculate it.
$IP_hdr->checksum($IP_hdr->calc_checksum);

my $expected_pkt = $MAC_hdr->packed . $IP_hdr->packed . $PDU->packed;

# add an entry in the routing table:
my $index = 0;
my $subnetIP = "192.168.1.0";
my $subnetMask = "255.255.255.0";
my $nextHopIP = "192.168.1.54";
my $outPort = 0x4; # output on MAC1

nftest_add_LPM_table_entry ('nf2c0',
			    $index,
			    $subnetIP,
			    $subnetMask,
			    $nextHopIP,
			    $outPort);

# add an entry in the ARP table
nftest_add_ARP_table_entry('nf2c0',
			   $index,
			   $nextHopIP,
			   $nextHopMAC);

# send packet out of eth1->nf2c0 should be forwarded out from nf2c1->eth2
nftest_send('eth1', $sent_pkt);
nftest_expect('eth2', $expected_pkt);

# create a filter for OSPF packets
# 1) don't match on the MAC header
$MAC_hdr->DA("00:00:00:00:00:00");
$MAC_hdr->SA("00:00:00:00:00:00");
$MAC_hdr->Ethertype(0x800);

my $MAC_mask = NF2::Ethernet_hdr->new(DA => "00:00:00:00:00:00",
				      SA => "00:00:00:00:00:00",
				      Ethertype => 0xffff
				     );
# 2) set a value and mask IP hdrs to match. The mask has to have ones in all the bit positions
#    we want to match.
my $IP_match = NF2::IP_hdr->new(proto => 89, # match on protocol = 89
				dst_ip => $ALLSPFRouters, # match on dst ip addr = $ALLSPFRouters
			       );

my $IP_mask  = NF2::IP_hdr->new(version => 0,  # don't match on version (on by dflt)
				ip_hdr_len => 0, # don't match on hdr len (on by dflt)
				dgram_len => 0, # don't match on datagram len (on by dflt)
				proto => 0xff,  # match on all 8 bits of the protocol
				dst_ip => "255.255.255.255", # match on ip addr
			       );

# add rule to all interfaces we want to ignore on
nftest_ignore("nf2c0",
	      ($MAC_mask->packed . $IP_mask->packed),
	      ($MAC_hdr->packed  . $IP_match->packed));

nftest_ignore("nf2c1",
	      ($MAC_mask->packed . $IP_mask->packed),
	      ($MAC_hdr->packed  . $IP_match->packed));

nftest_ignore("nf2c2",
	      ($MAC_mask->packed . $IP_mask->packed),
	      ($MAC_hdr->packed  . $IP_match->packed));

nftest_ignore("nf2c3",
	      ($MAC_mask->packed . $IP_mask->packed),
	      ($MAC_hdr->packed  . $IP_match->packed));

nftest_ignore("eth1",
	      ($MAC_mask->packed . $IP_mask->packed),
	      ($MAC_hdr->packed  . $IP_match->packed));

nftest_ignore("eth2",
	      ($MAC_mask->packed . $IP_mask->packed),
	      ($MAC_hdr->packed  . $IP_match->packed));

# send an OSPF packet from eth1. Should be received by nf2c0 and ignored.
$MAC_hdr->DA($DA);
$MAC_hdr->SA($SA);
$MAC_hdr->Ethertype(0x800);

my $IP_ospf = NF2::IP_hdr->new(proto => 89,
			       dst_ip => $ALLSPFRouters,
			       src_ip => "124.124.124.64",
			       ttl => $TTL,
			       );
$IP_ospf->checksum(0);  # make sure its zero before we calculate it.
$IP_ospf->checksum($IP_ospf->calc_checksum);

my $ospf_pkt = $MAC_hdr->packed . $IP_ospf->packed . $PDU->packed;
nftest_send ("eth1", $ospf_pkt);

sleep 2;
print "Done sleep\n";

my $unmatched_hoh = nftest_finish();

my $total_errors = 0;

while ( my ($ifacename, $ref) = each(%$unmatched_hoh) ) {
  while ( my ($pkt, $count) = each(%$ref) ) {
    my $unpacked_pkt = unpack('H*', $pkt);
    if ($count < 0) {
      $count = -$count;
      print "Missing packets on $ifacename:\n   $unpacked_pkt\n    with count $count\n";
    }
    else {
      print "Unexpected packets on $ifacename:\n   $unpacked_pkt\n    with count $count\n";
    }
    $total_errors += $count;
  }
}

if ($total_errors==0) {
  print "SUCCESS!\n";
}
else {
  print "FAIL: $total_errors errors\n";
}
