/* ****************************************************************************
 * vim:set shiftwidth=2 softtabstop=2 expandtab:
 * $Id: selftest.c 3198 2007-12-14 20:49:00Z grg $
 *
 * Module: selftest.c
 * Project: NetFPGA 2.1
 * Description: Interface with the self-test modules on the NetFPGA
 * to help diagnose problems.
 *
 * Change history:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/time.h>

#include <net/if.h>

#include <time.h>

#include <signal.h>

#include "nf2.h"
#include "../../../lib/C/common/nf2util.h"
#include <curses.h>
#include "selftest.h"
#include "selftest_dram.h"
#include "selftest_sram.h"
#include "selftest_serial.h"
#include "selftest_phy.h"
#include "selftest_mdio.h"
#include "selftest_reg.h"
#include "selftest_clk.h"
#include "selftest_dma.h"

#define PATHLEN		80

#define DEFAULT_IFACE	"nf2c0"
#define SELFTEST_VERSION  "1.00 alpha"

#define ONE_SHOT_ITER   5

typedef enum {LOW = 0, HIGH = 1} SW_TEST_EFFORT_LEVEL;

/* Global vars */
struct nf2device nf2;
int verbose = 0;
int continuous = 0;
int shortrun = 1;
int no_sata_flg = 0;

FILE * log_file;
WINDOW *w;

/* Function declarations */
void mainContinuous(void);
void mainOneShot(void);
//void init_work(void);
void reset_tests(void);
//void show_stats (int loop_iter);
//bool show_status_serial_test(void);
//bool show_status_sram_test(void);
//bool show_status_dram_test(void);
//bool show_status_mii_test(void);
//bool show_status_phy_test(void);
//bool show_status_reg_test(void);
//void sram_sw_test(SW_TEST_EFFORT_LEVEL );
void processArgs (int, char **);
void usage (char*);
void run_continuous(void);
void reset_continuous(void);
void stop_continuous(void);
void sigint_handler(int signum);
void reset_board(void);
void title_bar(void);
void clear_line(void);

#define NUM_TESTS 8
/* Selftest module interface */
struct test_module modules[NUM_TESTS] = { 
  {
    "Clock select", 
    clkResetContinuous,
    clkShowStatusContinuous,
    clkStopContinuous,
    clkGetResult,
  },
  {
    "Register interface", 
    regResetContinuous,
    regShowStatusContinuous,
    regStopContinuous,
    regGetResult,
  },
  {
    "MDIO interface", 
    mdioResetContinuous,
    mdioShowStatusContinuous,
    mdioStopContinuous,
    mdioGetResult,
  },
  {
    "PHY interface", 
    phyResetContinuous,
    phyShowStatusContinuous,
    phyStopContinuous,
    phyGetResult,
  },
  {
    "DRAM controller", 
    dramResetContinuous,
    dramShowStatusContinuous,
    dramStopContinuous,
    dramGetResult,
  },
  {
    "SRAM controller", 
    sramResetContinuous,
    sramShowStatusContinuous,
    sramStopContinuous,
    sramGetResult,
  },
  {
    "SATA controller", 
    serialResetContinuous,
    serialShowStatusContinuous,
    serialStopContinuous,
    serialGetResult,
  },
  {
    "DMA interface",
    dmaResetContinuous,
    dmaShowStatusContinuous,
    dmaStopContinuous,
    dmaGetResult,
  },
};


/*
 * Main function
 */
int main(int argc, char *argv[])
{
  // Set the default device
  nf2.device_name = DEFAULT_IFACE;

  // Process the command line arguments
  processArgs(argc, argv);

  // Check that the interface is valid and open it if possible
  if (check_iface(&nf2))
  {
    exit(1);
  }
  if (openDescriptor(&nf2))
  {
    exit(1);
  }

  // Add a signal handler
  signal(SIGINT, sigint_handler);

  // Measure the clock rates
  measureClocks();

  // Run the appropriate test
  if (continuous) {
    mainContinuous();
  }
  else if (shortrun) {
    mainOneShot();
  }

  // Close the network descriptor
  closeDescriptor(&nf2);

  return 0;
}

/*
 * "Main" function for continuous mode
 */
void mainContinuous(void)
{
  // Set up curses
  w = initscr();
  cbreak();
  halfdelay(1);
  noecho();

  //init_work(); //initialization. one time effort

  // Run the test in continuous mode
  run_continuous();
  stop_continuous();

  // End the curses
  endwin();
}

/*
 * "Main" function for one-shot mode
 */
void mainOneShot(void)
{
  int i;
  int failed = 0;

  // Reset the board and initialize the tests
  reset_board();
  reset_continuous();

  // Run the test in one-shot mode mode
  printf("NetFPGA selftest %s\n", SELFTEST_VERSION);
  printf("Running");
  fflush(stdout);
  for (i = 0; i < ONE_SHOT_ITER; i++) {
    sleep(1);
    printf(".");
    fflush(stdout);
  }
  printf(" ");

  // Verify the results
  for (i = 0; i < NUM_TESTS; i++) {
    if (!modules[i].get_result()) {
      if (!failed)
        printf("FAILED. Failing tests: ");
      else
        printf(", ");
      printf(modules[i].name);

      // Record that the tests have failed
      failed = 1;
    }
  }

  // Terminat the tests
  stop_continuous();

  // Check if the tests failed
  if (!failed)
    printf("PASSED\n");
  else
    printf("\n");
}

/*
 * Display a title bar
 */
void title_bar(void) {
  move(0,0);
  attron(A_REVERSE);
  clear_line();
  move(0,4);
  printw("NetFPGA selftest v%s", SELFTEST_VERSION);
  attroff(A_REVERSE);
}

/*
 * Clear a line
 */
void clear_line(void) {
  int n;

  n = COLS;
  for (; n > 0; n--)
      addch(' ');
}

/*
 * Run the program in continuous mode
 */
void run_continuous(void) {
  int ch = ERR;
  int count;
  int prev_lines;
  int prev_cols;
  int i;

  // Reset the board and initialize the tests
  reset_board();
  reset_continuous();


  // Run the tests continuously and wait
  while (1) {
    // Remember the screen dimensions
    prev_lines = LINES;
    prev_cols = COLS;

    // Clear the screen and move to the top corner
    erase();
    move(0,0);

    // Display a title bar
    title_bar();

    // Display the output of the tests
    move(2,0);

    for (i = 0; i < NUM_TESTS; i++) {
      modules[i].show_status_continuous();
    }

    // Display a footer bar
    move(LINES - 1, 0);
    clear_line();
    move(LINES - 1, 0);
    attron(A_REVERSE);
    printw("Q");
    attroff(A_REVERSE);
    printw(" Quit");
    move(LINES - 2,0);

    // Draw the screen
    refresh();

    // Sleep for a while, looking for key presses
    count = 0;
    ch = ERR;
    while (count < 10 && ch != 'q' && ch != 'Q' && prev_lines == LINES && prev_cols == COLS) {
      ch = getch();
      count++;
    }
    if (ch == 'q' || ch == 'Q') {
      return;
    }
  }
}

/*
 * Reset the board
 */
void reset_board(void) {
   u_int val;

   /* Read the current value of the control register so that we can modify
    * it to do a reset */
   readReg(&nf2, CPCI_REG_CTRL, &val);

   /* Write to the control register to reset it */
   writeReg(&nf2, CPCI_REG_CTRL, val | 0x100);
}

/*
 * Handle SIGINT gracefully
 */
void sigint_handler(int signum) {
  if (signum == SIGINT) {
    endwin();

    if (continuous)
      stop_continuous();

    printf("Caught SIGINT. Exiting...\n");
    exit(0);
  }
}

/*
 * Invoke the reset functions for continuous mode
 */
void reset_continuous(void) {
  int i;

  for (i = 0; i < NUM_TESTS; i++) {
    modules[i].reset_continuous();
  }
}

/*
 * Invoke the stop functions for continuous mode
 */
void stop_continuous(void) {
  int i;

  for (i = 0; i < NUM_TESTS; i++) {
    modules[i].stop_continuous();
  }
}

//initialize. this is one time effort
/*void init_work() {
  struct timeval tv;
  struct timezone tz;

  gettimeofday(&tv, &tz);

  long int sram_tst_seed = tv.tv_sec;
  srand48(sram_tst_seed);

  log_file = fopen("selftest.log", "a");
  fprintf(log_file, "sram h/w random test seed = %ld\n", sram_tst_seed);
}*/

// Reset the status of all tests
void reset_tests(void) {
  unsigned int val;
  int i;

  unsigned int data1, data2;
  move(10,0);
/*
  readReg(&nf2, NF2_REG_REF_TEST_BASE + (254) * 4, &val);
  printw("0x%08x\n", val);
  readReg(&nf2, NF2_REG_REF_TEST_BASE + (253) * 4, &val);
  printw("0x%08x\n", val);
  readReg(&nf2, NF2_REG_REF_TEST_BASE + (252) * 4, &val);
  printw("0x%08x\n", val);
*/

  for (i = 0; i < 100; i++) {
    //sleep(1);
    //readReg(&nf2, NF2_REG_REF_TEST_BASE + (i) * 4, &val);
    //writeReg(&nf2, NF2_REG_REF_TEST_BASE + (i) * 4, i);
  }

  

  // program h/w random test with a different test seed for each iteration 
  data1 = lrand48();
  data2 = lrand48();
  writeReg(&nf2, NF2_SRAM_TEST_RAND_SEED_HI, data1 & 0xf); 
  writeReg(&nf2, NF2_SRAM_TEST_RAND_SEED_LO, data2);

  writeReg(&nf2, NF2_SRAM_TEST_EN, 0x0003001f);
  writeReg(&nf2, NF2_DRAM_TEST_EN, 0x0000001f);
  writeReg(&nf2, NF2_DRAM_TEST_CTRL, 0x00000000);
  usleep(100000);
  writeReg(&nf2, NF2_DRAM_TEST_CTRL, 0x00000002);
  //writeReg(&nf2, NF2_PHY_TEST_RESTART, 0x00000001);

  writeReg(&nf2, NF2_SERIAL_TEST_CTRL, 1<<SERIAL_TEST_RESTART_BIT_NUM);
  //writeReg(&nf2, NF2_SERIAL_TEST_CTRL, 1<<SERIAL_TEST_NONSTOP_BIT_NUM);
  writeReg(&nf2, NF2_SERIAL_TEST_CTRL, 0);
  writeReg(&nf2, NF2_SERIAL_CTRL_0, 0);
  writeReg(&nf2, NF2_SERIAL_CTRL_1, 0);
}

/*void show_stats(int loop_iter) {
  bool all_test_done = false; 
  bool sram_test_done = false; 
  bool dram_test_done = false; 
  bool mii_test_done = false; 
  bool phy_test_done = false;
  bool reg_test_done = false;
  bool serial_test_done;

  while (! all_test_done) {
      clear();
      move(0,0);
      printw("NetFPGA 2.1 self test\nloop iteration=%d\n\n", loop_iter);

      //add all self test functions below: 
      //sram_test_done = show_status_sram_test( );
      dram_test_done = show_status_dram_test();
      mii_test_done = show_status_mii_test();
      //phy_test_done = show_status_phy_test();
      reg_test_done = show_status_reg_test();
      serial_test_done = show_status_serial_test();

      // apply "&&" to all tests' done variables   
      all_test_done = sram_test_done && 
                      dram_test_done && 
                      mii_test_done && 
                      phy_test_done && 
                      reg_test_done &&
                      serial_test_done; 
      
      refresh();
      sleep(2);

   }

}

bool show_status_serial_test() {
  bool test_done;
  unsigned int val, val2;

//  readReg(&nf2, NF2_SERIAL_CTRL_0, &val);
//  printw("Serial module 0 ctrl  :       user_rst   : %d\n", 1&(val>>SERIAL_USR_RESET_BIT_NUM));

//  readReg(&nf2, NF2_SERIAL_STATUS_0, &val);
//  printw("Serial module 0 status:       lane up    : %d,   channel_up  : %d,   hard_error  : %d\n",
//	 1&(val>>SERIAL_LANE_UP_BIT_NUM), 1&(val>>SERIAL_CHANNEL_UP_BIT_NUM), 1&(val>>SERIAL_HARD_ERROR_BIT_NUM));
//  printw("                              soft_error : %d,   frame_error : %d,   error_count : %d\n",
//	 1&(val>>SERIAL_SOFT_ERROR_BIT_NUM),1&(val>>SERIAL_FRAME_ERROR_BIT_NUM), SERIAL_ERROR_COUNT_MASK&(val>>SERIAL_ERROR_COUNT_BIT_NUM));
//  
//  readReg(&nf2, NF2_SERIAL_NUM_FRAMES_SENT_0, &val);
//  readReg(&nf2, NF2_SERIAL_NUM_FRAMES_RCVD_0, &val2);
//  printw("Serial module 0 stats :       num frames sent:   %d, num frames rcvd:   %d\n", val, val2);


//  readReg(&nf2, NF2_SERIAL_CTRL_1, &val);
//  printw("Serial module 1 ctrl  :       user_rst   : %d\n", 1&(val>>SERIAL_USR_RESET_BIT_NUM));

//  readReg(&nf2, NF2_SERIAL_STATUS_1, &val);
//  printw("Serial module 1 status:       lane up    : %d,   channel_up  : %d,   hard_error  : %d\n", 
//	 1&(val>>SERIAL_LANE_UP_BIT_NUM), 1&(val>>SERIAL_CHANNEL_UP_BIT_NUM), 1&(val>>SERIAL_HARD_ERROR_BIT_NUM));
//  printw("                              soft_error : %d,   frame_error : %d,   error_count : %d\n",
//	 1&(val>>SERIAL_SOFT_ERROR_BIT_NUM),1&(val>>SERIAL_FRAME_ERROR_BIT_NUM), SERIAL_ERROR_COUNT_MASK&(val>>SERIAL_ERROR_COUNT_BIT_NUM));
  
//  readReg(&nf2, NF2_SERIAL_NUM_FRAMES_SENT_1, &val);
//  readReg(&nf2, NF2_SERIAL_NUM_FRAMES_RCVD_1, &val2);
//  printw("Serial module 1 stats :       num frames sent:   %d, num frames rcvd:   %d\n", val, val2);

//  readReg(&nf2, NF2_SERIAL_TEST_CTRL, &val);
//  printw("Serial Test ctrl      :       Restart    : %d    Don't stop  : %d \n", 1&(val>>SERIAL_TEST_RESTART_BIT_NUM), 1&(val>>SERIAL_TEST_NONSTOP_BIT_NUM));

  readReg(&nf2, NF2_SERIAL_TEST_STAT, &val);
//  printw("Serial Test status    :       Success    : %d    Done        : %d    Running     : %d\n", 
//	 1&(val>>SERIAL_TEST_SUCCESSFUL_BIT_NUM), 1&(val>>SERIAL_TEST_DONE_BIT_NUM), 1&(val>>SERIAL_TEST_RUNNING_BIT_NUM));
//  printw("                              Count      : %d \n", (val>>SERIAL_TEST_COUNT_BIT_NUM));

  test_done = (((val>>SERIAL_TEST_DONE_BIT_NUM)&1)==1);

  return test_done;
}

bool show_status_sram_test( ) {
  unsigned int max_num_of_tests = 3;
  bool test_done; 
  int i; 

  unsigned int val; 
  unsigned char sram_en, test_en, test_done_sram_0, test_done_sram_1, test_fail_sram_0, test_fail_sram_1;

  bool done_sram_0, done_sram_1; 
  int a = 2;
  int b = 1;
  int c = 1;
  int d = 0;

  readReg(&nf2, NF2_SRAM_TEST_EN, &val);

  sram_en = (val >> 16) & 0x3;

  test_en = val & 0xFF;
  printw("0x%08x   SRAM en: %x   SRAM test en: %x\n", val, sram_en, test_en);

  for (i = 0; i < b; i++) {
  readReg(&nf2, NF2_SRAM_TEST_STATUS, &val);
  test_done_sram_0 = val & 0xFF;
  test_fail_sram_0 = (val >> 8) & 0xFF;
  test_done_sram_1 = (val >> 16) & 0xFF;
  test_fail_sram_1 = (val >> 24) & 0xFF;
  printw("SRAM test done: %x %x   SRAM test fail: %x %x\n", test_done_sram_0, test_done_sram_1, test_fail_sram_0, test_fail_sram_1);
  }

  for (i = 0; i < c; i++) {
  readReg(&nf2, NF2_SRAM_TEST_ERR_CNT, &val);
  printw("SRAM err: %x\n", val);
  }

  if (d)
    return false;

  
  readReg(&nf2, NF2_SRAM_TEST_EN, &val);
  sram_en = (val >> 16) & 0x3;
  test_en = val & 0xFF;

  done_sram_0 = !(sram_en & 0x1) || (test_en == test_done_sram_0);
  done_sram_1 = !(sram_en & 0x2) || (test_en == test_done_sram_1);
  test_done = done_sram_0 && done_sram_1;

  readReg(&nf2, NF2_SRAM_TEST_ERR_CNT, &val);
  printw("SRAM err: %x\n", val);
  printw("SRAM chip en: %x   Test en:%x   Done: %x %x   Fail: %x %x\n", sram_en, test_en, test_done_sram_0, test_done_sram_1, test_fail_sram_0, test_fail_sram_1);

  printw("%x   SRAM en: %x   test en:%x   Done: %x %x   Fail: %x %x\n", val, sram_en, test_en, test_done_sram_0, test_done_sram_1, test_fail_sram_0, test_fail_sram_1);

  if (test_done) {
    if (! (test_fail_sram_0 | test_fail_sram_1) ) {
      //all tests passed 
      printw("SRAM test: Passed all tests\n");

    }
    else {
      //some tests failed 

      printw("SRAM test: Failed tests "); 
      for (i = 0; i < max_num_of_tests; i++) 
	if ( ((test_fail_sram_0 | test_fail_sram_1) >> i) & 0x1) {
	  printw("%d  ", i + 1);
	}

      printw("\n");
    }
  } // if (test_done)
  
  else {
    //some tests are running 
    
    if (! done_sram_0) {
      //some tests running for sram_0 
      
      for (i = 0; i < max_num_of_tests; i++)  
	if ( ((test_en ^ test_done_sram_0) >> i) & 0x1 ) {
	  printw("SRAM test: Running test %d on SRAM_0\n", i + 1);
	  break; 
	}

    }

    else {
      //some tests running for sram_1 

      for (i = 0; i < max_num_of_tests; i++)  
	if ( ((test_en ^ test_done_sram_1) >> i) & 0x1 ) {
	  printw("SRAM test: Running test %d on SRAM_1\n", i + 1);
	  break; 
	}
    }
    
  } // some tests are running 

  return test_done; 

} //  show_status_sram_test(...
*/




//bool show_status_phy_test() {
/*
   unsigned int val; 
   unsigned int error_cnt, curr_log, err_code;
   int i;

   char *error_desc[6];

   error_desc[1] = "RX Packet Timed out";
   error_desc[2] = "Data Mismatch between TX and RX packet";
   error_desc[3] = "RX packet has different length from TX packet";
   error_desc[4] = "Packet status word error (probably caused by wrong CRC)";
   error_desc[5] = "More than one bit set in the EOP signal";



   printw("\n\n\nPhy test status:\n");
   readReg(&nf2, NF2_PHY_TEST_DONE, &val);
   if (val == 0) {
      printw("\tPhy test is still running\n");
      return val;
   }
   
    
   readReg(&nf2, NF2_PHY_TEST_ERROR_CNT, &error_cnt);
   if (error_cnt == 0) {
      printw("\tPhy test completed successfully with no errors!\n");
      return 1;
   }
   
   printw("\tPhy test completed with %u errors\n", error_cnt);
   if (error_cnt > 16) {
      printw("\n\tA log of the first 16 errors is shown below\n");
   }
   else {
      printw("\n\tA log the errors is shown below\n");
   }


   for (curr_log = 0; curr_log < error_cnt; curr_log ++) {
      printw("\t\tError %d: ", curr_log + 1);
      readReg(&nf2, NF2_PHY_TEST_ERRCODE_BASE+4*curr_log, &err_code);
      if (err_code > 0 && err_code < 6)
      	printw("%s\n", error_desc[err_code]);
      else
      	printw("Invalid error code: 0x%08x\n", err_code);

      readReg(&nf2, NF2_PHY_TEST_PKT_TYPE_BASE+4*curr_log, &val);
      printw("\t\t\tTest content type: ");
      switch(val) {
         case 0:  printw("0x0000...\n"); break;
         case 1:  printw("0xFFFF...\n"); break;
         case 2:  printw("0x5555...\n"); break;
         case 3:  printw("0xaaaa...\n"); break;
         default: printw("Undefined packet type\n"); 
      }

      
      readReg(&nf2, NF2_PHY_TEST_PKT_SIZE_BASE+4*curr_log, &val);
      printw("\t\t\tTest data size: ");
      switch(val) {
         case 0:  printw("60...\n"); break;
         case 1:  printw("799...\n"); break;
         case 2:  printw("1500...\n"); break;
         case 3:  printw("1400...\n"); break;
         default: printw("Undefined test data size (%d)\n", val); 
      }
      
       
      readReg(&nf2, NF2_PHY_TEST_PORT_BASE+4*curr_log, &val);
      printw("\t\t\tRx Port: %u", val+1);

      if ( (err_code != 1) && (err_code != 5) ) {
         readReg(&nf2, NF2_PHY_TEST_EXP_DATA_BASE+4*curr_log, &val);
         printw("\t\t\tExpected data: 0x%x", val);
      }
       
        
      if (err_code != 1) {
         readReg(&nf2, NF2_PHY_TEST_SEEN_DATA_BASE+4*curr_log, &val);
         printw("\t\t\tSeen data: 0x%x", val);
      }
      printw("\n");
   } 
*/  
/*
   return 1;

} // show_status_phy_test

bool show_status_dram_test( ) {
  unsigned int max_num_of_tests = 8;
  bool all_tests_done; 
  int i; 

  unsigned int val; 
  unsigned char test_en, test_done, test_fail;

  unsigned int fail_cnt;
  unsigned int fail_addr;
  unsigned long long fail_exp;
  unsigned long long fail_rd;

  readReg(&nf2, NF2_DRAM_TEST_EN, &val);
  test_en = val & 0xFF;
  
  readReg(&nf2, NF2_DRAM_TEST_STATUS, &val);
  test_done = val & 0xFF;
  test_fail = (val >> 8) & 0xFF;

  readReg(&nf2, NF2_DRAM_TEST_ERR_CNT, &val);
  printw("DRAM err: %x\n", val);

  printw("%x   test en:%x   Done: %x   Fail: %x\n", val, test_en, test_done, test_fail);
  all_tests_done = test_done == test_en;

  readReg(&nf2, NF2_DRAM_TEST_ITER_CNT, &val);
  printw("DRAM iter: %d\n", val);

  readReg(&nf2, NF2_DRAM_TEST_BAD_CNT, &val);
  printw("DRAM bad: %d\n", val);

  readReg(&nf2, NF2_DRAM_TEST_GOOD_CNT, &val);
  printw("DRAM good: %d\n", val);

  if (all_tests_done) {
    if (!test_fail) {
      // All tests passed 
      printw("DRAM test: Passed all tests\n");

      printw("Writing: 0x12345678 0xaaaaaaaa 0xabcd9876 0xfeedf00d\n");
      writeReg(&nf2, NF2_DRAM_BASE + 0x0, 0x12345678);
      writeReg(&nf2, NF2_DRAM_BASE + 0x4, 0xaaaaaaaa);
      writeReg(&nf2, NF2_DRAM_BASE + 0x8, 0xabcd9876);
      writeReg(&nf2, NF2_DRAM_BASE + 0xc, 0xfeedf00d);

      printw("Read:   ");
      for (i = 0; i < 8; i++) {
        readReg(&nf2, NF2_DRAM_BASE + 4 * i, &val);
        printw(" 0x%08x", val);
      }
      printw("\n");


    }
    else {
      //some tests failed 

      printw("DRAM test: Failed tests "); 
      for (i = 0; i < max_num_of_tests; i++) 
	if ( (test_fail >> i) & 0x1) {
	  printw("%d  ", i + 1);
	}
      printw("\n");

      // Print the failing tests
      readReg(&nf2, NF2_DRAM_TEST_ERR_CNT, &fail_cnt);

      for (i = 0; i < fail_cnt; i++) {
        readReg(&nf2, NF2_DRAM_TEST_LOG_ADDR + i * NF2_DRAM_TEST_LOG_OFFSET, &fail_addr);

        readReg(&nf2, NF2_DRAM_TEST_LOG_EXP_DATA_HI + i * NF2_DRAM_TEST_LOG_OFFSET, &val);
        fail_exp = (unsigned long long)val << 32;
        readReg(&nf2, NF2_DRAM_TEST_LOG_EXP_DATA_LO + i * NF2_DRAM_TEST_LOG_OFFSET, &val);
        fail_exp |= val;

        readReg(&nf2, NF2_DRAM_TEST_LOG_RD_DATA_HI + i * NF2_DRAM_TEST_LOG_OFFSET, &val);
        fail_rd = (unsigned long long)val << 32;
        readReg(&nf2, NF2_DRAM_TEST_LOG_RD_DATA_LO + i * NF2_DRAM_TEST_LOG_OFFSET, &val);
        fail_rd |= val;
        
        printw("\tError at: %07x   Expected: %016x   Saw: %016x\n", fail_addr, fail_exp, fail_rd);
      }
    }
  } // if (all_tests_done)
  
  else {
    //some tests are running 
    
    for (i = 0; i < max_num_of_tests; i++)  
      if ( ((test_en ^ test_done) >> i) & 0x1 ) {
        printw("DRAM test: Running test %d\n", i + 1);
        break; 
      }
  } // some tests are running 
  printw("\n");

  return all_tests_done; 

} //  show_status_dram_test(...


bool show_status_mii_test( ) {
  unsigned int max_num_of_tests = 8;
  bool all_tests_done; 
  int i; 

  unsigned int val; 
  unsigned char test_en, test_done, test_fail;

  unsigned int fail_cnt;
  unsigned int fail_addr;
  unsigned long long fail_exp;
  unsigned long long fail_rd;

  int retry;

  printw("MII Test\n");

  for (i = 0; i < 32 * 4; i++) {
    // Read the result (might have to read multiple times)
    retry = 4;
    do {
      readReg(&nf2, NF2_MII_REG_BASE + 0 * NF2_MII_PHY_OFFSET + i * 4, &val);
      retry--;
    } while (retry > 0 && (val & 0x80000000));

    if (i % 8 == 0)
      printw("%08x:  ", NF2_MII_REG_BASE + 0 * NF2_MII_PHY_OFFSET + i * 4);
    printw("%04x ", val);
    if (i % 8 == 7)
      printw("\n");

  }
  printw("\n");

  // Write to the interrrupt mask registers
  writeReg(&nf2, NF2_MII_REG_BASE + 0 * NF2_MII_PHY_OFFSET + 0x1b * 4, 0x1234);
  retry = 4;
  do {
    readReg(&nf2, NF2_MII_REG_BASE + 0 * NF2_MII_PHY_OFFSET + 0 * 4, &val);
    retry--;
  } while (retry > 0 && (val & 0x80000000));
  writeReg(&nf2, NF2_MII_REG_BASE + 1 * NF2_MII_PHY_OFFSET + 0x1b * 4, 0xaaaa);
  retry = 4;
  do {
    readReg(&nf2, NF2_MII_REG_BASE + 0 * NF2_MII_PHY_OFFSET + 0 * 4, &val);
    retry--;
  } while (retry > 0 && (val & 0x80000000));
  writeReg(&nf2, NF2_MII_REG_BASE + 2 * NF2_MII_PHY_OFFSET + 0x1b * 4, 0x9876);
  retry = 4;
  do {
    readReg(&nf2, NF2_MII_REG_BASE + 0 * NF2_MII_PHY_OFFSET + 0 * 4, &val);
    retry--;
  } while (retry > 0 && (val & 0x80000000));
  writeReg(&nf2, NF2_MII_REG_BASE + 3 * NF2_MII_PHY_OFFSET + 0x1b * 4, 0x5555);
  retry = 4;
  do {
    readReg(&nf2, NF2_MII_REG_BASE + 0 * NF2_MII_PHY_OFFSET + 0 * 4, &val);
    retry--;
  } while (retry > 0 && (val & 0x80000000));

  for (i = 0; i < 4; i++) {
    retry = 4;
    do {
      readReg(&nf2, NF2_MII_REG_BASE + i * NF2_MII_PHY_OFFSET + 0x1b * 4, &val);
      retry--;
    } while (retry > 0 && (val & 0x80000000));
    printw("%04x ", val);
  }
  printw("\n");

  
  all_tests_done = false;
  return all_tests_done; 

} //  show_status_mii_test(...


bool show_status_reg_test( ) {
  bool all_tests_done = false; 
  unsigned int max_words = 1024 / 4;
  unsigned int val; 
  int i; 


  printw("Reg test: writing to registers\n");
  for (i = 0; i < max_words; i++) {
    //writeReg(&nf2, NF2_REG_TEST_BASE + i * 4, i);
  }

  printw("Reg test: reading registers. Should increment sequentially\n");


*/



  //for (i = 120; i < 136 /*max_words / 2*/; i++) {




/*    if (i < max_words / 2) {
      if (i % 2 == 0)
        readReg(&nf2, NF2_REG_TEST_BASE + i * 4, &val);
      else
        readReg(&nf2, 0x0401400, &val);
    }
    else {
      readReg(&nf2, NF2_REG_REF_TEST_BASE + i * 4, &val);


*/



      /*if (val != i * 4) {
        readReg(&nf2, NF2_REG_REF_TEST_BASE + i * 4, &val);
      }*/

/*
    }

    if (i % 8 == 0)
      printw("%08x:", NF2_REG_TEST_BASE + i * 4);
    printw("  %08x", val);
    if (i % 8 == 7)
      printw("\n");
  }

  printw("\n");
  for (i = 0; i < 8; i++) {
    readReg(&nf2, NF2_REG_REF_TEST_BASE + (254) * 4, &val);
    printw("  %08x", val);
  }
  printw("\n");


  return all_tests_done; 

} //  show_status_reg_test(...

void sram_sw_test(SW_TEST_EFFORT_LEVEL effort_level) {

  int i, j; 
  
  unsigned int val1, val2, data1, data2; 

  struct timeval tv;
  struct timezone tz;
  gettimeofday(&tv, &tz);

  long int sram_tst_seed = tv.tv_sec;
  fprintf(log_file, "sram s/w random test seed = %ld\n", sram_tst_seed);
  srand48(sram_tst_seed);

  for (i=1; i<=2; i++) {

    for (j = (effort_level == LOW) ? 1 : 0; j < 512 * 1024; j = (effort_level == LOW) ? j * 2 : j + 1) {
      
      data1 = lrand48();
      data2 = lrand48();

      if (i==1) {
	writeReg(&nf2, NF2_REG_FUNC_SRAM_1_MSB_WR, data1 & 0xf);

	writeReg(&nf2, NF2_SRAM_1_BASE + j * 4, data2 & 0xffffffff);
      } 
      else {
	writeReg(&nf2, NF2_REG_FUNC_SRAM_2_MSB_WR, data1 & 0xf);

	writeReg(&nf2, NF2_SRAM_2_BASE + j * 4, data2 & 0xffffffff);
      }

      if (j <= 4) 
	fprintf(log_file, "WRITE: SRAM_%d, word addr=0x%05x, write data=0x%x %08x\n", 
	       i, j, data1 & 0xf, data2);

    }
  }

  srand48(sram_tst_seed);

  for (i=1; i<=2; i++) {

    for (j = (effort_level == LOW) ? 1 : 0; j < 512 * 1024; j = (effort_level == LOW) ? j * 2 : j + 1) {

      if (i==1) {
	readReg(&nf2, NF2_SRAM_1_BASE + j * 4, &data2);
	readReg(&nf2, NF2_REG_FUNC_SRAM_1_MSB_RD, &data1);

      } 
      else {
	readReg(&nf2, NF2_SRAM_2_BASE + j * 4, &data2);
	readReg(&nf2, NF2_REG_FUNC_SRAM_2_MSB_RD, &data1);
      }

      if (j <= 4) 
	fprintf(log_file, "READ : SRAM_%d, word addr=0x%05x, read   out=0x%x %08x\n", 
	       i, j, data1, data2);

      val1 = lrand48();
      val2 = lrand48();

       if (((val1 & 0xf) != (data1 & 0xf)) || 
	   ((val2 & 0xffffffff) != (data2 & 0xffffffff))) {
	 printf("Error: SRAM_%d, word addr=0x%05x, read out=0x%x 0x%08x, expect data=0x%x %08x\n",  
		i, j, data1 & 0xf, data2, val1 & 0xf, val2);

	 fprintf(log_file, "Error: SRAM_%d, word addr=0x%05x, read out=0x%x 0x%08x, expect data=0x%x %08x\n",  
		i, j, data1 & 0xf, data2, val1 & 0xf, val2);
       }
      
    } // for (j

  } // for (i 

  fprintf(log_file, "\n");

}
*/


/* 
 * Process the arguments.
 */
void processArgs (int argc, char **argv ) {

   char c;

   /* set defaults */
   verbose = 0;

   /* don't want getopt to moan - I can do that just fine thanks! */
   opterr = 0;
   while ((c = getopt (argc, argv, "csi:n")) != -1)
      switch (c)
	 {
	 case 'c':
	    continuous = 1;
	    shortrun = 0;
	    break;
	 case 's':
	    shortrun = 1;
	    continuous = 0;
	    break;
//	 case 'v':
//	    verbose = 1;
//	    break;
//	 case 'l':   /* log file */
//	    log_file_name = optarg;
//	    break;
	 case 'i':   /* interface name */
	    nf2.device_name = optarg;
	    break;
   case 'n': /* without SATA test */
      no_sata_flg = 1;
      break;
	 case '?':
	    if (isprint (optopt))
               fprintf (stderr, "Unknown option `-%c'.\n", optopt);
	    else
               fprintf (stderr,
                        "Unknown option character `\\x%x'.\n",
                        optopt);
	 default:
	    usage(argv[0]);
	    exit(1);
	 }

//   if (verbose) {
//      printf ("logfile = %s.   bin file = %s\n", log_file_name, bin_file_name);
//   }

}

/*
 * Describe usage of this program.
 */
void usage (char *prog) {
   printf("Usage: %s <options>  [filename.bin | filename.bit]\n", prog);
   printf("\nOptions: -l <logfile> (default is stdout).\n");
   printf("         -i <iface> : interface name.\n");
   printf("         -v : be verbose.\n");
   printf("         -c : run continuously\n");
   printf("         -s : short test mode\n");
   printf("         -n : disable SATA testing\n");
}


