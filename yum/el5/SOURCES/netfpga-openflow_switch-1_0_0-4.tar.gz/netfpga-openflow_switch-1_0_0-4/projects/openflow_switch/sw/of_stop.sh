#!/bin/bash

# Execute this shell as a super user on your home directory

# 1. Kill ofprotocol then ofdatapath

killall ofprotocol
killall ofdatapath

