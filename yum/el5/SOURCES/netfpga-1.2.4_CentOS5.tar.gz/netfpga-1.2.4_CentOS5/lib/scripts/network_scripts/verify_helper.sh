#!/bin/bash
#
# This script sources the net_commons and goes back into verify.pl
#

. net_common.sh
./verify.pl --no_source