#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0x89e24b9c, "struct_module" },
	{ 0x4c3af445, "__request_region" },
	{ 0x4ac7b024, "pci_bus_read_config_byte" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0x89b301d4, "param_get_int" },
	{ 0xdc3eaf70, "iomem_resource" },
	{ 0xb8f60d68, "skb_pad" },
	{ 0xe1b7029c, "print_tainted" },
	{ 0xab978df6, "malloc_sizes" },
	{ 0x3ffa5ef4, "pci_disable_device" },
	{ 0x772274b1, "netif_carrier_on" },
	{ 0x87b6fae2, "netif_carrier_off" },
	{ 0xfb1d0a92, "alloc_netdev" },
	{ 0xd8c152cd, "raise_softirq_irqoff" },
	{ 0x98bd6f46, "param_set_int" },
	{ 0x87cddf59, "_spin_lock_irqsave" },
	{ 0x7d11c268, "jiffies" },
	{ 0xda4008e6, "cond_resched" },
	{ 0x92cfbd9d, "netif_rx" },
	{ 0xa13798f8, "printk_ratelimit" },
	{ 0xb2a606bf, "pci_set_master" },
	{ 0x51ba71d3, "pci_set_dma_mask" },
	{ 0x1b7d4074, "printk" },
	{ 0x15e074de, "free_netdev" },
	{ 0x2da418b5, "copy_to_user" },
	{ 0x604efc6a, "register_netdev" },
	{ 0x625acc81, "__down_failed_interruptible" },
	{ 0xa20fdde, "_spin_unlock_irqrestore" },
	{ 0x1902adf, "netpoll_trap" },
	{ 0x9eac042a, "__ioremap" },
	{ 0x1c53db6e, "skb_over_panic" },
	{ 0x19070091, "kmem_cache_alloc" },
	{ 0x9aebf873, "__alloc_skb" },
	{ 0x26e96637, "request_irq" },
	{ 0x89d282ea, "kfree_skb" },
	{ 0x6b2dc060, "dump_stack" },
	{ 0xb00b9d99, "eth_type_trans" },
	{ 0x8bb33e7d, "__release_region" },
	{ 0x7423476b, "pci_unregister_driver" },
	{ 0xad97dcd, "ether_setup" },
	{ 0x280f9f14, "__per_cpu_offset" },
	{ 0x19cacd0, "init_waitqueue_head" },
	{ 0x37a0cba, "kfree" },
	{ 0xedc03953, "iounmap" },
	{ 0x13f3405e, "__pci_register_driver" },
	{ 0x60a4461c, "__up_wakeup" },
	{ 0x828fe72a, "unregister_netdev" },
	{ 0x45e37139, "__netif_schedule" },
	{ 0x908aa9b2, "iowrite32" },
	{ 0xdd994dbd, "pci_enable_device" },
	{ 0xf2a644fb, "copy_from_user" },
	{ 0x2241a928, "ioread32" },
	{ 0xf20dabd8, "free_irq" },
	{ 0x3b41e04b, "per_cpu__softnet_data" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("pci:v0000FEEDd00000001sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "6F4EE29319276B21F641935");
