#ifndef SR_LWTCP_GLUE_H_
#define SR_LWTCP_GLUE_H_

#include "sr_base_internal.h"

void sr_transport_input(uint8_t* packet /* borrowed */);

#endif /*SR_LWTCP_GLUE_H_*/
