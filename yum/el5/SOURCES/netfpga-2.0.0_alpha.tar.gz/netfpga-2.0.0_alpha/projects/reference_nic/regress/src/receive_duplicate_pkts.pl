#!/usr/bin/perl
#
# Script to receive duplicate packets as sent by the send_pkts
# program. Used to verify functionality in PHY loopback mode
#

use Net::Pcap;

use strict;

use constant WAIT_TIME_IN_HASH => 10;

my $err = '';
my $dev = $ARGV[0];
my $type= hex($ARGV[1]);

my $exp_seq = 1;
my %unmatched_pkts = ();
my $num_errors = 0;
my $num_pkts_processed = 0;

# open the device for live listening
print "Opening $dev.\n";
my $pcap = Net::Pcap::open_live($dev, 1514, 1, 0, \$err)
  or die "Can't open device $dev: $err\n";

#my $pcap = Net::Pcap::open_offline("temp_nf2c0.pcap", \$err)
#  or die "Can't read file: $err\n";

# install signal handler
sub sighup_rcvd{
  print "Signal rcvd\n";
  Net::Pcap::breakloop($pcap);
}
$SIG{HUP} = 'sighup_rcvd';
$SIG{INT} = 'sighup_rcvd';
$SIG{QUIT} = 'sighup_rcvd';
$SIG{KILL} = 'sighup_rcvd';

print "Starting capture.\n";

# loop over forever (until breakloop is called)
Net::Pcap::loop($pcap, -1, \&process_packet, "hello");

print "Capture done.\n";

finish();

# close the device
Net::Pcap::close($pcap);


#######################################################################
# functions

sub bintohex {
  unpack("H*", shift);
}

# processes a packet to match it with a previous packet 
# or store it for later matching
sub process_packet {
  my ($user_data, $header, $packet) = @_;

  my $value;

  # parse the packet info
  my ($total_num_pkts, $seq_num, $length, $eth_type) = parse_pkt($header, $packet);

  # check the ethertype and ignore
  if ($eth_type != $type) {
    return;
  }

  print "$exp_seq $seq_num \n";

  # see first if we have seen this packet before
  if($unmatched_pkts{$packet} != 0) {
    # found a match
    delete $unmatched_pkts{$packet};
  }

  elsif($seq_num < $exp_seq) {
    $num_errors++;
    print "ERROR: Packet with sequence number $seq_num was either ";
    print "duplicated, received too late, or corrupted at the sequence number.\n";
  }

  elsif($seq_num > $exp_seq) {
    $num_errors += ($seq_num - $exp_seq);
    print "ERROR: Packet with sequence number $seq_num was received but ";
    print "expected pkt with sequence number $exp_seq. Assuming pkts between ";
    print " $exp_seq and $seq_num are dropped or lost somehow and continuing.\n";
    $exp_seq = $seq_num + 1;
  }

  else {
    $unmatched_pkts{$packet} = 1;
    $exp_seq = $seq_num + 1;
  }

  $num_pkts_processed++;

  # remove any packets that have been there for too long to keep the hash table small
  # and increment the residence time
  while (($packet, $value)=each(%unmatched_pkts)) {
    if($value >= WAIT_TIME_IN_HASH){
      delete $unmatched_pkts{$packet};
      print "ERROR: Failed to match a sent packet after some time. Removing from table.\n";
      $num_errors++;
    }
    else {
      $unmatched_pkts{$packet}++;
    }
  }
}

# get the info that was parsed and put it in the format we want
# this is run after capture is done to finish up
sub finish {
  my ($packet, $value);
  while (($packet, $value)=each(%unmatched_pkts)) {
    print "ERROR: Failed to match a sent packet. Removing from table.\n";
    $num_errors++;
  }

  # get the statistics
  my %stats=();
  Net::Pcap::stats($pcap, \%stats);
  my $num_dropped = $stats{'ps_drop'};

  print "\nProcessed $num_pkts_processed pkts. Found $num_errors errors. Didn't capture $num_dropped pkts.\n";
}

# checks each packet for correctness
# this is a slow process ~1ms/pkt
sub check_pkt {

  my ($header, $bin_pkt) = @_;

  my $total_errors = 0;
  my $i = 0;
  my $exp_byte;
  my $found_byte;

  #my $pkt = unpack("H*", $bin_pkt);
  #print "$pkt\n";

  my ($ethtype_found, $total_num_pkts, $seq_num, $length, @bytes) = unpack("nNNNC*", substr($bin_pkt, 12));

  # check the ethertype
  #printf "Ethtype found: %x\n", $ethtype_found;
  if ($ethtype_found != $type) {
    $total_errors++;
    print "ERROR: Ethertype found $ethtype_found doesn't match expected $type.\n";
  }

  #printf "length is 0x%x i.e. %u\n",$length, $length;
  if($length != $header->{'len'}) {
    $total_errors++;
    print "ERROR: Expected length from packet is $length but actual length off the wire is $header->{'len'}\n";
  }

  # check the contents
  for($i=0, $exp_byte = (($length + 12) % 256);
      $i<$header->{'len'}-14-12;
      $i++, $exp_byte = ($exp_byte+1)%256){
    #$found_byte = unpack("C", substr($bin_pkt, 0, 1, ""));
    $found_byte = $bytes[$i];
    if($found_byte != $exp_byte){
      printf("ERROR: byte %d expected to be 0x%x but saw 0x%x\n",
             $i, $exp_byte, $found_byte);
      $total_errors++;
    }
  }

  return ($total_errors, $seq_num, $length);
}

sub parse_pkt {

  my ($header, $bin_pkt) = @_;

  my ($ethtype_found, $total_num_pkts, $seq_num, $length) = unpack("nNNN", substr($bin_pkt, 12, 14));

  return ($total_num_pkts, $seq_num, $length, $ethtype_found);
}
