#!/bin/env python

import subprocess
import sys

sys.exit(subprocess.call("./run.pl"))
