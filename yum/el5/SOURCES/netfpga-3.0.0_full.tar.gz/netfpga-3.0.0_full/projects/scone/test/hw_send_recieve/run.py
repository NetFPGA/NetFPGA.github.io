#!/bin/env python

import subprocess
import sys

import os; print os.getcwd()

sys.exit(subprocess.call("./run.pl"))
