/* ****************************************************************************
 * vim:set shiftwidth=2 softtabstop=2 expandtab:
 * $Id: selftest_serial.c 4196 2008-06-23 23:12:37Z grg $
 *
 * Module: selftest_serial.c
 * Project: NetFPGA selftest
 * Description: SATA selftest module
 *
 * Change history:
 *
 */

#include <sys/types.h>
#include <curses.h>
#include <time.h>
#include "../../../lib/C/common/reg_defines.h"
#include "nf2.h"
#include "selftest.h"
#include "selftest_serial.h"


//external global variable for flags
extern no_sata_flg;

/*
 * Reset the interface and configure it for continuous operation
 */
void serialResetContinuous(void) {
  writeReg(&nf2, SERIAL_TEST_CTRL_REG, 1<<SERIAL_TEST_RESTART_BIT_NUM);
  writeReg(&nf2, SERIAL_TEST_CTRL_REG, 0);
 
  writeReg(&nf2, SERIAL_TEST_CONTROL_0_REG, 0);
  writeReg(&nf2, SERIAL_TEST_CONTROL_1_REG, 0);
} // serialResetContinuous

/*
 * Show the status of the SATA test when running in continuous mode
 *
 * Return -- boolean indicatin success
 */
int serialShowStatusContinuous(void) {
  unsigned int val; 
  unsigned int val2;
  unsigned int val3;
  int64_t val_long1;
  int64_t val_long2;

  if (no_sata_flg == 1) 
  {
    printw("SATA Test Disabled\n");
    return 0;
  }
  else
  { 
  writeReg(&nf2, SERIAL_TEST_CTRL_REG, 1<<SERIAL_TEST_NONSTOP_BIT_NUM);

  readReg(&nf2, SERIAL_TEST_STATUS_0_REG, &val2);
  readReg(&nf2, SERIAL_TEST_STATUS_1_REG, &val3);

  // Read the status register
  readReg(&nf2, SERIAL_TEST_STAT_REG, &val);
  printw("SATA test: %s   (Success: %d    Running: %d)\n", 
	 ((val>>SERIAL_TEST_SUCCESSFUL_BIT_NUM) & 0x1) && ((val>>SERIAL_TEST_RUNNING_BIT_NUM) & 0x1) ? "pass" : "fail",
         ((val2>>SERIAL_LANE_UP_BIT_NUM & 0x1) && (val2>>SERIAL_CHANNEL_UP_BIT_NUM & 0x1) && (val3>>SERIAL_LANE_UP_BIT_NUM & 0x1) && (val3>>SERIAL_CHANNEL_UP_BIT_NUM & 0x1) && (val>>SERIAL_TEST_SUCCESSFUL_BIT_NUM) & 0x1),
         (val>>SERIAL_TEST_RUNNING_BIT_NUM) & 0x1);

  readReg(&nf2, SERIAL_TEST_STATUS_0_REG, &val);
  printw("Serial module 0 status:       lane up    : %d,   channel_up  : %d,   hard_error  : %d",
	 1&(val>>SERIAL_LANE_UP_BIT_NUM), 1&(val>>SERIAL_CHANNEL_UP_BIT_NUM), 1&(val>>SERIAL_HARD_ERROR_BIT_NUM));
  
  if ((val>>SERIAL_LANE_UP_BIT_NUM) == 0 && (val>>SERIAL_CHANNEL_UP_BIT_NUM) == 0)
  {
    printw("  (ERROR: Check the SATA Cable connection)\n");
  }
  else
  {
    printw("\n");
  }
 
  printw("                              soft_error : %d,   frame_error : %d,   error_count : %d\n",
	 1&(val>>SERIAL_SOFT_ERROR_BIT_NUM),1&(val>>SERIAL_FRAME_ERROR_BIT_NUM), SERIAL_ERROR_COUNT_MASK&(val>>SERIAL_ERROR_COUNT_BIT_NUM));
  
  readReg(&nf2, SERIAL_TEST_NUM_FRAMES_SENT_0_HI_REG, &val);
  val_long1 = val;
  val_long1 <<= 32;
  readReg(&nf2, SERIAL_TEST_NUM_FRAMES_SENT_0_LO_REG, &val);
  val_long1 += val;
  readReg(&nf2, SERIAL_TEST_NUM_FRAMES_RCVD_0_HI_REG, &val);
  val_long2 = val;
  val_long2 <<= 32;
  readReg(&nf2, SERIAL_TEST_NUM_FRAMES_RCVD_0_LO_REG, &val);
  val_long2 += val;
  printw("Serial module 0 stats :       num frames sent:   %d, num frames rcvd:   ", val_long1);
  printw("%d \n", val_long2);

  readReg(&nf2, SERIAL_TEST_STATUS_1_REG, &val);
  printw("Serial module 1 status:       lane up    : %d,   channel_up  : %d,   hard_error  : %d", 
	 1&(val>>SERIAL_LANE_UP_BIT_NUM), 1&(val>>SERIAL_CHANNEL_UP_BIT_NUM), 1&(val>>SERIAL_HARD_ERROR_BIT_NUM));

  if ((val>>SERIAL_LANE_UP_BIT_NUM) == 0 && (val>>SERIAL_CHANNEL_UP_BIT_NUM) == 0)
  {
    printw("  (ERROR: Check the SATA Cable connection)\n");
  }
  else
  {
    printw("\n");
  }
  
  printw("                              soft_error : %d,   frame_error : %d,   error_count : %d\n",
	 1&(val>>SERIAL_SOFT_ERROR_BIT_NUM),1&(val>>SERIAL_FRAME_ERROR_BIT_NUM), SERIAL_ERROR_COUNT_MASK&(val>>SERIAL_ERROR_COUNT_BIT_NUM));
  
  readReg(&nf2, SERIAL_TEST_NUM_FRAMES_SENT_1_HI_REG, &val);
  val_long1 = val;
  val_long1 <<= 32;
  readReg(&nf2, SERIAL_TEST_NUM_FRAMES_SENT_1_LO_REG, &val);
  val_long1 += val;
  readReg(&nf2, SERIAL_TEST_NUM_FRAMES_RCVD_1_HI_REG, &val);
  val_long2 = val;
  val_long2 <<= 32;
  readReg(&nf2, SERIAL_TEST_NUM_FRAMES_RCVD_1_LO_REG, &val);
  val_long2 += val;
  printw("Serial module 1 stats :       num frames sent:   %d, num frames rcvd:   ", val_long1);
  printw("%d \n", val_long2);

  return ((val>>SERIAL_TEST_SUCCESSFUL_BIT_NUM) & 0x1) && ((val>>SERIAL_TEST_RUNNING_BIT_NUM) & 0x1);
  }
} // serialShowStatusContinuous

/*
 * Stop the interface
 */
void serialStopContinuous(void) {
  writeReg(&nf2, SERIAL_TEST_CTRL_REG, 0);
} // serialStopContinuous

/*
 * Get the test result
 *
 * Return -- boolean indicatin success
 */
int serialGetResult(void) {
  unsigned int val; 
  unsigned int val2;
  unsigned int val3;

/*   readReg(&nf2, SERIAL_TEST_CTRL_REG, &val); */
/*   printf("nonstop: %d\n",((val>>SERIAL_TEST_NONSTOP_BIT_NUM) & 0x1)) ; */
if (no_sata_flg != 1)
{
  // Read the status register
  readReg(&nf2, SERIAL_TEST_STAT_REG, &val);
  readReg(&nf2, SERIAL_TEST_STATUS_0_REG, &val2);
  readReg(&nf2, SERIAL_TEST_STATUS_1_REG, &val3);
  
/*   printf("success: %d, done: %d, count: %x\n",((val>>SERIAL_TEST_SUCCESSFUL_BIT_NUM) & 0x1), ((val>>SERIAL_TEST_DONE_BIT_NUM) & 0x1), val>>3) ; */

  return ((val2>>SERIAL_LANE_UP_BIT_NUM & 0x1) && (val2>>SERIAL_CHANNEL_UP_BIT_NUM & 0x1) && (val3>>SERIAL_LANE_UP_BIT_NUM & 0x1) && (val3>>SERIAL_CHANNEL_UP_BIT_NUM & 0x1) && (val>>SERIAL_TEST_SUCCESSFUL_BIT_NUM) & 0x1) && ((val>>SERIAL_TEST_DONE_BIT_NUM) & 0x1);
}
else 
{
  return 1;
}
} // serialGetResult

