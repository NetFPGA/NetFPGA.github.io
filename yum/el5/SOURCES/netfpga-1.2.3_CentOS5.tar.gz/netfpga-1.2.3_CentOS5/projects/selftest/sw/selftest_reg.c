/* ****************************************************************************
 * vim:set shiftwidth=2 softtabstop=2 expandtab:
 * $Id: selftest_reg.c 4196 2008-06-23 23:12:37Z grg $
 *
 * Module: selftest_reg.c
 * Project: NetFPGA selftest
 * Description: Register selftest module
 *
 * Change history:
 *
 */

#include "../../../lib/C/common/reg_defines.h"
#include "nf2.h"
#include "selftest.h"
#include "selftest_reg.h"
#include <curses.h>
#include <time.h>

/*
 * Reset the interface and configure it for continuous operation
 */
void regResetContinuous(void) {
} // regResetContinuous

/*
 * Show the status of the SATA test when running in continuous mode
 *
 * Return -- boolean indicating success
 */
int regShowStatusContinuous(void) {
  unsigned int val; 
  int i;
  int vals[REG_TEST_SIZE];
  int ok = 1;

  // Generate random values and write them to the test registers
  for (i = 0; i < REG_TEST_SIZE; i++) {
    vals[i] = rand();
    writeReg(&nf2, REG_FILE_BASE_ADDR_REG + i * 4, vals[i]);
  }

  // Read the values back to check for errors
  for (i = 0; i < REG_TEST_SIZE; i++) {
    readReg(&nf2, REG_FILE_BASE_ADDR_REG + i * 4, &val);
    if (val != vals[i]) {
      ok = 0;
    }
  }

  printw("Reg test: %s\n", ok ? "pass" : "fail");

  return ok;
} // regShowStatusContinuous

/*
 * Stop the interface
 */
void regStopContinuous(void) {
} // regStopContinuous

/*
 * Get the test result
 *
 * Return -- boolean indicating success
 */
int regGetResult(void) {
  unsigned int val; 
  int i;
  int vals[REG_TEST_SIZE];
  int ok = 1;

  // Generate random values and write them to the test registers
  for (i = 0; i < REG_TEST_SIZE; i++) {
    vals[i] = rand();
    writeReg(&nf2, REG_FILE_BASE_ADDR_REG + i * 4, vals[i]);
  }

  // Read the values back to check for errors
  for (i = 0; i < REG_TEST_SIZE; i++) {
    readReg(&nf2, REG_FILE_BASE_ADDR_REG + i * 4, &val);
    if (val != vals[i]) {
      ok = 0;
    }
  }

  return ok;
} // regGetResult
