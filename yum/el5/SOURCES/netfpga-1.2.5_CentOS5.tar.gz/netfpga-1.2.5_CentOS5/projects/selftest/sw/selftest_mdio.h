/* ****************************************************************************
 * vim:set shiftwidth=2 softtabstop=2 expandtab:
 * $Id: selftest_mdio.h 3046 2007-12-05 00:35:55Z g9coving $
 *
 * Module: selftest_mdio.h
 * Project: NetFPGA selftest
 * Description: MDIO selftest module
 *
 * Change history:
 *
 */

#ifndef _SELFTEST_MDIO_H
#define _SELFTEST_MDIO_H	1

#define MDIO_READ_RETRIES 20 
#define NUM_PHY           4

void mdioResetContinuous(void);
int mdioShowStatusContinuous(void);
void mdioStopContinuous(void);
int mdioGetResult(void);

#endif
