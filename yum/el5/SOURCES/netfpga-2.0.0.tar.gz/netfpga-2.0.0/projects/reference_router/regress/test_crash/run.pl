#!/usr/bin/perl

system 'nice -n -19 ./crash.pl --len 1496 --pkts 200';
