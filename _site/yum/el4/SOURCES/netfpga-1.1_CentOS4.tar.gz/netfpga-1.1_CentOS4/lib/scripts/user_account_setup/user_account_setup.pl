#!/usr/bin/perl -w

#
# Script to copy the NetFPGA files to the user account and 
# create the enviornment variables
# $Id: user_account_setup.pl gac1 $
#

use strict;

print "Copying the NF2 directory to your user account\n";
`cp -r /usr/local/NF2 ~`;

print "Adding the NetFPGA Enviornment Variables to your .bashrc\n";
`cat /usr/local/NF2/bashrc_addon >> ~/.basrc`;
