/* ****************************************************************************
 * $Id: regdump.c 1593 2007-04-04 05:31:05Z jnaous $
 *
 * Module: regdump.c
 * Project: NetFPGA 2.1 reference
 * Description: Test program to dump the switch registers
 *
 * Change history:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>

#include <net/if.h>

#include <time.h>

#include "../common/reg_defines.h"
#include "../common/nf2util.h"

#define PATHLEN		80

#define DEFAULT_IFACE	"nf2c0"

/* Global vars */
static struct nf2device nf2;
static int verbose = 0;
static int force_cnet = 0;

/* Function declarations */
void print (void);

int main(int argc, char *argv[])
{
	unsigned val;

	nf2.device_name = DEFAULT_IFACE;

	printf("hi\n");

	if (check_iface(&nf2))
	{
		exit(1);
	}
	if (openDescriptor(&nf2))
	{
		exit(1);
	}

	print();

	closeDescriptor(&nf2);

	return 0;
}

void print(void) {
	unsigned val, i;

	//	readReg(&nf2, UNET_ID, &val);
	//	printf("Board ID: Version %i, Device %i\n", GET_VERSION(val), GET_DEVICE(val));
	readReg(&nf2, MAC_GRP_0_CONTROL_REG, &val);
	printf("MAC 0 Control: 0x%08x ", val);
	if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("TX disabled, ");
	}
	else {
	  printf("TX enabled,  ");
	}
	if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("RX disabled, ");
	}
	else {
	  printf("RX enabled,  ");
	}
	if(val&(1<<RESET_MAC_BIT_NUM)) {
	  printf("reset on,    ");
	}
	else {
	  printf("reset off,   ");
	}
	printf("mac config 0x%02x\n", val>>MAC_CONFIG_BIT_NUM);

	readReg(&nf2, RX_QUEUE_0_NUM_PKTS_STORED_REG, &val);
	printf("Num pkts stored in rx queue 0:      %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_PKTS_DROPPED_FULL_REG, &val);
	printf("Num pkts dropped (rx queue 0 full): %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_PKTS_DROPPED_BAD_REG, &val);
	printf("Num pkts dropped (bad fcs q 0):     %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of rx queue 0: %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of rx queue 0: %u\n", val);
	readReg(&nf2, TX_QUEUE_0_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in tx queue 0:             %u\n", val);
	readReg(&nf2, TX_QUEUE_0_NUM_PKTS_SENT_REG, &val);
	printf("Num pkts sent tx queue 0:           %u\n", val);
	readReg(&nf2, TX_QUEUE_0_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of tx queue 0: %u\n", val);
	readReg(&nf2, TX_QUEUE_0_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of tx queue 0: %u\n\n", val);

	readReg(&nf2, MAC_GRP_1_CONTROL_REG, &val);
	printf("MAC 1 Control: 0x%08x ", val);
	if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("TX disabled, ");
	}
	else {
	  printf("TX enabled,  ");
	}
	if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("RX disabled, ");
	}
	else {
	  printf("RX enabled,  ");
	}
	if(val&(1<<RESET_MAC_BIT_NUM)) {
	  printf("reset on,    ");
	}
	else {
	  printf("reset off,   ");
	}
	printf("mac config 0x%02x\n", val>>MAC_CONFIG_BIT_NUM);
	readReg(&nf2, RX_QUEUE_1_NUM_PKTS_STORED_REG, &val);
	printf("Num pkts stored in rx queue 1:      %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_PKTS_DROPPED_FULL_REG, &val);
	printf("Num pkts dropped (rx queue 1 full): %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_PKTS_DROPPED_BAD_REG, &val);
	printf("Num pkts dropped (bad fcs q 1):     %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of rx queue 1: %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of rx queue 1: %u\n", val);
	readReg(&nf2, TX_QUEUE_1_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in tx queue 1:             %u\n", val);
	readReg(&nf2, TX_QUEUE_1_NUM_PKTS_SENT_REG, &val);
	printf("Num pkts sent tx queue 1:           %u\n", val);
	readReg(&nf2, TX_QUEUE_1_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of tx queue 1: %u\n", val);
	readReg(&nf2, TX_QUEUE_1_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of tx queue 1: %u\n\n", val);

	readReg(&nf2, MAC_GRP_2_CONTROL_REG, &val);
	printf("MAC 2 Control: 0x%08x ", val);
	if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("TX disabled, ");
	}
	else {
	  printf("TX enabled,  ");
	}
	if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("RX disabled, ");
	}
	else {
	  printf("RX enabled,  ");
	}
	if(val&(1<<RESET_MAC_BIT_NUM)) {
	  printf("reset on,    ");
	}
	else {
	  printf("reset off,   ");
	}
	readReg(&nf2, RX_QUEUE_2_NUM_PKTS_STORED_REG, &val);
	printf("Num pkts stored in rx queue 2:      %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_PKTS_DROPPED_FULL_REG, &val);
	printf("Num pkts dropped (rx queue 2 full): %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_PKTS_DROPPED_BAD_REG, &val);
	printf("Num pkts dropped (bad fcs q 2):     %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of rx queue 2: %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of rx queue 2: %u\n", val);
	readReg(&nf2, TX_QUEUE_2_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in tx queue 2:             %u\n", val);
	readReg(&nf2, TX_QUEUE_2_NUM_PKTS_SENT_REG, &val);
	printf("Num pkts sent tx queue 2:           %u\n", val);
	readReg(&nf2, TX_QUEUE_2_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of tx queue 2: %u\n", val);
	readReg(&nf2, TX_QUEUE_2_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of tx queue 2: %u\n\n", val);

	readReg(&nf2, MAC_GRP_3_CONTROL_REG, &val);
	printf("MAC 3 Control: 0x%08x ", val);
	if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("TX disabled, ");
	}
	else {
	  printf("TX enabled,  ");
	}
	if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("RX disabled, ");
	}
	else {
	  printf("RX enabled,  ");
	}
	if(val&(1<<RESET_MAC_BIT_NUM)) {
	  printf("reset on,    ");
	}
	else {
	  printf("reset off,   ");
	}
	readReg(&nf2, RX_QUEUE_3_NUM_PKTS_STORED_REG, &val);
	printf("Num pkts stored in rx queue 3:      %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_PKTS_DROPPED_FULL_REG, &val);
	printf("Num pkts dropped (rx queue 3 full): %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_PKTS_DROPPED_BAD_REG, &val);
	printf("Num pkts dropped (bad fcs q 3):     %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of rx queue 3: %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of rx queue 3: %u\n", val);
	readReg(&nf2, TX_QUEUE_3_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in tx queue 3:             %u\n", val);
	readReg(&nf2, TX_QUEUE_3_NUM_PKTS_SENT_REG, &val);
	printf("Num pkts sent tx queue 3:           %u\n", val);
	readReg(&nf2, TX_QUEUE_3_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of tx queue 3: %u\n", val);
	readReg(&nf2, TX_QUEUE_3_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of tx queue 3: %u\n\n", val);

	readReg(&nf2, SWITCH_OP_LUT_NUM_HITS_REG, &val);
	printf("MAC lut num hits:                   %u\n", val);
	readReg(&nf2, SWITCH_OP_LUT_NUM_MISSES_REG, &val);
	printf("MAC lut num misses:                 %u\n\n", val);
	for(i=0; i<16; i=i+1){
	  writeReg(&nf2, SWITCH_OP_LUT_MAC_LUT_RD_ADDR_REG, i);
	  readReg(&nf2, SWITCH_OP_LUT_PORTS_MAC_HI_REG, &val);
	  printf("   CAM table entry %02u: wr_protect: %u, ports: 0x%04x, mac: 0x%04x", i, val>>31, (val&0x7fff0000)>>16, (val&0xffff));
	  readReg(&nf2, SWITCH_OP_LUT_MAC_LO_REG, &val);
	  printf("%08x\n", val);
	}

	readReg(&nf2, IN_ARB_NUM_PKTS_SENT_REG, &val);
	printf("IN_ARB_NUM_PKTS_SENT_REG                  %u\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_WORD_0_LO_REG, &val);
	printf("IN_ARB_LAST_PKT_WORD_0_LO_REG             %08x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_WORD_0_HI_REG, &val);
	printf("IN_ARB_LAST_PKT_WORD_0_HI_REG             %08x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_CTRL_0_REG, &val);
	printf("IN_ARB_LAST_PKT_CTRL_0_REG                %02x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_WORD_1_LO_REG, &val);
	printf("IN_ARB_LAST_PKT_WORD_1_LO_REG             %08x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_WORD_1_HI_REG, &val);
	printf("IN_ARB_LAST_PKT_WORD_1_HI_REG             %08x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_CTRL_1_REG, &val);
	printf("IN_ARB_LAST_PKT_CTRL_1_REG                %02x\n", val);
	readReg(&nf2, IN_ARB_STATE_REG, &val);
	printf("IN_ARB_STATE_REG                          %u\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_0, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_0                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_0, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_0             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_0, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_0        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_0, &val);
	printf("OQ_NUM_PKTS_STORED_REG_0                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_0, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_0                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_0, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_0            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_0, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_0       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_0, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_0                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_0, &val);
	printf("OQ_ADDRESS_HI_REG_0                       %08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_0, &val);
	printf("OQ_ADDRESS_LO_REG_0                       %08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_0, &val);
	printf("OQ_WR_ADDRESS_REG_0                       %08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_0, &val);
	printf("OQ_RD_ADDRESS_REG_0                       %08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_0, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_0                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_0, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_0                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_0, &val);
	printf("OQ_CONTROL_REG_0                          %x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_1, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_1                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_1, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_1             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_1, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_1        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_1, &val);
	printf("OQ_NUM_PKTS_STORED_REG_1                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_1, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_1                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_1, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_1            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_1, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_1       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_1, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_1                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_1, &val);
	printf("OQ_ADDRESS_HI_REG_1                       %08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_1, &val);
	printf("OQ_ADDRESS_LO_REG_1                       %08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_1, &val);
	printf("OQ_WR_ADDRESS_REG_1                       %08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_1, &val);
	printf("OQ_RD_ADDRESS_REG_1                       %08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_1, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_1                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_1, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_1                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_1, &val);
	printf("OQ_CONTROL_REG_1                          %x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_2, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_2                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_2, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_2             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_2, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_2        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_2, &val);
	printf("OQ_NUM_PKTS_STORED_REG_2                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_2, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_2                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_2, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_2            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_2, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_2       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_2, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_2                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_2, &val);
	printf("OQ_ADDRESS_HI_REG_2                       %08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_2, &val);
	printf("OQ_ADDRESS_LO_REG_2                       %08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_2, &val);
	printf("OQ_WR_ADDRESS_REG_2                       %08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_2, &val);
	printf("OQ_RD_ADDRESS_REG_2                       %08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_2, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_2                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_2, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_2                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_2, &val);
	printf("OQ_CONTROL_REG_2                          %x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_3, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_3                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_3, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_3             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_3, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_3        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_3, &val);
	printf("OQ_NUM_PKTS_STORED_REG_3                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_3, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_3                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_3, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_3            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_3, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_3       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_3, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_3                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_3, &val);
	printf("OQ_ADDRESS_HI_REG_3                       %08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_3, &val);
	printf("OQ_ADDRESS_LO_REG_3                       %08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_3, &val);
	printf("OQ_WR_ADDRESS_REG_3                       %08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_3, &val);
	printf("OQ_RD_ADDRESS_REG_3                       %08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_3, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_3                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_3, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_3                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_3, &val);
	printf("OQ_CONTROL_REG_3                          %x\n\n", val);
}
