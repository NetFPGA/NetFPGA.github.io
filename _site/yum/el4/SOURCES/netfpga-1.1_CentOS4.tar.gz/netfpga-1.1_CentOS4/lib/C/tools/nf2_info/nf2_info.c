/* ****************************************************************************
 * vim:set shiftwidth=2 softtabstop=2 expandtab:
 * $Id: nf2_info.c 1908 2007-07-10 20:36:13Z grg $
 *
 * Module: regdump.c
 * Project: NetFPGA 2 Linux Kernel Driver
 * Description: Test program to dump the CPCI registers
 *
 * Change history:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>

#include <net/if.h>

#include "../../common/nf2.h"
#include "../../common/nf2util.h"

#define PATHLEN		80

#define DEFAULT_IFACE	"nf2c0"

#define DEVICE_STR_LEN 120

#define NF2_DEVICE_ID   0x0400000
#define NF2_VERSION     0x0400004
#define NF2_DEVICE_STR  0x0400008

/* Global vars */
static struct nf2device nf2;
static int verbose = 0;

static unsigned nf2_version;
static unsigned nf2_device_id;
static char nf2_device_str[DEVICE_STR_LEN];

/* Function declarations */
void processArgs (int , char **);
void usage (void);
void read_info (void);
void display_info (void);

int main(int argc, char *argv[])
{
  unsigned val;

  nf2.device_name = DEFAULT_IFACE;


  processArgs(argc, argv);
  if (check_iface(&nf2))
  {
    exit(1);
  }
  if (openDescriptor(&nf2))
  {
    exit(1);
  }

  //printCPCIRegisters();
  //readReg(&nf2, CPCI_REG_BOARD_ID, &val);
  //if (NF2_GET_CONTROL(val) || force_cnet)
  //  printCNETRegisters();
  read_info();
  display_info();

  closeDescriptor(&nf2);

  return 0;
}


/* 
 *  Read the version info from the board
 */
void read_info(void)
{
  int i;

  // Read the version and revision
  readReg(&nf2, NF2_DEVICE_ID, &nf2_device_id);
  readReg(&nf2, NF2_VERSION, &nf2_version);

  // Read the version string
  for (i = 0; i < (DEVICE_STR_LEN / 4) - 2; i++)
  {
    readReg(&nf2, NF2_DEVICE_STR + i * 4, (unsigned *)(nf2_device_str + i * 4));
  }
  nf2_device_str[DEVICE_STR_LEN - 1] = '\0';
}


/* 
 *  Display the version info
 */
void display_info(void)
{
  printf("NF2 device ID: %d %08x\n", nf2_device_id, nf2_device_id);
  printf("NF2 version: %d\n", nf2_version);
  printf("NF2 device string: %s\n", nf2_device_str);
}



/* 
 *  Process the arguments.
 */
void processArgs (int argc, char **argv )
{
  char c;

  /* don't want getopt to moan - I can do that just fine thanks! */
  opterr = 0;

  while ((c = getopt (argc, argv, "i:vh")) != -1)
  {
    switch (c)
    {
      case 'v':	/* Verbose */
        verbose = 1;
        break;
      case 'i':	/* interface name */
        nf2.device_name = optarg;
        break;
      case '?':
        if (isprint (optopt))
          fprintf (stderr, "Unknown option `-%c'.\n", optopt);
        else
          fprintf (stderr,
                  "Unknown option character `\\x%x'.\n",
                  optopt);
        // Let this fall through to the usage

      case 'h':
      default:
        usage();
        exit(1);
    }
  }
}


/*
 *  Describe usage of this program.
 */
void usage (void)
{
  printf("Usage: ./nf2_info <options> \n\n");
  printf("Options: -i <iface> : interface name (default nf2c0)\n");
  printf("         -v : be verbose.\n");
  printf("         -h : Print this message and exit.\n");
}
