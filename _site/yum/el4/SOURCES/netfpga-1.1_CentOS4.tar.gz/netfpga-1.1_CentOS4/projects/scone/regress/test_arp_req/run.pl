#!/usr/bin/perl
# Author: Sara Bolouki
# Date: 11/14/2007

# Objective:
# Send a packet in to the software component that will not get an rtable hit
# and confirm that it generates an arp request

use Error qw(:try);
use IO::Socket;
use NF2::TestLib;
use NF2::PacketLib;
use strict;    

# Move to SCONE's root directory
chdir '../../sw' or die "Can't cd: $!\n";

my $pid;

# Fork off a process for SCONE
if ( !( $pid = fork ) ) {

	# Run SCONE from this process
	exec "./scone", "-r", "rtable.netfpga";
	die "Failed to launch SCONE: $!";
}
else {
	my $exitCode = 1;
	try {

		# Run control from this process

		# Wait for router to initialize
		sleep(1);

		# launch PCAP listenting to eth1, eth2
		my @interfaces = ( "eth1", "eth2" );
		nftest_init( \@ARGV, \@interfaces );
		nftest_start( \@interfaces );

		my $nf2c0_mac  = "00:00:00:00:00:01";
		my $nf2c1_mac  = "00:00:00:00:00:02";
		my $bogus_mac0 = "aa:bb:cc:dd:ee:f0";
		my $bogus_mac1 = "ca:fe:f0:0d:00:00";

		my $nf2c0_ip  = "192.168.0.2";
		my $nf2c1_ip  = "192.168.1.2";
		my $bogus_ip0 = "192.168.0.100";
		my $bogus_ip1 = "192.168.1.100";
		my $ttl       = 40;
		my $BCAST_MAC = "ff:ff:ff:ff:ff:ff";

		# Creat the expeted ARP request on eth2
		my $arp_req_pkt = NF2::ARP_pkt->new(
			DA            => $BCAST_MAC,
			SA            => $nf2c1_mac,
			Op            => 0x1,
			SenderIpAddr  => $nf2c1_ip,
			SenderEthAddr => $nf2c1_mac,
			TargetIpAddr  => $bogus_ip1,
			len           => 56
		);

		# Listen for  arp request on eth2
		nftest_expect( 'eth2', $arp_req_pkt->packed );

		# Create the main packet
		my $pkt = NF2::IP_pkt->new(
			DA     => $nf2c0_mac,
			SA     => $bogus_mac0,
			ttl    => $ttl,
			src_ip => $bogus_ip0,
			dst_ip => $bogus_ip1,
			len    => 60
		);

		# send pkt eth1->nf2c0
		nftest_send( 'eth1', $pkt->packed );

		# Ignore OSPF Packets and ARP Requests
		nftest_ignore_ospf( "eth1", "eth2" );

		#nftest_ignore_arp_request("eth2");

		# Sleep for 1 second
		sleep(1);

		# Finish and print errors, if any
		my $total_errors = nftest_print_errors( nftest_finish() );

		if ( $total_errors == 0 ) {
			print "SUCCESS!\n";
			$exitCode = 0;
		}
		else {
			print "FAIL: $total_errors errors\n";
			$exitCode = 1;
		}
	}
	catch Error with {

		# Catch and print any errors that occurred during control processing
		my $ex = shift;
		if ($ex) {
			print $ex->stringify();
		}
	}
	finally {

		# Ensure SCONE is killed even if we have an error
		kill 9, $pid;

		# Exit with the resulting exit code
		exit($exitCode);
	};
}
