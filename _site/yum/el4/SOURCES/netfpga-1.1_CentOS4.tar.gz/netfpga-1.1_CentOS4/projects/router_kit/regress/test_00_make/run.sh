#!/bin/sh

cd ../../sw
make
