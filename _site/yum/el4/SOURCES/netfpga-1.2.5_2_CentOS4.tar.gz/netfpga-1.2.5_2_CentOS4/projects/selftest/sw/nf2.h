/* ****************************************************************************
 * $Id: nf2.h 4196 2008-06-23 23:12:37Z grg $
 *
 * Module: nf2.h
 * Project: NetFPGA 2 Linux Kernel Driver
 * Description: Header file for kernel driver
 *
 * Change history:
 *
 */

#ifndef _NF2_H
#define _NF2_H	1

#define NF2_DEV_NAME	"nf2"

/* Include for socket IOCTLs */
#include <linux/sockios.h>
#include "../../../lib/C/common/reg_defines.h"

/* Maximum number of interfaces */
#ifndef MAX_IFACE
#define MAX_IFACE	4
#endif

// MDIO register base
#define MDIO_OFFSET			(MDIO_1_CONTROL_REG - MDIO_0_CONTROL_REG)

// serial_ctrl bits
#define SERIAL_USR_RESET_BIT_NUM           0
// serial stat bits
#define SERIAL_LANE_UP_BIT_NUM             0
#define SERIAL_CHANNEL_UP_BIT_NUM          1
#define SERIAL_HARD_ERROR_BIT_NUM          2
#define SERIAL_SOFT_ERROR_BIT_NUM          3
#define SERIAL_FRAME_ERROR_BIT_NUM         4
#define SERIAL_ERROR_COUNT_BIT_NUM         8
#define SERIAL_ERROR_COUNT_MASK            0x000000ff
// serial test ctrl bits
#define SERIAL_TEST_RESTART_BIT_NUM        0
#define SERIAL_TEST_NONSTOP_BIT_NUM        1
// serial test stat bits
#define SERIAL_TEST_SUCCESSFUL_BIT_NUM     0
#define SERIAL_TEST_DONE_BIT_NUM           1
#define SERIAL_TEST_RUNNING_BIT_NUM        2
#define SERIAL_TEST_COUNT_BIT_NUM          3

/* CPCI registers */
#define CPCI_REG_ID			0x000
#define CPCI_REG_BOARD_ID		0x004
#define CPCI_REG_CTRL			0x008
#define CPCI_REG_RESET			0x00c
#define CPCI_REG_ERROR			0x010
#define CPCI_REG_DUMMY			0x020
#define CPCI_REG_INTERRUPT_MASK		0x040
#define CPCI_REG_INTERRUPT_STATUS	0x044
#define CPCI_NF2_CLK_SEL		0x050
#define CPCI_REG_PROG_DATA		0x100
#define CPCI_REG_PROG_STATUS		0x104
#define CPCI_REG_PROG_CTRL		0x108
#define CPCI_REG_DMA_I_ADDR		0x140
#define CPCI_REG_DMA_E_ADDR		0x144
#define CPCI_REG_DMA_I_SIZE		0x148
#define CPCI_REG_DMA_E_SIZE		0x14c
#define CPCI_REG_DMA_I_CTRL		0x150
#define CPCI_REG_DMA_E_CTRL		0x154
#define CPCI_REG_DMA_MAX_XFER_TIME	0x180
#define CPCI_REG_DMA_MAX_RETRIES	0x184
#define CPCI_REG_CNET_MAX_XFER_TIME	0x188
#define CPCI_REG_DMA_I_PKT_CNT		0x400
#define CPCI_REG_DMA_E_PKT_CNT		0x404
#define CPCI_REG_CPCI_REG_RD_CNT	0x408
#define CPCI_REG_CPCI_REG_WR_CNT	0x40c
#define CPCI_REG_CNET_REG_RD_CNT	0x410
#define CPCI_REG_CNET_REG_WR_CNT	0x414

/* Base address for CNET registers */
#define PHY_REG_BASE			0x600000

#define PHY_REG_CMD			(PHY_REG_BASE)
#define PHY_REG_STATUS			(PHY_REG_BASE)

/* Phy register masks */
#define PHY_RD_WR			0x80000000
#define PHY_PHY				0x03000000
#define PHY_ADDR			0x001F0000
#define PHY_DATA			0x0000FFFF

#define PHY_DONE			0x80000000
#define PHY_DONE_CNT			0x001F0000


#define GET_VERSION(x)			(x & 0xFFFF)
#define GET_DEVICE(x)			((x >> 16) & 0xFFFF)

#define GET_PORT(x)			((x >> 16) & 0xFFFF)
#define GET_LENGTH(x)			(x & 0xFFFF)

#define GET_NEARLY_FULL(x)		(x >> 31)
#define GET_FULL(x)			((x >> 16) & 0x1)
#define GET_EMPTY(x)			((x >> 8) & 0x1)
#define GET_WAITING(x)			(x & 0x1)

#define GET_SEND(x)			((x >> 1) & 0x1)
#define GET_RECEIVE(x)			(x & 0x1)

// SRAM cpu direct access base address 
#define NF2_SRAM_1_BASE                   0xC00000
#define NF2_SRAM_2_BASE                   0xE00000

// Normal function register base address 
#define NF2_REG_FUNC_BASE                (UNET_REG_BASE + 0x1400) 

// individual registers in normal function register block 
#define NF2_REG_FUNC_SRAM_1_MSB_RD        (NF2_REG_FUNC_BASE + 0x0)
#define NF2_REG_FUNC_SRAM_1_MSB_WR        (NF2_REG_FUNC_BASE + 0x4)
#define NF2_REG_FUNC_SRAM_2_MSB_RD        (NF2_REG_FUNC_BASE + 0x8)
#define NF2_REG_FUNC_SRAM_2_MSB_WR        (NF2_REG_FUNC_BASE + 0xC)

/* 
 * Structure for transferring register data via an IOCTL
 */
struct nf2reg {
	unsigned int	reg;
	unsigned int	val;
};

#endif
