#
# Library of test functions for regression tests
#

# Map file
MAP=

# Process the command line arguments
function processArgs () {
	# Note that we use `"$@"' to let each command-line parameter expand to a 
	# separate word. The quotes around `$@' are essential!
	# We need TEMP as the `eval set --' would nuke the return value of getopt.
	TEMP=`getopt -o ? --long map: -n "$0" -- "$@"`

	if [ $? != 0 ] ; then echo "Terminating..." >&2 ; exit 1 ; fi

	# Note the quotes around `$TEMP': they are essential!
	eval set -- "$TEMP"

	while true ; do
		case "$1" in
			--map) readMap $2 ; shift 2 ;;
			--) shift ; break ;;
			*) echo "Internal error!" ; exit 1 ;;
		esac
	done
}

# Read in a mapping file
function readMap () {
	# Verify that the file exists
	if [ ! -f "$1" ] ; then
		echo "Error: Cannot locate '$1'"
		exit 1
	fi

	# Process the file line by line
	POS=0
	for LINE in `cat "$1" | sed 's/#.*//' | sed 's/ //g'` ; do
		MAP[$POS]=$LINE
		POS=`expr $POS + 1`
	done
}

# Get an interface mapping
function getIface () {
	if [ $# -ne 1 ] ; then
		echo "Error: getIface takes exactly one argument (at TestLib.sh:$LINENO)"
		exit 1
	fi

	# Try to find the port name in the mapping list
	MAPSIZE=${#MAP[*]}
	for ((i=0;i<$MAPSIZE;i++)) ; do
		LINE=${MAP[${i}]}
		if [ `echo "$LINE" | grep "^$1:"` ] ; then
			RESULT=`echo "$LINE" | awk -F : '{ print $2 }' `
			IFACE=$RESULT
			return
		fi
	done

	# If we get to here then we didn't find a mapping so just return the original name
	IFACE=$1
}
