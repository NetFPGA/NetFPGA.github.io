/* ****************************************************************************
 * $Id: show_stats.c 3546 2008-04-03 00:12:27Z grg $
 *
 * Module: show_stats.c
 * Project: NetFPGA 2. Yashar's buffer sizing project
 * Description: Display current stats
 *
 * Change history:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>

#include <net/if.h>

#include <time.h>

#include "../common/reg_defines.h"
#include "../common/nf2util.h"
#include <curses.h>

#define PATHLEN		80

#define DEFAULT_IFACE	"nf2c0"

/* Global vars */
static struct nf2device nf2;
static int verbose = 0;
static int force_cnet = 0;

/* Function declarations */
void show_stats (void);

WINDOW *w;

static unsigned int lost[8],stored[8], removed[8];

int main(int argc, char *argv[])
{
	unsigned val;

        for (val=0;val<8;val++) { lost[val] = 0; stored[val]=0; removed[val]=0; }

	nf2.device_name = DEFAULT_IFACE;

	if (check_iface(&nf2))
	{
		exit(1);
	}
	if (openDescriptor(&nf2))
	{
		exit(1);
	}

        w = initscr(); cbreak(); noecho();

	show_stats();

	closeDescriptor(&nf2);

	endwin();

	return 0;
}

void show_stats(void) {
   unsigned val;
   unsigned lo_addr[8], hi_addr[8];
   unsigned i;

   while (1) {

      move(5,0);

      readReg(&nf2, MAC_GRP_0_CONTROL_REG, &val);
      printw("MAC 0 Control: 0x%08x ", val);
      if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
         printw("TX disabled, ");
      }
      else {
         printw("TX enabled,  ");
      }
      if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
         printw("RX disabled, ");
      }
      else {
         printw("RX enabled,  ");
      }
      if(val&(1<<RESET_MAC_BIT_NUM)) {
         printw("reset on,    ");
      }
      else {
         printw("reset off,   ");
      }
      printw("mac config 0x%02x\n", val>>MAC_DISABLE_TX_BIT_NUM);

      readReg(&nf2, MAC_GRP_1_CONTROL_REG, &val);
      printw("MAC 1 Control: 0x%08x ", val);
      if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
         printw("TX disabled, ");
      }
      else {
         printw("TX enabled,  ");
      }
      if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
         printw("RX disabled, ");
      }
      else {
         printw("RX enabled,  ");
      }
      if(val&(1<<RESET_MAC_BIT_NUM)) {
         printw("reset on,    ");
      }
      else {
         printw("reset off,   ");
      }
      printw("mac config 0x%02x\n", val>>MAC_DISABLE_TX_BIT_NUM);

      readReg(&nf2, MAC_GRP_2_CONTROL_REG, &val);
      printw("MAC 2 Control: 0x%08x ", val);
      if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
         printw("TX disabled, ");
      }
      else {
         printw("TX enabled,  ");
      }
      if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
         printw("RX disabled, ");
      }
      else {
         printw("RX enabled,  ");
      }
      if(val&(1<<RESET_MAC_BIT_NUM)) {
         printw("reset on,    ");
      }
      else {
         printw("reset off,   ");
      }
      printw("mac config 0x%02x\n", val>>MAC_DISABLE_TX_BIT_NUM);

      readReg(&nf2, MAC_GRP_3_CONTROL_REG, &val);
      printw("MAC 3 Control: 0x%08x ", val);
      if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
         printw("TX disabled, ");
      }
      else {
         printw("TX enabled,  ");
      }
      if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
         printw("RX disabled, ");
      }
      else {
         printw("RX enabled,  ");
      }
      if(val&(1<<RESET_MAC_BIT_NUM)) {
         printw("reset on,    ");
      }
      else {
         printw("reset off,   ");
      }
      printw("mac config 0x%02x\n", val>>MAC_DISABLE_TX_BIT_NUM);

      move (12,0);
      printw("                   Port 0    CPU 0   Port 1    CPU 1   Port 2    CPU 2   Port 3    CPU 3\n");
      printw("Packets Lost:\n");
      printw("Packets Stored:\n");
      printw("Packets Removed:\n");   
      printw("Bytes Stored:\n");
      printw("Bytes Removed:\n");
      printw("Low address:\n");
      printw("High address:\n");
      printw("Write address:\n");
      printw("Read address:\n");

      move (13,17);
      readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_0, &val); lost[0] = val;
      printw("%8i", lost[0]);
      readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_1, &val);lost[1] = val;
      printw(" %8i", lost[1]);
      readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_2, &val);lost[2] = val;
      printw(" %8i", lost[2]);
      readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_3, &val);lost[3] = val;
      printw(" %8i", lost[3]);
      readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_4, &val);lost[4] = val;
      printw(" %8i", lost[4]);
      readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_5, &val);lost[5] = val;
      printw(" %8i", lost[5]);
      readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_6, &val);lost[6] = val;
      printw(" %8i", lost[6]);
      readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_7, &val);lost[7] = val;
      printw(" %8i", lost[7]);

      move (14,17);
      readReg(&nf2, OQ_NUM_PKTS_STORED_REG_0, &val);stored[0] = val;
      printw("%8i", stored[0]);
      readReg(&nf2, OQ_NUM_PKTS_STORED_REG_1, &val);stored[1] = val;
      printw(" %8i", stored[1]);
      readReg(&nf2, OQ_NUM_PKTS_STORED_REG_2, &val);stored[2] = val;
      printw(" %8i", stored[2]);
      readReg(&nf2, OQ_NUM_PKTS_STORED_REG_3, &val);stored[3] = val;
      printw(" %8i", stored[3]);
      readReg(&nf2, OQ_NUM_PKTS_STORED_REG_4, &val);stored[4] = val;
      printw(" %8i", stored[4]);
      readReg(&nf2, OQ_NUM_PKTS_STORED_REG_5, &val);stored[5] = val;
      printw(" %8i", stored[5]);
      readReg(&nf2, OQ_NUM_PKTS_STORED_REG_6, &val);stored[6] = val;
      printw(" %8i", stored[6]);
      readReg(&nf2, OQ_NUM_PKTS_STORED_REG_7, &val);stored[7] = val;
      printw(" %8i", stored[7]);

      move (15,17);
      readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_0, &val);removed[0] = val;
      printw("%8i", removed[0]);
      readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_1, &val);removed[1] = val;
      printw(" %8i", removed[1]);
      readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_2, &val);removed[2] = val;
      printw(" %8i", removed[2]);
      readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_3, &val);removed[3] = val;
      printw(" %8i", removed[3]);
      readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_4, &val);removed[4] = val;
      printw(" %8i", removed[4]);
      readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_5, &val);removed[5] = val;
      printw(" %8i", removed[5]);
      readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_6, &val);removed[6] = val;
      printw(" %8i", removed[6]);
      readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_7, &val);removed[7] = val;
      printw(" %8i", removed[7]);

      move (16,17);
      readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_0, &val);
      printw("%8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_1, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_2, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_3, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_4, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_5, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_6, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_7, &val);
      printw(" %8i", val);

      move (17,17);
      readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_0, &val);
      printw("%8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_1, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_2, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_3, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_4, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_5, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_6, &val);
      printw(" %8i", val);
      readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_7, &val);
      printw(" %8i", val);

      move (18,17);
      readReg(&nf2, OQ_ADDRESS_LO_REG_0, &val);lo_addr[0] = val;
      printw("%8x", lo_addr[0]<<3);
      readReg(&nf2, OQ_ADDRESS_LO_REG_1, &val);lo_addr[1] = val;
      printw(" %8x", lo_addr[1]<<3);
      readReg(&nf2, OQ_ADDRESS_LO_REG_2, &val);lo_addr[2] = val;
      printw(" %8x", lo_addr[2]<<3);
      readReg(&nf2, OQ_ADDRESS_LO_REG_3, &val);lo_addr[3] = val;
      printw(" %8x", lo_addr[3]<<3);
      readReg(&nf2, OQ_ADDRESS_LO_REG_4, &val);lo_addr[4] = val;
      printw(" %8x", lo_addr[4]<<3);
      readReg(&nf2, OQ_ADDRESS_LO_REG_5, &val);lo_addr[5] = val;
      printw(" %8x", lo_addr[5]<<3);
      readReg(&nf2, OQ_ADDRESS_LO_REG_6, &val);lo_addr[6] = val;
      printw(" %8x", lo_addr[6]<<3);
      readReg(&nf2, OQ_ADDRESS_LO_REG_7, &val);lo_addr[7] = val;
      printw(" %8x", lo_addr[7]<<3);

      move (19,17);
      readReg(&nf2, OQ_ADDRESS_HI_REG_0, &val);hi_addr[0] = val;
      printw("%8x", hi_addr[0]<<3);
      readReg(&nf2, OQ_ADDRESS_HI_REG_1, &val);hi_addr[1] = val;
      printw(" %8x", hi_addr[1]<<3);
      readReg(&nf2, OQ_ADDRESS_HI_REG_2, &val);hi_addr[2] = val;
      printw(" %8x", hi_addr[2]<<3);
      readReg(&nf2, OQ_ADDRESS_HI_REG_3, &val);hi_addr[3] = val;
      printw(" %8x", hi_addr[3]<<3);
      readReg(&nf2, OQ_ADDRESS_HI_REG_4, &val);hi_addr[4] = val;
      printw(" %8x", hi_addr[4]<<3);
      readReg(&nf2, OQ_ADDRESS_HI_REG_5, &val);hi_addr[5] = val;
      printw(" %8x", hi_addr[5]<<3);
      readReg(&nf2, OQ_ADDRESS_HI_REG_6, &val);hi_addr[6] = val;
      printw(" %8x", hi_addr[6]<<3);
      readReg(&nf2, OQ_ADDRESS_HI_REG_7, &val);hi_addr[7] = val;
      printw(" %8x", hi_addr[7]<<3);

      move (20,17);
      readReg(&nf2, OQ_WR_ADDRESS_REG_0, &val);
      printw("%8x", val<<3);
      readReg(&nf2, OQ_WR_ADDRESS_REG_1, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_WR_ADDRESS_REG_2, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_WR_ADDRESS_REG_3, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_WR_ADDRESS_REG_4, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_WR_ADDRESS_REG_5, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_WR_ADDRESS_REG_6, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_WR_ADDRESS_REG_7, &val);
      printw(" %8x", val<<3);

      move (21,17);
      readReg(&nf2, OQ_RD_ADDRESS_REG_0, &val);
      printw("%8x", val<<3);
      readReg(&nf2, OQ_RD_ADDRESS_REG_1, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_RD_ADDRESS_REG_2, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_RD_ADDRESS_REG_3, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_RD_ADDRESS_REG_4, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_RD_ADDRESS_REG_5, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_RD_ADDRESS_REG_6, &val);
      printw(" %8x", val<<3);
      readReg(&nf2, OQ_RD_ADDRESS_REG_7, &val);
      printw(" %8x", val<<3);

      move (22,0);
      printw("Size:");
      move (22,16);
      for (i=0;i<8;i++) {
	 printw(" %6iKB", ((hi_addr[i]-lo_addr[i])/128));
      }

	move (24,0);
	readReg(&nf2, SWITCH_OP_LUT_NUM_HITS_REG, &val);
	printw("MAC lut num hits:              %u\n", val);
	readReg(&nf2, SWITCH_OP_LUT_NUM_MISSES_REG, &val);
	printw("MAC lut num misses:            %u\n\n", val);
	for(i=0; i<16; i=i+1){
	  writeReg(&nf2, SWITCH_OP_LUT_MAC_LUT_RD_ADDR_REG, i);
	  readReg(&nf2, SWITCH_OP_LUT_PORTS_MAC_HI_REG, &val);
	  printw("   CAM table entry %02u: wr_protect: %u, ports: 0x%04x, mac: 0x%04x", i, val>>31, (val&0x7fff0000)>>16, (val&0xffff));
	  readReg(&nf2, SWITCH_OP_LUT_MAC_LO_REG, &val);
	  printw("%08x\n", val);
	}


      refresh();

      sleep(1);

   }

}
