/********************************************************
*
* C register defines file for packet_generator
*
********************************************************/

#ifndef _REG_DEFINES_
#define _REG_DEFINES_

/* ========= Constants ========= */

// ===== File: lib/verilog/core/common/xml/global.xml =====

// Maximum number of phy ports
#define MAX_PHY_PORTS                         4

// PCI address bus width
#define PCI_ADDR_WIDTH                        32

// PCI data bus width
#define PCI_DATA_WIDTH                        32

// PCI byte enable bus width
#define PCI_BE_WIDTH                          4

// CPCI--CNET address bus width. This is byte addresses even though bottom bits are zero.
#define CPCI_CNET_ADDR_WIDTH                  27

// CPCI--CNET data bus width
#define CPCI_CNET_DATA_WIDTH                  32

// CPCI--NF2 address bus width. This is byte addresses even though bottom bits are zero.
#define CPCI_NF2_ADDR_WIDTH                   27

// CPCI--NF2 data bus width
#define CPCI_NF2_DATA_WIDTH                   32

// DMA data bus width
#define DMA_DATA_WIDTH                        32

// DMA control bus width
#define DMA_CTRL_WIDTH                        4

// CPCI debug bus width
#define CPCI_DEBUG_DATA_WIDTH                 29

// SRAM address width
#define SRAM_ADDR_WIDTH                       19

// SRAM data width
#define SRAM_DATA_WIDTH                       36

// DRAM address width
#define DRAM_ADDR_WIDTH                       24


// ===== File: lib/verilog/core/common/xml/nf_defines.xml =====

// Clock period of 125 MHz clock in ns
#define FAST_CLK_PERIOD                       8

// Clock period of 62.5 MHz clock in ns
#define SLOW_CLK_PERIOD                       16

// Header value used by the IO queues
#define IO_QUEUE_STAGE_NUM                    0xff

// Data path data width
#define DATA_WIDTH                            64

// Data path control width
#define CTRL_WIDTH                            8


// ===== File: projects/packet_generator/include/sram_rr_output_queues.xml =====

#define NUM_OUTPUT_QUEUES                     12

#define OQ_DEFAULT_MAX_PKTS                   0x7ffff

#define OQ_SRAM_PKT_CNT_WIDTH                 19

#define OQ_SRAM_WORD_CNT_WIDTH                19

#define OQ_SRAM_BYTE_CNT_WIDTH                19

#define OQ_ENABLE_SEND_BIT_NUM                0

#define OQ_INITIALIZE_OQ_BIT_NUM              1

#define OQ_PKT_GEN_ITER_WIDTH                 32


// ===== File: projects/packet_generator/include/rate_limiter.xml =====

// enable bit num
#define RATE_LIMIT_ENABLE_BIT_NUM             0

// overhead bit num
#define RATE_LIMIT_INCLUDE_OVERHEAD_BIT_NUM   1


// ===== File: lib/verilog/core/utils/xml/device_id_reg.xml =====

// Total number of registers
#define DEV_ID_NUM_REGS                       32

// Number of non string registers
#define DEV_ID_NON_DEV_STR_REGS               7

// Device description length (in words, not chars)
#define DEV_ID_DEV_STR_WORD_LEN               25

// Device description length (in bytes/chars)
#define DEV_ID_DEV_STR_BYTE_LEN               100

// Device description length (in bits)
#define DEV_ID_DEV_STR_BIT_LEN                800

// Length of MD5 sum (bits)
#define DEV_ID_MD5SUM_LENGTH                  128

// MD5 sum of the string "device_id.v"
#define DEV_ID_MD5_VALUE                      0x4071736d8a603d2b4d55f62989a73c95
#define DEV_ID_MD5_VALUE_0                    0x4071736d
#define DEV_ID_MD5_VALUE_1                    0x8a603d2b
#define DEV_ID_MD5_VALUE_2                    0x4d55f629
#define DEV_ID_MD5_VALUE_3                    0x89a73c95


// ===== File: lib/verilog/core/io_queues/ethernet_mac/xml/ethernet_mac.xml =====

// TX queue disable bit
#define MAC_GRP_TX_QUEUE_DISABLE_BIT_NUM      0

// RX queue disable bit
#define MAC_GRP_RX_QUEUE_DISABLE_BIT_NUM      1

// Reset MAC bit
#define MAC_GRP_RESET_MAC_BIT_NUM             2

// MAC TX queue disable bit
#define MAC_GRP_MAC_DISABLE_TX_BIT_NUM        3

// MAC RX queue disable bit
#define MAC_GRP_MAC_DISABLE_RX_BIT_NUM        4

// MAC disable jumbo TX bit
#define MAC_GRP_MAC_DIS_JUMBO_TX_BIT_NUM      5

// MAC disable jumbo RX bit
#define MAC_GRP_MAC_DIS_JUMBO_RX_BIT_NUM      6

// MAC disable crc check disable bit
#define MAC_GRP_MAC_DIS_CRC_CHECK_BIT_NUM     7

// MAC disable crc generate bit
#define MAC_GRP_MAC_DIS_CRC_GEN_BIT_NUM       8


// ===== File: projects/packet_generator/include/project.xml =====

// HASH(0x9b73d80)
#define PKT_CAP_DA                            0x000000000001
#define PKT_CAP_DA_HI                         0x00000000
#define PKT_CAP_DA_LO                         0x00000001

// HASH(0x9b7408c)
#define PKT_CAP_SA                            0x000000000002
#define PKT_CAP_SA_HI                         0x00000000
#define PKT_CAP_SA_LO                         0x00000002

// HASH(0x9b74224)
#define PKT_CAP_ETHERTYPE                     0x9001


// -------------------------------------
//   Modules
// -------------------------------------

// Module tags
#define CORE_BASE_ADDR          0x0000000
#define DEV_ID_BASE_ADDR        0x0400000
#define MDIO_BASE_ADDR          0x0440000
#define COUNTER_BASE_ADDR       0x0480000
#define DMA_BASE_ADDR           0x0500000
#define MAC_GRP_0_BASE_ADDR     0x0600000
#define MAC_GRP_1_BASE_ADDR     0x0640000
#define MAC_GRP_2_BASE_ADDR     0x0680000
#define MAC_GRP_3_BASE_ADDR     0x06c0000
#define CPU_QUEUE_0_BASE_ADDR   0x0700000
#define CPU_QUEUE_1_BASE_ADDR   0x0740000
#define CPU_QUEUE_2_BASE_ADDR   0x0780000
#define CPU_QUEUE_3_BASE_ADDR   0x07c0000
#define SRAM_BASE_ADDR          0x1000000
#define UDP_BASE_ADDR           0x2000000
#define OQ_BASE_ADDR            0x2000000
#define IN_ARB_BASE_ADDR        0x2001000
#define DELAY_BASE_ADDR         0x2001100
#define RATE_LIMIT_0_BASE_ADDR  0x2001140
#define RATE_LIMIT_1_BASE_ADDR  0x2001180
#define RATE_LIMIT_2_BASE_ADDR  0x20011c0
#define RATE_LIMIT_3_BASE_ADDR  0x2001200
#define RATE_LIMIT_4_BASE_ADDR  0x2001240
#define RATE_LIMIT_5_BASE_ADDR  0x2001280
#define RATE_LIMIT_6_BASE_ADDR  0x20012c0
#define RATE_LIMIT_7_BASE_ADDR  0x2001300
#define PKT_GEN_BASE_ADDR       0x2001400
#define DRAM_BASE_ADDR          0x4000000

#define CPU_QUEUE_OFFSET    0x0040000
#define MAC_GRP_OFFSET      0x0040000
#define RATE_LIMIT_OFFSET   0x0000040


/* ========== Registers ========== */

// Name: device_id (DEV_ID)
// Description: Device identification
// File: lib/verilog/core/utils/xml/device_id_reg.xml
#define DEV_ID_MD5_0_REG        0x0400000
#define DEV_ID_MD5_1_REG        0x0400004
#define DEV_ID_MD5_2_REG        0x0400008
#define DEV_ID_MD5_3_REG        0x040000c
#define DEV_ID_DEVICE_ID_REG    0x0400010
#define DEV_ID_REVISION_REG     0x0400014
#define DEV_ID_CPCI_ID_REG      0x0400018
#define DEV_ID_DEV_STR_0_REG    0x040001c
#define DEV_ID_DEV_STR_1_REG    0x0400020
#define DEV_ID_DEV_STR_2_REG    0x0400024
#define DEV_ID_DEV_STR_3_REG    0x0400028
#define DEV_ID_DEV_STR_4_REG    0x040002c
#define DEV_ID_DEV_STR_5_REG    0x0400030
#define DEV_ID_DEV_STR_6_REG    0x0400034
#define DEV_ID_DEV_STR_7_REG    0x0400038
#define DEV_ID_DEV_STR_8_REG    0x040003c
#define DEV_ID_DEV_STR_9_REG    0x0400040
#define DEV_ID_DEV_STR_10_REG   0x0400044
#define DEV_ID_DEV_STR_11_REG   0x0400048
#define DEV_ID_DEV_STR_12_REG   0x040004c
#define DEV_ID_DEV_STR_13_REG   0x0400050
#define DEV_ID_DEV_STR_14_REG   0x0400054
#define DEV_ID_DEV_STR_15_REG   0x0400058
#define DEV_ID_DEV_STR_16_REG   0x040005c
#define DEV_ID_DEV_STR_17_REG   0x0400060
#define DEV_ID_DEV_STR_18_REG   0x0400064
#define DEV_ID_DEV_STR_19_REG   0x0400068
#define DEV_ID_DEV_STR_20_REG   0x040006c
#define DEV_ID_DEV_STR_21_REG   0x0400070
#define DEV_ID_DEV_STR_22_REG   0x0400074
#define DEV_ID_DEV_STR_23_REG   0x0400078
#define DEV_ID_DEV_STR_24_REG   0x040007c

// Name: mdio (MDIO)
// Description: MDIO interface
// File: lib/verilog/core/io/mdio/xml/mdio.xml
#define MDIO_PHY_0_CONTROL_REG                                  0x0440000
#define MDIO_PHY_0_STATUS_REG                                   0x0440004
#define MDIO_PHY_0_PHY_ID_0_REG                                 0x0440008
#define MDIO_PHY_0_PHY_ID_1_REG                                 0x044000c
#define MDIO_PHY_0_AUTONEGOTIATION_ADVERT_REG                   0x0440010
#define MDIO_PHY_0_AUTONEG_LINK_PARTNER_BASE_PAGE_ABILITY_REG   0x0440014
#define MDIO_PHY_0_AUTONEG_EXPANSION_REG                        0x0440018
#define MDIO_PHY_0_AUTONEG_NEXT_PAGE_TX_REG                     0x044001c
#define MDIO_PHY_0_AUTONEG_LINK_PARTNER_RCVD_NEXT_PAGE_REG      0x0440020
#define MDIO_PHY_0_MASTER_SLAVE_CTRL_REG                        0x0440024
#define MDIO_PHY_0_MASTER_SLAVE_STATUS_REG                      0x0440028
#define MDIO_PHY_0_PSE_CTRL_REG                                 0x044002c
#define MDIO_PHY_0_PSE_STATUS_REG                               0x0440030
#define MDIO_PHY_0_MMD_ACCESS_CTRL_REG                          0x0440034
#define MDIO_PHY_0_MMD_ACCESS_STATUS_REG                        0x0440038
#define MDIO_PHY_0_EXTENDED_STATUS_REG                          0x044003c
#define MDIO_PHY_1_CONTROL_REG                                  0x0440080
#define MDIO_PHY_1_STATUS_REG                                   0x0440084
#define MDIO_PHY_1_PHY_ID_0_REG                                 0x0440088
#define MDIO_PHY_1_PHY_ID_1_REG                                 0x044008c
#define MDIO_PHY_1_AUTONEGOTIATION_ADVERT_REG                   0x0440090
#define MDIO_PHY_1_AUTONEG_LINK_PARTNER_BASE_PAGE_ABILITY_REG   0x0440094
#define MDIO_PHY_1_AUTONEG_EXPANSION_REG                        0x0440098
#define MDIO_PHY_1_AUTONEG_NEXT_PAGE_TX_REG                     0x044009c
#define MDIO_PHY_1_AUTONEG_LINK_PARTNER_RCVD_NEXT_PAGE_REG      0x04400a0
#define MDIO_PHY_1_MASTER_SLAVE_CTRL_REG                        0x04400a4
#define MDIO_PHY_1_MASTER_SLAVE_STATUS_REG                      0x04400a8
#define MDIO_PHY_1_PSE_CTRL_REG                                 0x04400ac
#define MDIO_PHY_1_PSE_STATUS_REG                               0x04400b0
#define MDIO_PHY_1_MMD_ACCESS_CTRL_REG                          0x04400b4
#define MDIO_PHY_1_MMD_ACCESS_STATUS_REG                        0x04400b8
#define MDIO_PHY_1_EXTENDED_STATUS_REG                          0x04400bc
#define MDIO_PHY_2_CONTROL_REG                                  0x0440100
#define MDIO_PHY_2_STATUS_REG                                   0x0440104
#define MDIO_PHY_2_PHY_ID_0_REG                                 0x0440108
#define MDIO_PHY_2_PHY_ID_1_REG                                 0x044010c
#define MDIO_PHY_2_AUTONEGOTIATION_ADVERT_REG                   0x0440110
#define MDIO_PHY_2_AUTONEG_LINK_PARTNER_BASE_PAGE_ABILITY_REG   0x0440114
#define MDIO_PHY_2_AUTONEG_EXPANSION_REG                        0x0440118
#define MDIO_PHY_2_AUTONEG_NEXT_PAGE_TX_REG                     0x044011c
#define MDIO_PHY_2_AUTONEG_LINK_PARTNER_RCVD_NEXT_PAGE_REG      0x0440120
#define MDIO_PHY_2_MASTER_SLAVE_CTRL_REG                        0x0440124
#define MDIO_PHY_2_MASTER_SLAVE_STATUS_REG                      0x0440128
#define MDIO_PHY_2_PSE_CTRL_REG                                 0x044012c
#define MDIO_PHY_2_PSE_STATUS_REG                               0x0440130
#define MDIO_PHY_2_MMD_ACCESS_CTRL_REG                          0x0440134
#define MDIO_PHY_2_MMD_ACCESS_STATUS_REG                        0x0440138
#define MDIO_PHY_2_EXTENDED_STATUS_REG                          0x044013c
#define MDIO_PHY_3_CONTROL_REG                                  0x0440180
#define MDIO_PHY_3_STATUS_REG                                   0x0440184
#define MDIO_PHY_3_PHY_ID_0_REG                                 0x0440188
#define MDIO_PHY_3_PHY_ID_1_REG                                 0x044018c
#define MDIO_PHY_3_AUTONEGOTIATION_ADVERT_REG                   0x0440190
#define MDIO_PHY_3_AUTONEG_LINK_PARTNER_BASE_PAGE_ABILITY_REG   0x0440194
#define MDIO_PHY_3_AUTONEG_EXPANSION_REG                        0x0440198
#define MDIO_PHY_3_AUTONEG_NEXT_PAGE_TX_REG                     0x044019c
#define MDIO_PHY_3_AUTONEG_LINK_PARTNER_RCVD_NEXT_PAGE_REG      0x04401a0
#define MDIO_PHY_3_MASTER_SLAVE_CTRL_REG                        0x04401a4
#define MDIO_PHY_3_MASTER_SLAVE_STATUS_REG                      0x04401a8
#define MDIO_PHY_3_PSE_CTRL_REG                                 0x04401ac
#define MDIO_PHY_3_PSE_STATUS_REG                               0x04401b0
#define MDIO_PHY_3_MMD_ACCESS_CTRL_REG                          0x04401b4
#define MDIO_PHY_3_MMD_ACCESS_STATUS_REG                        0x04401b8
#define MDIO_PHY_3_EXTENDED_STATUS_REG                          0x04401bc

#define MDIO_PHY_GROUP_BASE_ADDR   0x0440000
#define MDIO_PHY_GROUP_INST_OFFSET 0x0000080

// Name: stamp_counter (COUNTER)
// Description: Registers for the Stamp Counter and PTP
// File: projects/packet_generator/include/stamp_counter.xml
#define COUNTER_1_REG                         0x0480000
#define COUNTER_2_REG                         0x0480004
#define COUNTER_3_REG                         0x0480008
#define COUNTER_4_REG                         0x048000c
#define COUNTER_1_2_LOAD_REG                  0x0480010
#define COUNTER_3_4_LOAD_REG                  0x0480014
#define COUNTER_BIT_95_64_REG                 0x0480018
#define COUNTER_BIT_63_32_REG                 0x048001c
#define COUNTER_BIT_31_0_REG                  0x0480020
#define COUNTER_READ_ENABLE_REG               0x0480024
#define COUNTER_CLK_SYN_0_COUNTER_RESET_REG   0x0480028
#define COUNTER_CLK_SYN_0_TX_HI_REG           0x048002c
#define COUNTER_CLK_SYN_0_TX_LO_REG           0x0480030
#define COUNTER_CLK_SYN_0_RX_HI_REG           0x0480034
#define COUNTER_CLK_SYN_0_RX_LO_REG           0x0480038
#define COUNTER_CLK_SYN_1_COUNTER_RESET_REG   0x048003c
#define COUNTER_CLK_SYN_1_TX_HI_REG           0x0480040
#define COUNTER_CLK_SYN_1_TX_LO_REG           0x0480044
#define COUNTER_CLK_SYN_1_RX_HI_REG           0x0480048
#define COUNTER_CLK_SYN_1_RX_LO_REG           0x048004c
#define COUNTER_CLK_SYN_2_COUNTER_RESET_REG   0x0480050
#define COUNTER_CLK_SYN_2_TX_HI_REG           0x0480054
#define COUNTER_CLK_SYN_2_TX_LO_REG           0x0480058
#define COUNTER_CLK_SYN_2_RX_HI_REG           0x048005c
#define COUNTER_CLK_SYN_2_RX_LO_REG           0x0480060
#define COUNTER_CLK_SYN_3_COUNTER_RESET_REG   0x0480064
#define COUNTER_CLK_SYN_3_TX_HI_REG           0x0480068
#define COUNTER_CLK_SYN_3_TX_LO_REG           0x048006c
#define COUNTER_CLK_SYN_3_RX_HI_REG           0x0480070
#define COUNTER_CLK_SYN_3_RX_LO_REG           0x0480074
#define COUNTER_PTP_VALID_TX_REG              0x0480078
#define COUNTER_PTP_VALID_RX_REG              0x048007c
#define COUNTER_PTP_ENABLE_MASK_RX_REG        0x0480080
#define COUNTER_PTP_ENABLE_MASK_TX_REG        0x0480084
#define COUNTER_PTP_MASK_RX_REG               0x0480088
#define COUNTER_PTP_MASK_TX_REG               0x048008c

// Name: dma (DMA)
// Description: DMA transfer module
// File: lib/verilog/core/dma/xml/dma.xml

// Name: nf2_mac_grp (MAC_GRP_0)
// Description: Ethernet MAC group
// File: lib/verilog/core/io_queues/ethernet_mac/xml/ethernet_mac.xml
#define MAC_GRP_0_CONTROL_REG                          0x0600000
#define MAC_GRP_0_RX_QUEUE_NUM_PKTS_IN_QUEUE_REG       0x0600004
#define MAC_GRP_0_RX_QUEUE_NUM_PKTS_STORED_REG         0x0600008
#define MAC_GRP_0_RX_QUEUE_NUM_PKTS_DROPPED_FULL_REG   0x060000c
#define MAC_GRP_0_RX_QUEUE_NUM_PKTS_DROPPED_BAD_REG    0x0600010
#define MAC_GRP_0_RX_QUEUE_NUM_PKTS_DEQUEUED_REG       0x0600014
#define MAC_GRP_0_RX_QUEUE_NUM_WORDS_PUSHED_REG        0x0600018
#define MAC_GRP_0_RX_QUEUE_NUM_BYTES_PUSHED_REG        0x060001c
#define MAC_GRP_0_TX_QUEUE_NUM_PKTS_IN_QUEUE_REG       0x0600020
#define MAC_GRP_0_TX_QUEUE_NUM_PKTS_ENQUEUED_REG       0x0600024
#define MAC_GRP_0_TX_QUEUE_NUM_PKTS_SENT_REG           0x0600028
#define MAC_GRP_0_TX_QUEUE_NUM_WORDS_PUSHED_REG        0x060002c
#define MAC_GRP_0_TX_QUEUE_NUM_BYTES_PUSHED_REG        0x0600030

// Name: nf2_mac_grp (MAC_GRP_1)
// Description: Ethernet MAC group
// File: lib/verilog/core/io_queues/ethernet_mac/xml/ethernet_mac.xml
#define MAC_GRP_1_CONTROL_REG                          0x0640000
#define MAC_GRP_1_RX_QUEUE_NUM_PKTS_IN_QUEUE_REG       0x0640004
#define MAC_GRP_1_RX_QUEUE_NUM_PKTS_STORED_REG         0x0640008
#define MAC_GRP_1_RX_QUEUE_NUM_PKTS_DROPPED_FULL_REG   0x064000c
#define MAC_GRP_1_RX_QUEUE_NUM_PKTS_DROPPED_BAD_REG    0x0640010
#define MAC_GRP_1_RX_QUEUE_NUM_PKTS_DEQUEUED_REG       0x0640014
#define MAC_GRP_1_RX_QUEUE_NUM_WORDS_PUSHED_REG        0x0640018
#define MAC_GRP_1_RX_QUEUE_NUM_BYTES_PUSHED_REG        0x064001c
#define MAC_GRP_1_TX_QUEUE_NUM_PKTS_IN_QUEUE_REG       0x0640020
#define MAC_GRP_1_TX_QUEUE_NUM_PKTS_ENQUEUED_REG       0x0640024
#define MAC_GRP_1_TX_QUEUE_NUM_PKTS_SENT_REG           0x0640028
#define MAC_GRP_1_TX_QUEUE_NUM_WORDS_PUSHED_REG        0x064002c
#define MAC_GRP_1_TX_QUEUE_NUM_BYTES_PUSHED_REG        0x0640030

// Name: nf2_mac_grp (MAC_GRP_2)
// Description: Ethernet MAC group
// File: lib/verilog/core/io_queues/ethernet_mac/xml/ethernet_mac.xml
#define MAC_GRP_2_CONTROL_REG                          0x0680000
#define MAC_GRP_2_RX_QUEUE_NUM_PKTS_IN_QUEUE_REG       0x0680004
#define MAC_GRP_2_RX_QUEUE_NUM_PKTS_STORED_REG         0x0680008
#define MAC_GRP_2_RX_QUEUE_NUM_PKTS_DROPPED_FULL_REG   0x068000c
#define MAC_GRP_2_RX_QUEUE_NUM_PKTS_DROPPED_BAD_REG    0x0680010
#define MAC_GRP_2_RX_QUEUE_NUM_PKTS_DEQUEUED_REG       0x0680014
#define MAC_GRP_2_RX_QUEUE_NUM_WORDS_PUSHED_REG        0x0680018
#define MAC_GRP_2_RX_QUEUE_NUM_BYTES_PUSHED_REG        0x068001c
#define MAC_GRP_2_TX_QUEUE_NUM_PKTS_IN_QUEUE_REG       0x0680020
#define MAC_GRP_2_TX_QUEUE_NUM_PKTS_ENQUEUED_REG       0x0680024
#define MAC_GRP_2_TX_QUEUE_NUM_PKTS_SENT_REG           0x0680028
#define MAC_GRP_2_TX_QUEUE_NUM_WORDS_PUSHED_REG        0x068002c
#define MAC_GRP_2_TX_QUEUE_NUM_BYTES_PUSHED_REG        0x0680030

// Name: nf2_mac_grp (MAC_GRP_3)
// Description: Ethernet MAC group
// File: lib/verilog/core/io_queues/ethernet_mac/xml/ethernet_mac.xml
#define MAC_GRP_3_CONTROL_REG                          0x06c0000
#define MAC_GRP_3_RX_QUEUE_NUM_PKTS_IN_QUEUE_REG       0x06c0004
#define MAC_GRP_3_RX_QUEUE_NUM_PKTS_STORED_REG         0x06c0008
#define MAC_GRP_3_RX_QUEUE_NUM_PKTS_DROPPED_FULL_REG   0x06c000c
#define MAC_GRP_3_RX_QUEUE_NUM_PKTS_DROPPED_BAD_REG    0x06c0010
#define MAC_GRP_3_RX_QUEUE_NUM_PKTS_DEQUEUED_REG       0x06c0014
#define MAC_GRP_3_RX_QUEUE_NUM_WORDS_PUSHED_REG        0x06c0018
#define MAC_GRP_3_RX_QUEUE_NUM_BYTES_PUSHED_REG        0x06c001c
#define MAC_GRP_3_TX_QUEUE_NUM_PKTS_IN_QUEUE_REG       0x06c0020
#define MAC_GRP_3_TX_QUEUE_NUM_PKTS_ENQUEUED_REG       0x06c0024
#define MAC_GRP_3_TX_QUEUE_NUM_PKTS_SENT_REG           0x06c0028
#define MAC_GRP_3_TX_QUEUE_NUM_WORDS_PUSHED_REG        0x06c002c
#define MAC_GRP_3_TX_QUEUE_NUM_BYTES_PUSHED_REG        0x06c0030

// Name: cpu_dma_queue (CPU_QUEUE_0)
// Description: CPU DMA queue
// File: lib/verilog/core/io_queues/cpu_dma_queue/xml/cpu_dma_queue.xml

// Name: cpu_dma_queue (CPU_QUEUE_1)
// Description: CPU DMA queue
// File: lib/verilog/core/io_queues/cpu_dma_queue/xml/cpu_dma_queue.xml

// Name: cpu_dma_queue (CPU_QUEUE_2)
// Description: CPU DMA queue
// File: lib/verilog/core/io_queues/cpu_dma_queue/xml/cpu_dma_queue.xml

// Name: cpu_dma_queue (CPU_QUEUE_3)
// Description: CPU DMA queue
// File: lib/verilog/core/io_queues/cpu_dma_queue/xml/cpu_dma_queue.xml

// Name: SRAM (SRAM)
// Description: SRAM

// Name: output_queues (OQ)
// Description: SRAM-based output queue using round-robin removal, modified for Packet Generator
// File: projects/packet_generator/include/sram_rr_output_queues.xml
#define OQ_QUEUE_0_CTRL_REG                          0x2000000
#define OQ_QUEUE_0_NUM_PKT_BYTES_STORED_REG          0x2000004
#define OQ_QUEUE_0_NUM_OVERHEAD_BYTES_STORED_REG     0x2000008
#define OQ_QUEUE_0_NUM_PKT_BYTES_REMOVED_REG         0x200000c
#define OQ_QUEUE_0_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000010
#define OQ_QUEUE_0_NUM_PKTS_STORED_REG               0x2000014
#define OQ_QUEUE_0_NUM_PKTS_DROPPED_REG              0x2000018
#define OQ_QUEUE_0_NUM_PKTS_REMOVED_REG              0x200001c
#define OQ_QUEUE_0_ADDR_LO_REG                       0x2000020
#define OQ_QUEUE_0_ADDR_HI_REG                       0x2000024
#define OQ_QUEUE_0_RD_ADDR_REG                       0x2000028
#define OQ_QUEUE_0_WR_ADDR_REG                       0x200002c
#define OQ_QUEUE_0_NUM_PKTS_IN_Q_REG                 0x2000030
#define OQ_QUEUE_0_MAX_PKTS_IN_Q_REG                 0x2000034
#define OQ_QUEUE_0_NUM_WORDS_IN_Q_REG                0x2000038
#define OQ_QUEUE_0_NUM_WORDS_LEFT_REG                0x200003c
#define OQ_QUEUE_0_FULL_THRESH_REG                   0x2000040
#define OQ_QUEUE_0_CURR_ITER_REG                     0x2000044
#define OQ_QUEUE_0_MAX_ITER_REG                      0x2000048
#define OQ_QUEUE_1_CTRL_REG                          0x2000100
#define OQ_QUEUE_1_NUM_PKT_BYTES_STORED_REG          0x2000104
#define OQ_QUEUE_1_NUM_OVERHEAD_BYTES_STORED_REG     0x2000108
#define OQ_QUEUE_1_NUM_PKT_BYTES_REMOVED_REG         0x200010c
#define OQ_QUEUE_1_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000110
#define OQ_QUEUE_1_NUM_PKTS_STORED_REG               0x2000114
#define OQ_QUEUE_1_NUM_PKTS_DROPPED_REG              0x2000118
#define OQ_QUEUE_1_NUM_PKTS_REMOVED_REG              0x200011c
#define OQ_QUEUE_1_ADDR_LO_REG                       0x2000120
#define OQ_QUEUE_1_ADDR_HI_REG                       0x2000124
#define OQ_QUEUE_1_RD_ADDR_REG                       0x2000128
#define OQ_QUEUE_1_WR_ADDR_REG                       0x200012c
#define OQ_QUEUE_1_NUM_PKTS_IN_Q_REG                 0x2000130
#define OQ_QUEUE_1_MAX_PKTS_IN_Q_REG                 0x2000134
#define OQ_QUEUE_1_NUM_WORDS_IN_Q_REG                0x2000138
#define OQ_QUEUE_1_NUM_WORDS_LEFT_REG                0x200013c
#define OQ_QUEUE_1_FULL_THRESH_REG                   0x2000140
#define OQ_QUEUE_1_CURR_ITER_REG                     0x2000144
#define OQ_QUEUE_1_MAX_ITER_REG                      0x2000148
#define OQ_QUEUE_2_CTRL_REG                          0x2000200
#define OQ_QUEUE_2_NUM_PKT_BYTES_STORED_REG          0x2000204
#define OQ_QUEUE_2_NUM_OVERHEAD_BYTES_STORED_REG     0x2000208
#define OQ_QUEUE_2_NUM_PKT_BYTES_REMOVED_REG         0x200020c
#define OQ_QUEUE_2_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000210
#define OQ_QUEUE_2_NUM_PKTS_STORED_REG               0x2000214
#define OQ_QUEUE_2_NUM_PKTS_DROPPED_REG              0x2000218
#define OQ_QUEUE_2_NUM_PKTS_REMOVED_REG              0x200021c
#define OQ_QUEUE_2_ADDR_LO_REG                       0x2000220
#define OQ_QUEUE_2_ADDR_HI_REG                       0x2000224
#define OQ_QUEUE_2_RD_ADDR_REG                       0x2000228
#define OQ_QUEUE_2_WR_ADDR_REG                       0x200022c
#define OQ_QUEUE_2_NUM_PKTS_IN_Q_REG                 0x2000230
#define OQ_QUEUE_2_MAX_PKTS_IN_Q_REG                 0x2000234
#define OQ_QUEUE_2_NUM_WORDS_IN_Q_REG                0x2000238
#define OQ_QUEUE_2_NUM_WORDS_LEFT_REG                0x200023c
#define OQ_QUEUE_2_FULL_THRESH_REG                   0x2000240
#define OQ_QUEUE_2_CURR_ITER_REG                     0x2000244
#define OQ_QUEUE_2_MAX_ITER_REG                      0x2000248
#define OQ_QUEUE_3_CTRL_REG                          0x2000300
#define OQ_QUEUE_3_NUM_PKT_BYTES_STORED_REG          0x2000304
#define OQ_QUEUE_3_NUM_OVERHEAD_BYTES_STORED_REG     0x2000308
#define OQ_QUEUE_3_NUM_PKT_BYTES_REMOVED_REG         0x200030c
#define OQ_QUEUE_3_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000310
#define OQ_QUEUE_3_NUM_PKTS_STORED_REG               0x2000314
#define OQ_QUEUE_3_NUM_PKTS_DROPPED_REG              0x2000318
#define OQ_QUEUE_3_NUM_PKTS_REMOVED_REG              0x200031c
#define OQ_QUEUE_3_ADDR_LO_REG                       0x2000320
#define OQ_QUEUE_3_ADDR_HI_REG                       0x2000324
#define OQ_QUEUE_3_RD_ADDR_REG                       0x2000328
#define OQ_QUEUE_3_WR_ADDR_REG                       0x200032c
#define OQ_QUEUE_3_NUM_PKTS_IN_Q_REG                 0x2000330
#define OQ_QUEUE_3_MAX_PKTS_IN_Q_REG                 0x2000334
#define OQ_QUEUE_3_NUM_WORDS_IN_Q_REG                0x2000338
#define OQ_QUEUE_3_NUM_WORDS_LEFT_REG                0x200033c
#define OQ_QUEUE_3_FULL_THRESH_REG                   0x2000340
#define OQ_QUEUE_3_CURR_ITER_REG                     0x2000344
#define OQ_QUEUE_3_MAX_ITER_REG                      0x2000348
#define OQ_QUEUE_4_CTRL_REG                          0x2000400
#define OQ_QUEUE_4_NUM_PKT_BYTES_STORED_REG          0x2000404
#define OQ_QUEUE_4_NUM_OVERHEAD_BYTES_STORED_REG     0x2000408
#define OQ_QUEUE_4_NUM_PKT_BYTES_REMOVED_REG         0x200040c
#define OQ_QUEUE_4_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000410
#define OQ_QUEUE_4_NUM_PKTS_STORED_REG               0x2000414
#define OQ_QUEUE_4_NUM_PKTS_DROPPED_REG              0x2000418
#define OQ_QUEUE_4_NUM_PKTS_REMOVED_REG              0x200041c
#define OQ_QUEUE_4_ADDR_LO_REG                       0x2000420
#define OQ_QUEUE_4_ADDR_HI_REG                       0x2000424
#define OQ_QUEUE_4_RD_ADDR_REG                       0x2000428
#define OQ_QUEUE_4_WR_ADDR_REG                       0x200042c
#define OQ_QUEUE_4_NUM_PKTS_IN_Q_REG                 0x2000430
#define OQ_QUEUE_4_MAX_PKTS_IN_Q_REG                 0x2000434
#define OQ_QUEUE_4_NUM_WORDS_IN_Q_REG                0x2000438
#define OQ_QUEUE_4_NUM_WORDS_LEFT_REG                0x200043c
#define OQ_QUEUE_4_FULL_THRESH_REG                   0x2000440
#define OQ_QUEUE_4_CURR_ITER_REG                     0x2000444
#define OQ_QUEUE_4_MAX_ITER_REG                      0x2000448
#define OQ_QUEUE_5_CTRL_REG                          0x2000500
#define OQ_QUEUE_5_NUM_PKT_BYTES_STORED_REG          0x2000504
#define OQ_QUEUE_5_NUM_OVERHEAD_BYTES_STORED_REG     0x2000508
#define OQ_QUEUE_5_NUM_PKT_BYTES_REMOVED_REG         0x200050c
#define OQ_QUEUE_5_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000510
#define OQ_QUEUE_5_NUM_PKTS_STORED_REG               0x2000514
#define OQ_QUEUE_5_NUM_PKTS_DROPPED_REG              0x2000518
#define OQ_QUEUE_5_NUM_PKTS_REMOVED_REG              0x200051c
#define OQ_QUEUE_5_ADDR_LO_REG                       0x2000520
#define OQ_QUEUE_5_ADDR_HI_REG                       0x2000524
#define OQ_QUEUE_5_RD_ADDR_REG                       0x2000528
#define OQ_QUEUE_5_WR_ADDR_REG                       0x200052c
#define OQ_QUEUE_5_NUM_PKTS_IN_Q_REG                 0x2000530
#define OQ_QUEUE_5_MAX_PKTS_IN_Q_REG                 0x2000534
#define OQ_QUEUE_5_NUM_WORDS_IN_Q_REG                0x2000538
#define OQ_QUEUE_5_NUM_WORDS_LEFT_REG                0x200053c
#define OQ_QUEUE_5_FULL_THRESH_REG                   0x2000540
#define OQ_QUEUE_5_CURR_ITER_REG                     0x2000544
#define OQ_QUEUE_5_MAX_ITER_REG                      0x2000548
#define OQ_QUEUE_6_CTRL_REG                          0x2000600
#define OQ_QUEUE_6_NUM_PKT_BYTES_STORED_REG          0x2000604
#define OQ_QUEUE_6_NUM_OVERHEAD_BYTES_STORED_REG     0x2000608
#define OQ_QUEUE_6_NUM_PKT_BYTES_REMOVED_REG         0x200060c
#define OQ_QUEUE_6_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000610
#define OQ_QUEUE_6_NUM_PKTS_STORED_REG               0x2000614
#define OQ_QUEUE_6_NUM_PKTS_DROPPED_REG              0x2000618
#define OQ_QUEUE_6_NUM_PKTS_REMOVED_REG              0x200061c
#define OQ_QUEUE_6_ADDR_LO_REG                       0x2000620
#define OQ_QUEUE_6_ADDR_HI_REG                       0x2000624
#define OQ_QUEUE_6_RD_ADDR_REG                       0x2000628
#define OQ_QUEUE_6_WR_ADDR_REG                       0x200062c
#define OQ_QUEUE_6_NUM_PKTS_IN_Q_REG                 0x2000630
#define OQ_QUEUE_6_MAX_PKTS_IN_Q_REG                 0x2000634
#define OQ_QUEUE_6_NUM_WORDS_IN_Q_REG                0x2000638
#define OQ_QUEUE_6_NUM_WORDS_LEFT_REG                0x200063c
#define OQ_QUEUE_6_FULL_THRESH_REG                   0x2000640
#define OQ_QUEUE_6_CURR_ITER_REG                     0x2000644
#define OQ_QUEUE_6_MAX_ITER_REG                      0x2000648
#define OQ_QUEUE_7_CTRL_REG                          0x2000700
#define OQ_QUEUE_7_NUM_PKT_BYTES_STORED_REG          0x2000704
#define OQ_QUEUE_7_NUM_OVERHEAD_BYTES_STORED_REG     0x2000708
#define OQ_QUEUE_7_NUM_PKT_BYTES_REMOVED_REG         0x200070c
#define OQ_QUEUE_7_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000710
#define OQ_QUEUE_7_NUM_PKTS_STORED_REG               0x2000714
#define OQ_QUEUE_7_NUM_PKTS_DROPPED_REG              0x2000718
#define OQ_QUEUE_7_NUM_PKTS_REMOVED_REG              0x200071c
#define OQ_QUEUE_7_ADDR_LO_REG                       0x2000720
#define OQ_QUEUE_7_ADDR_HI_REG                       0x2000724
#define OQ_QUEUE_7_RD_ADDR_REG                       0x2000728
#define OQ_QUEUE_7_WR_ADDR_REG                       0x200072c
#define OQ_QUEUE_7_NUM_PKTS_IN_Q_REG                 0x2000730
#define OQ_QUEUE_7_MAX_PKTS_IN_Q_REG                 0x2000734
#define OQ_QUEUE_7_NUM_WORDS_IN_Q_REG                0x2000738
#define OQ_QUEUE_7_NUM_WORDS_LEFT_REG                0x200073c
#define OQ_QUEUE_7_FULL_THRESH_REG                   0x2000740
#define OQ_QUEUE_7_CURR_ITER_REG                     0x2000744
#define OQ_QUEUE_7_MAX_ITER_REG                      0x2000748
#define OQ_QUEUE_8_CTRL_REG                          0x2000800
#define OQ_QUEUE_8_NUM_PKT_BYTES_STORED_REG          0x2000804
#define OQ_QUEUE_8_NUM_OVERHEAD_BYTES_STORED_REG     0x2000808
#define OQ_QUEUE_8_NUM_PKT_BYTES_REMOVED_REG         0x200080c
#define OQ_QUEUE_8_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000810
#define OQ_QUEUE_8_NUM_PKTS_STORED_REG               0x2000814
#define OQ_QUEUE_8_NUM_PKTS_DROPPED_REG              0x2000818
#define OQ_QUEUE_8_NUM_PKTS_REMOVED_REG              0x200081c
#define OQ_QUEUE_8_ADDR_LO_REG                       0x2000820
#define OQ_QUEUE_8_ADDR_HI_REG                       0x2000824
#define OQ_QUEUE_8_RD_ADDR_REG                       0x2000828
#define OQ_QUEUE_8_WR_ADDR_REG                       0x200082c
#define OQ_QUEUE_8_NUM_PKTS_IN_Q_REG                 0x2000830
#define OQ_QUEUE_8_MAX_PKTS_IN_Q_REG                 0x2000834
#define OQ_QUEUE_8_NUM_WORDS_IN_Q_REG                0x2000838
#define OQ_QUEUE_8_NUM_WORDS_LEFT_REG                0x200083c
#define OQ_QUEUE_8_FULL_THRESH_REG                   0x2000840
#define OQ_QUEUE_8_CURR_ITER_REG                     0x2000844
#define OQ_QUEUE_8_MAX_ITER_REG                      0x2000848
#define OQ_QUEUE_9_CTRL_REG                          0x2000900
#define OQ_QUEUE_9_NUM_PKT_BYTES_STORED_REG          0x2000904
#define OQ_QUEUE_9_NUM_OVERHEAD_BYTES_STORED_REG     0x2000908
#define OQ_QUEUE_9_NUM_PKT_BYTES_REMOVED_REG         0x200090c
#define OQ_QUEUE_9_NUM_OVERHEAD_BYTES_REMOVED_REG    0x2000910
#define OQ_QUEUE_9_NUM_PKTS_STORED_REG               0x2000914
#define OQ_QUEUE_9_NUM_PKTS_DROPPED_REG              0x2000918
#define OQ_QUEUE_9_NUM_PKTS_REMOVED_REG              0x200091c
#define OQ_QUEUE_9_ADDR_LO_REG                       0x2000920
#define OQ_QUEUE_9_ADDR_HI_REG                       0x2000924
#define OQ_QUEUE_9_RD_ADDR_REG                       0x2000928
#define OQ_QUEUE_9_WR_ADDR_REG                       0x200092c
#define OQ_QUEUE_9_NUM_PKTS_IN_Q_REG                 0x2000930
#define OQ_QUEUE_9_MAX_PKTS_IN_Q_REG                 0x2000934
#define OQ_QUEUE_9_NUM_WORDS_IN_Q_REG                0x2000938
#define OQ_QUEUE_9_NUM_WORDS_LEFT_REG                0x200093c
#define OQ_QUEUE_9_FULL_THRESH_REG                   0x2000940
#define OQ_QUEUE_9_CURR_ITER_REG                     0x2000944
#define OQ_QUEUE_9_MAX_ITER_REG                      0x2000948
#define OQ_QUEUE_10_CTRL_REG                         0x2000a00
#define OQ_QUEUE_10_NUM_PKT_BYTES_STORED_REG         0x2000a04
#define OQ_QUEUE_10_NUM_OVERHEAD_BYTES_STORED_REG    0x2000a08
#define OQ_QUEUE_10_NUM_PKT_BYTES_REMOVED_REG        0x2000a0c
#define OQ_QUEUE_10_NUM_OVERHEAD_BYTES_REMOVED_REG   0x2000a10
#define OQ_QUEUE_10_NUM_PKTS_STORED_REG              0x2000a14
#define OQ_QUEUE_10_NUM_PKTS_DROPPED_REG             0x2000a18
#define OQ_QUEUE_10_NUM_PKTS_REMOVED_REG             0x2000a1c
#define OQ_QUEUE_10_ADDR_LO_REG                      0x2000a20
#define OQ_QUEUE_10_ADDR_HI_REG                      0x2000a24
#define OQ_QUEUE_10_RD_ADDR_REG                      0x2000a28
#define OQ_QUEUE_10_WR_ADDR_REG                      0x2000a2c
#define OQ_QUEUE_10_NUM_PKTS_IN_Q_REG                0x2000a30
#define OQ_QUEUE_10_MAX_PKTS_IN_Q_REG                0x2000a34
#define OQ_QUEUE_10_NUM_WORDS_IN_Q_REG               0x2000a38
#define OQ_QUEUE_10_NUM_WORDS_LEFT_REG               0x2000a3c
#define OQ_QUEUE_10_FULL_THRESH_REG                  0x2000a40
#define OQ_QUEUE_10_CURR_ITER_REG                    0x2000a44
#define OQ_QUEUE_10_MAX_ITER_REG                     0x2000a48
#define OQ_QUEUE_11_CTRL_REG                         0x2000b00
#define OQ_QUEUE_11_NUM_PKT_BYTES_STORED_REG         0x2000b04
#define OQ_QUEUE_11_NUM_OVERHEAD_BYTES_STORED_REG    0x2000b08
#define OQ_QUEUE_11_NUM_PKT_BYTES_REMOVED_REG        0x2000b0c
#define OQ_QUEUE_11_NUM_OVERHEAD_BYTES_REMOVED_REG   0x2000b10
#define OQ_QUEUE_11_NUM_PKTS_STORED_REG              0x2000b14
#define OQ_QUEUE_11_NUM_PKTS_DROPPED_REG             0x2000b18
#define OQ_QUEUE_11_NUM_PKTS_REMOVED_REG             0x2000b1c
#define OQ_QUEUE_11_ADDR_LO_REG                      0x2000b20
#define OQ_QUEUE_11_ADDR_HI_REG                      0x2000b24
#define OQ_QUEUE_11_RD_ADDR_REG                      0x2000b28
#define OQ_QUEUE_11_WR_ADDR_REG                      0x2000b2c
#define OQ_QUEUE_11_NUM_PKTS_IN_Q_REG                0x2000b30
#define OQ_QUEUE_11_MAX_PKTS_IN_Q_REG                0x2000b34
#define OQ_QUEUE_11_NUM_WORDS_IN_Q_REG               0x2000b38
#define OQ_QUEUE_11_NUM_WORDS_LEFT_REG               0x2000b3c
#define OQ_QUEUE_11_FULL_THRESH_REG                  0x2000b40
#define OQ_QUEUE_11_CURR_ITER_REG                    0x2000b44
#define OQ_QUEUE_11_MAX_ITER_REG                     0x2000b48

#define OQ_QUEUE_GROUP_BASE_ADDR   0x2000000
#define OQ_QUEUE_GROUP_INST_OFFSET 0x0000100

// Name: in_arb (IN_ARB)
// Description: Round-robin input arbiter
// File: lib/verilog/core/input_arbiter/rr_input_arbiter/xml/rr_input_arbiter.xml
#define IN_ARB_NUM_PKTS_SENT_REG        0x2001000
#define IN_ARB_LAST_PKT_WORD_0_HI_REG   0x2001004
#define IN_ARB_LAST_PKT_WORD_0_LO_REG   0x2001008
#define IN_ARB_LAST_PKT_CTRL_0_REG      0x200100c
#define IN_ARB_LAST_PKT_WORD_1_HI_REG   0x2001010
#define IN_ARB_LAST_PKT_WORD_1_LO_REG   0x2001014
#define IN_ARB_LAST_PKT_CTRL_1_REG      0x2001018
#define IN_ARB_STATE_REG                0x200101c

// Name: delay (DELAY)
// Description: Delay Module Registers
// File: projects/packet_generator/include/delay.xml
#define DELAY_RESET_REG   0x2001100

// Name: rate_limiter (RATE_LIMIT_0)
// Description: Event Capture Registers
// File: projects/packet_generator/include/rate_limiter.xml
#define RATE_LIMIT_0_CTRL_REG             0x2001140
#define RATE_LIMIT_0_TOKEN_INTERVAL_REG   0x2001144
#define RATE_LIMIT_0_TOKEN_INC_REG        0x2001148

// Name: rate_limiter (RATE_LIMIT_1)
// Description: Event Capture Registers
// File: projects/packet_generator/include/rate_limiter.xml
#define RATE_LIMIT_1_CTRL_REG             0x2001180
#define RATE_LIMIT_1_TOKEN_INTERVAL_REG   0x2001184
#define RATE_LIMIT_1_TOKEN_INC_REG        0x2001188

// Name: rate_limiter (RATE_LIMIT_2)
// Description: Event Capture Registers
// File: projects/packet_generator/include/rate_limiter.xml
#define RATE_LIMIT_2_CTRL_REG             0x20011c0
#define RATE_LIMIT_2_TOKEN_INTERVAL_REG   0x20011c4
#define RATE_LIMIT_2_TOKEN_INC_REG        0x20011c8

// Name: rate_limiter (RATE_LIMIT_3)
// Description: Event Capture Registers
// File: projects/packet_generator/include/rate_limiter.xml
#define RATE_LIMIT_3_CTRL_REG             0x2001200
#define RATE_LIMIT_3_TOKEN_INTERVAL_REG   0x2001204
#define RATE_LIMIT_3_TOKEN_INC_REG        0x2001208

// Name: rate_limiter (RATE_LIMIT_4)
// Description: Event Capture Registers
// File: projects/packet_generator/include/rate_limiter.xml
#define RATE_LIMIT_4_CTRL_REG             0x2001240
#define RATE_LIMIT_4_TOKEN_INTERVAL_REG   0x2001244
#define RATE_LIMIT_4_TOKEN_INC_REG        0x2001248

// Name: rate_limiter (RATE_LIMIT_5)
// Description: Event Capture Registers
// File: projects/packet_generator/include/rate_limiter.xml
#define RATE_LIMIT_5_CTRL_REG             0x2001280
#define RATE_LIMIT_5_TOKEN_INTERVAL_REG   0x2001284
#define RATE_LIMIT_5_TOKEN_INC_REG        0x2001288

// Name: rate_limiter (RATE_LIMIT_6)
// Description: Event Capture Registers
// File: projects/packet_generator/include/rate_limiter.xml
#define RATE_LIMIT_6_CTRL_REG             0x20012c0
#define RATE_LIMIT_6_TOKEN_INTERVAL_REG   0x20012c4
#define RATE_LIMIT_6_TOKEN_INC_REG        0x20012c8

// Name: rate_limiter (RATE_LIMIT_7)
// Description: Event Capture Registers
// File: projects/packet_generator/include/rate_limiter.xml
#define RATE_LIMIT_7_CTRL_REG             0x2001300
#define RATE_LIMIT_7_TOKEN_INTERVAL_REG   0x2001304
#define RATE_LIMIT_7_TOKEN_INC_REG        0x2001308

// Name: packet_capture (PKT_GEN)
// Description: Packet Generator Control Registers
// File: projects/packet_generator/include/packet_capture.xml
#define PKT_GEN_CTRL_ENABLE_REG            0x2001400
#define PKT_GEN_CTRL_0_PKT_COUNT_REG       0x2001480
#define PKT_GEN_CTRL_0_BYTE_COUNT_HI_REG   0x2001484
#define PKT_GEN_CTRL_0_BYTE_COUNT_LO_REG   0x2001488
#define PKT_GEN_CTRL_0_TIME_FIRST_HI_REG   0x200148c
#define PKT_GEN_CTRL_0_TIME_FIRST_LO_REG   0x2001490
#define PKT_GEN_CTRL_0_TIME_LAST_HI_REG    0x2001494
#define PKT_GEN_CTRL_0_TIME_LAST_LO_REG    0x2001498
#define PKT_GEN_CTRL_1_PKT_COUNT_REG       0x20014a0
#define PKT_GEN_CTRL_1_BYTE_COUNT_HI_REG   0x20014a4
#define PKT_GEN_CTRL_1_BYTE_COUNT_LO_REG   0x20014a8
#define PKT_GEN_CTRL_1_TIME_FIRST_HI_REG   0x20014ac
#define PKT_GEN_CTRL_1_TIME_FIRST_LO_REG   0x20014b0
#define PKT_GEN_CTRL_1_TIME_LAST_HI_REG    0x20014b4
#define PKT_GEN_CTRL_1_TIME_LAST_LO_REG    0x20014b8
#define PKT_GEN_CTRL_2_PKT_COUNT_REG       0x20014c0
#define PKT_GEN_CTRL_2_BYTE_COUNT_HI_REG   0x20014c4
#define PKT_GEN_CTRL_2_BYTE_COUNT_LO_REG   0x20014c8
#define PKT_GEN_CTRL_2_TIME_FIRST_HI_REG   0x20014cc
#define PKT_GEN_CTRL_2_TIME_FIRST_LO_REG   0x20014d0
#define PKT_GEN_CTRL_2_TIME_LAST_HI_REG    0x20014d4
#define PKT_GEN_CTRL_2_TIME_LAST_LO_REG    0x20014d8
#define PKT_GEN_CTRL_3_PKT_COUNT_REG       0x20014e0
#define PKT_GEN_CTRL_3_BYTE_COUNT_HI_REG   0x20014e4
#define PKT_GEN_CTRL_3_BYTE_COUNT_LO_REG   0x20014e8
#define PKT_GEN_CTRL_3_TIME_FIRST_HI_REG   0x20014ec
#define PKT_GEN_CTRL_3_TIME_FIRST_LO_REG   0x20014f0
#define PKT_GEN_CTRL_3_TIME_LAST_HI_REG    0x20014f4
#define PKT_GEN_CTRL_3_TIME_LAST_LO_REG    0x20014f8

#define PKT_GEN_CTRL_GROUP_BASE_ADDR   0x2001480
#define PKT_GEN_CTRL_GROUP_INST_OFFSET 0x0000020

// Name: DRAM (DRAM)
// Description: DRAM




#endif

