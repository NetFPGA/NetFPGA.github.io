#!/bin/bash

# Execute this shell as a super user on your home directory
# You will need a four-port GigE NIC for the test

source env_vars
of_nf2_test.pl

