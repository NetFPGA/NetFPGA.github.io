#!/bin/bash

# Execute this shell as a super user on your home directory

#NetFPGA kernel module availability check
nfchk=`/sbin/lsmod | grep nf2 | cut -d" " -f1`
if test "$nfchk" != "nf2"
then
 echo "Check if you have properly installed NetFPGA kernel module"
 exit 1
fi

#NetFPGA card availability check
devchk=`/sbin/lspci | grep feed |cut -d" " -f6 |cut -c1-4`
if test "$devchk" != "feed"
then
 echo "Check if you have properly mounted NetFPGA card"
 exit 1
fi

#Required packages installation
wget http://packages.sw.be/rpmforge-release/rpmforge-release-0.3.6-1.el5.rf.i386.rpm
rpm -Uhv rpmforge-release-0.3.6-1.el5.rf.i386.rpm

yum -y install git automake pkgconfig libtool gcc imake make

wget http://ftp.gnu.org/gnu/autoconf/autoconf-2.62.tar.gz
tar xvzf autoconf-2.62.tar.gz
cd autoconf-2.62
./configure --prefix=/usr
make
make install

cd ..

yum -y install kernel-`uname -r` kernel-headers-`uname -r` kernel-devel-`uname -r`
yum -y install perl-Convert-Binary-C perl-Data-HexDump perl-Net-Pcap perl-Net-RawIP.i386 perl-Error.noarch
yum -y groupinstall "X Window System"
yum -y install wireshark wireshark-gnome glib2-devel

#Stop unwanted service
/sbin/chkconfig avahi-daemon off
/etc/rc.d/init.d/avahi-daemon stop

#Acquire OpenFlow module (including NetFPGA hardware table module and bitfile)
git clone git://openflowswitch.org/openflow openflow-git
cd openflow-git
./boot.sh

#Make
./configure --with-l26=/lib/modules/`uname -r`/build --enable-hw-tables=nf2
make
make install

#Install Wireshark dissectors 
cd utilities/wireshark_dissectors/openflow
make
make install

cd ../../../..

#Setup env file for regression test
echo "export OF_ROOT=`pwd`/openflow-git" > env_vars
echo "export OFT_ROOT=\${OF_ROOT}/regress" >> env_vars
echo "export PATH=\${PATH}:\${OFT_ROOT}/bin:/sbin:/usr/sbin" >> env_vars
echo "export PERL5LIB=\${OFT_ROOT}/lib/Perl5" >> env_vars

