/* ****************************************************************************
 * $Id: of_regdump.c 1593 2007-04-04 05:31:05Z jnaous $
 *
 * Module: of_regdump.c
 * Project: open flow reference
 * Description: Test program to dump the open flow registers
 *
 * Change history:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>

#include <net/if.h>

#include <time.h>

#include "../../../../lib/C/common/reg_defines.h"
#include "../../lib/C/reg_defines_openflow_switch.h"
#include "nf2_openflow.h"
#include "../../../../lib/C/common/nf2util.h"

#define PATHLEN		80

#define DEFAULT_IFACE	"nf2c0"

/* Global vars */
static struct nf2device nf2;
static int verbose = 0;
static int force_cnet = 0;

/* Function declarations */
void print (void);
void printMAC (unsigned char*);
void printIP (unsigned);
void write_openflow_wildcard_table(int index, nf2_of_entry_wrap *wildcard, nf2_of_entry_wrap *wildcard_mask, 
				   nf2_of_action_wrap *wildcard_actions);
void read_openflow_wildcard_table(int, int *entry_not_zero, nf2_of_entry_wrap *wildcard, nf2_of_entry_wrap *wildcard_mask, 
				    nf2_of_action_wrap *wildcard_actions);
void print_openflow_table(nf2_of_entry_wrap , nf2_of_entry_wrap , 
				    nf2_of_action_wrap );
int main(int argc, char *argv[])
{
	unsigned val;

	nf2.device_name = DEFAULT_IFACE;

	if (check_iface(&nf2))
	{
		exit(1);
	}
	if (openDescriptor(&nf2))
	{
		exit(1);
	}

	print();

	closeDescriptor(&nf2);

	return 0;
}

void print(void) {
	unsigned val, val2;
	int i, j, entry_not_zero;
	nf2_of_entry_wrap openflow_wildcard_entry;
	nf2_of_entry_wrap openflow_wildcard_mask;
	nf2_of_action_wrap openflow_wildcard_actions;

	//	readReg(&nf2, UNET_ID, &val);
	//	printf("Board ID: Version %i, Device %i\n", GET_VERSION(val), GET_DEVICE(val));
	readReg(&nf2, MAC_GRP_0_CONTROL_REG, &val);
	printf("MAC 0 Control: 0x%08x ", val);
	if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("TX disabled, ");
	}
	else {
	  printf("TX enabled,  ");
	}
	if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("RX disabled, ");
	}
	else {
	  printf("RX enabled,  ");
	}
	if(val&(1<<RESET_MAC_BIT_NUM)) {
	  printf("reset on\n");
	}
	else {
	  printf("reset off\n");
	}
	printf("mac config 0x%02x\n", val>>MAC_DISABLE_TX_BIT_NUM);

	readReg(&nf2, RX_QUEUE_0_NUM_PKTS_STORED_REG, &val);
	printf("Num pkts enqueued to rx queue 0:      %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_PKTS_DROPPED_FULL_REG, &val);
	printf("Num pkts dropped (rx queue 0 full): %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_PKTS_DROPPED_BAD_REG, &val);
	printf("Num pkts dropped (bad fcs q 0):     %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of rx queue 0: %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of rx queue 0: %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_PKTS_DEQUEUED_REG, &val);
	printf("Num pkts dequeued from rx queue 0: %u\n", val);
	readReg(&nf2, RX_QUEUE_0_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in rx queue 0: %u\n\n", val);

	readReg(&nf2, TX_QUEUE_0_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in tx queue 0:             %u\n", val);
	readReg(&nf2, TX_QUEUE_0_NUM_PKTS_SENT_REG, &val);
	printf("Num pkts dequeued from tx queue 0:           %u\n", val);
	readReg(&nf2, TX_QUEUE_0_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of tx queue 0: %u\n", val);
	readReg(&nf2, TX_QUEUE_0_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of tx queue 0: %u\n", val);
	readReg(&nf2, TX_QUEUE_0_NUM_PKTS_ENQUEUED_REG, &val);
	printf("Num pkts enqueued to tx queue 0: %u\n\n", val);

	readReg(&nf2, MAC_GRP_1_CONTROL_REG, &val);
	printf("MAC 1 Control: 0x%08x ", val);
	if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("TX disabled, ");
	}
	else {
	  printf("TX enabled,  ");
	}
	if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("RX disabled, ");
	}
	else {
	  printf("RX enabled,  ");
	}
	if(val&(1<<RESET_MAC_BIT_NUM)) {
	  printf("reset on\n");
	}
	else {
	  printf("reset off\n");
	}
	printf("mac config 0x%02x\n", val>>MAC_DISABLE_TX_BIT_NUM);
	readReg(&nf2, RX_QUEUE_1_NUM_PKTS_STORED_REG, &val);
	printf("Num pkts enqueued to rx queue 1:      %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_PKTS_DROPPED_FULL_REG, &val);
	printf("Num pkts dropped (rx queue 1 full): %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_PKTS_DROPPED_BAD_REG, &val);
	printf("Num pkts dropped (bad fcs q 1):     %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of rx queue 1: %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of rx queue 1: %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_PKTS_DEQUEUED_REG, &val);
	printf("Num pkts dequeued from rx queue 1: %u\n", val);
	readReg(&nf2, RX_QUEUE_1_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in rx queue 1: %u\n\n", val);

	readReg(&nf2, TX_QUEUE_1_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in tx queue 1:             %u\n", val);
	readReg(&nf2, TX_QUEUE_1_NUM_PKTS_SENT_REG, &val);
	printf("Num pkts dequeued from tx queue 1:           %u\n", val);
	readReg(&nf2, TX_QUEUE_1_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of tx queue 1: %u\n", val);
	readReg(&nf2, TX_QUEUE_1_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of tx queue 1: %u\n", val);
        readReg(&nf2, TX_QUEUE_1_NUM_PKTS_ENQUEUED_REG, &val);
        printf("Num pkts enqueued to tx queue 1: %u\n\n", val);

	readReg(&nf2, MAC_GRP_2_CONTROL_REG, &val);
	printf("MAC 2 Control: 0x%08x ", val);
	if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("TX disabled, ");
	}
	else {
	  printf("TX enabled,  ");
	}
	if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("RX disabled, ");
	}
	else {
	  printf("RX enabled,  ");
	}
	if(val&(1<<RESET_MAC_BIT_NUM)) {
	  printf("reset on\n");
	}
	else {
	  printf("reset off\n");
	}
	printf("mac config 0x%02x\n", val>>MAC_DISABLE_TX_BIT_NUM);
	readReg(&nf2, RX_QUEUE_2_NUM_PKTS_STORED_REG, &val);
	printf("Num pkts enqueued to rx queue 2:      %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_PKTS_DROPPED_FULL_REG, &val);
	printf("Num pkts dropped (rx queue 2 full): %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_PKTS_DROPPED_BAD_REG, &val);
	printf("Num pkts dropped (bad fcs q 2):     %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of rx queue 2: %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of rx queue 2: %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_PKTS_DEQUEUED_REG, &val);
	printf("Num pkts dequeued from rx queue 2: %u\n", val);
	readReg(&nf2, RX_QUEUE_2_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in rx queue 2: %u\n\n", val);

	readReg(&nf2, TX_QUEUE_2_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in tx queue 2:             %u\n", val);
	readReg(&nf2, TX_QUEUE_2_NUM_PKTS_SENT_REG, &val);
	printf("Num pkts dequeued from tx queue 2:           %u\n", val);
	readReg(&nf2, TX_QUEUE_2_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of tx queue 2: %u\n", val);
	readReg(&nf2, TX_QUEUE_2_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of tx queue 2: %u\n", val);
        readReg(&nf2, TX_QUEUE_2_NUM_PKTS_ENQUEUED_REG, &val);
        printf("Num pkts enqueued to tx queue 2: %u\n\n", val);

	readReg(&nf2, MAC_GRP_3_CONTROL_REG, &val);
	printf("MAC 3 Control: 0x%08x ", val);
	if(val&(1<<TX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("TX disabled, ");
	}
	else {
	  printf("TX enabled,  ");
	}
	if(val&(1<<RX_QUEUE_DISABLE_BIT_NUM)) {
	  printf("RX disabled, ");
	}
	else {
	  printf("RX enabled,  ");
	}
	if(val&(1<<RESET_MAC_BIT_NUM)) {
	  printf("reset on\n");
	}
	else {
	  printf("reset off\n");
	}
        printf("mac config 0x%02x\n", val>>MAC_DISABLE_TX_BIT_NUM);
	readReg(&nf2, RX_QUEUE_3_NUM_PKTS_STORED_REG, &val);
	printf("Num pkts enqueued to rx queue 3:      %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_PKTS_DROPPED_FULL_REG, &val);
	printf("Num pkts dropped (rx queue 3 full): %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_PKTS_DROPPED_BAD_REG, &val);
	printf("Num pkts dropped (bad fcs q 3):     %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of rx queue 3: %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of rx queue 3: %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_PKTS_DEQUEUED_REG, &val);
	printf("Num pkts dequeued from rx queue 3: %u\n", val);
	readReg(&nf2, RX_QUEUE_3_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in rx queue 3: %u\n\n", val);

	readReg(&nf2, TX_QUEUE_3_NUM_PKTS_IN_QUEUE_REG, &val);
	printf("Num pkts in tx queue 3:             %u\n", val);
	readReg(&nf2, TX_QUEUE_3_NUM_PKTS_SENT_REG, &val);
	printf("Num pkts dequeued from tx queue 3:           %u\n", val);
	readReg(&nf2, TX_QUEUE_3_NUM_WORDS_PUSHED_REG, &val);
	printf("Num words pushed out of tx queue 3: %u\n", val);
	readReg(&nf2, TX_QUEUE_3_NUM_BYTES_PUSHED_REG, &val);
	printf("Num bytes pushed out of tx queue 3: %u\n", val);
        readReg(&nf2, TX_QUEUE_3_NUM_PKTS_ENQUEUED_REG, &val);
        printf("Num pkts enqueued to tx queue 3: %u\n\n", val);

	readReg(&nf2, CPU_REG_Q_0_WR_DATA_WORD_REG, &val);
	printf("CPU_REG_Q_0_WR_DATA_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_0_WR_CTRL_WORD_REG, &val);
	printf("CPU_REG_Q_0_WR_CTRL_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_0_WR_NUM_WORDS_LEFT_REG, &val);
	printf("CPU_REG_Q_0_WR_NUM_WORDS_LEFT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_WR_NUM_PKTS_IN_Q_REG, &val);
	printf("CPU_REG_Q_0_WR_NUM_PKTS_IN_Q_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_RD_DATA_WORD_REG, &val);
	printf("CPU_REG_Q_0_RD_DATA_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_0_RD_CTRL_WORD_REG, &val);
	printf("CPU_REG_Q_0_RD_CTRL_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_0_RD_NUM_WORDS_AVAIL_REG, &val);
	printf("CPU_REG_Q_0_RD_NUM_WORDS_AVAIL_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_RD_NUM_PKTS_IN_Q_REG, &val);
	printf("CPU_REG_Q_0_RD_NUM_PKTS_IN_Q_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_RX_NUM_PKTS_RCVD_REG, &val);
	printf("CPU_REG_Q_0_RX_NUM_PKTS_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_TX_NUM_PKTS_SENT_REG, &val);
	printf("CPU_REG_Q_0_TX_NUM_PKTS_SENT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_RX_NUM_WORDS_RCVD_REG, &val);
	printf("CPU_REG_Q_0_RX_NUM_WORDS_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_TX_NUM_WORDS_SENT_REG, &val);
	printf("CPU_REG_Q_0_TX_NUM_WORDS_SENT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_RX_NUM_BYTES_RCVD_REG, &val);
	printf("CPU_REG_Q_0_RX_NUM_BYTES_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_0_TX_NUM_BYTES_SENT_REG, &val);
	printf("CPU_REG_Q_0_TX_NUM_BYTES_SENT_REG: %u\n\n", val);

	readReg(&nf2, CPU_REG_Q_1_WR_DATA_WORD_REG, &val);
	printf("CPU_REG_Q_1_WR_DATA_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_1_WR_CTRL_WORD_REG, &val);
	printf("CPU_REG_Q_1_WR_CTRL_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_1_WR_NUM_WORDS_LEFT_REG, &val);
	printf("CPU_REG_Q_1_WR_NUM_WORDS_LEFT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_WR_NUM_PKTS_IN_Q_REG, &val);
	printf("CPU_REG_Q_1_WR_NUM_PKTS_IN_Q_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_RD_DATA_WORD_REG, &val);
	printf("CPU_REG_Q_1_RD_DATA_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_1_RD_CTRL_WORD_REG, &val);
	printf("CPU_REG_Q_1_RD_CTRL_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_1_RD_NUM_WORDS_AVAIL_REG, &val);
	printf("CPU_REG_Q_1_RD_NUM_WORDS_AVAIL_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_RD_NUM_PKTS_IN_Q_REG, &val);
	printf("CPU_REG_Q_1_RD_NUM_PKTS_IN_Q_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_RX_NUM_PKTS_RCVD_REG, &val);
	printf("CPU_REG_Q_1_RX_NUM_PKTS_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_TX_NUM_PKTS_SENT_REG, &val);
	printf("CPU_REG_Q_1_TX_NUM_PKTS_SENT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_RX_NUM_WORDS_RCVD_REG, &val);
	printf("CPU_REG_Q_1_RX_NUM_WORDS_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_TX_NUM_WORDS_SENT_REG, &val);
	printf("CPU_REG_Q_1_TX_NUM_WORDS_SENT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_RX_NUM_BYTES_RCVD_REG, &val);
	printf("CPU_REG_Q_1_RX_NUM_BYTES_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_1_TX_NUM_BYTES_SENT_REG, &val);
	printf("CPU_REG_Q_1_TX_NUM_BYTES_SENT_REG: %u\n\n", val);

	readReg(&nf2, CPU_REG_Q_2_WR_DATA_WORD_REG, &val);
	printf("CPU_REG_Q_2_WR_DATA_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_2_WR_CTRL_WORD_REG, &val);
	printf("CPU_REG_Q_2_WR_CTRL_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_2_WR_NUM_WORDS_LEFT_REG, &val);
	printf("CPU_REG_Q_2_WR_NUM_WORDS_LEFT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_WR_NUM_PKTS_IN_Q_REG, &val);
	printf("CPU_REG_Q_2_WR_NUM_PKTS_IN_Q_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_RD_DATA_WORD_REG, &val);
	printf("CPU_REG_Q_2_RD_DATA_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_2_RD_CTRL_WORD_REG, &val);
	printf("CPU_REG_Q_2_RD_CTRL_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_2_RD_NUM_WORDS_AVAIL_REG, &val);
	printf("CPU_REG_Q_2_RD_NUM_WORDS_AVAIL_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_RD_NUM_PKTS_IN_Q_REG, &val);
	printf("CPU_REG_Q_2_RD_NUM_PKTS_IN_Q_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_RX_NUM_PKTS_RCVD_REG, &val);
	printf("CPU_REG_Q_2_RX_NUM_PKTS_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_TX_NUM_PKTS_SENT_REG, &val);
	printf("CPU_REG_Q_2_TX_NUM_PKTS_SENT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_RX_NUM_WORDS_RCVD_REG, &val);
	printf("CPU_REG_Q_2_RX_NUM_WORDS_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_TX_NUM_WORDS_SENT_REG, &val);
	printf("CPU_REG_Q_2_TX_NUM_WORDS_SENT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_RX_NUM_BYTES_RCVD_REG, &val);
	printf("CPU_REG_Q_2_RX_NUM_BYTES_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_2_TX_NUM_BYTES_SENT_REG, &val);
	printf("CPU_REG_Q_2_TX_NUM_BYTES_SENT_REG: %u\n\n", val);

	readReg(&nf2, CPU_REG_Q_3_WR_DATA_WORD_REG, &val);
	printf("CPU_REG_Q_3_WR_DATA_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_3_WR_CTRL_WORD_REG, &val);
	printf("CPU_REG_Q_3_WR_CTRL_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_3_WR_NUM_WORDS_LEFT_REG, &val);
	printf("CPU_REG_Q_3_WR_NUM_WORDS_LEFT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_WR_NUM_PKTS_IN_Q_REG, &val);
	printf("CPU_REG_Q_3_WR_NUM_PKTS_IN_Q_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_RD_DATA_WORD_REG, &val);
	printf("CPU_REG_Q_3_RD_DATA_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_3_RD_CTRL_WORD_REG, &val);
	printf("CPU_REG_Q_3_RD_CTRL_WORD_REG: 0x%08x\n", val);
	readReg(&nf2, CPU_REG_Q_3_RD_NUM_WORDS_AVAIL_REG, &val);
	printf("CPU_REG_Q_3_RD_NUM_WORDS_AVAIL_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_RD_NUM_PKTS_IN_Q_REG, &val);
	printf("CPU_REG_Q_3_RD_NUM_PKTS_IN_Q_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_RX_NUM_PKTS_RCVD_REG, &val);
	printf("CPU_REG_Q_3_RX_NUM_PKTS_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_TX_NUM_PKTS_SENT_REG, &val);
	printf("CPU_REG_Q_3_TX_NUM_PKTS_SENT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_RX_NUM_WORDS_RCVD_REG, &val);
	printf("CPU_REG_Q_3_RX_NUM_WORDS_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_TX_NUM_WORDS_SENT_REG, &val);
	printf("CPU_REG_Q_3_TX_NUM_WORDS_SENT_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_RX_NUM_BYTES_RCVD_REG, &val);
	printf("CPU_REG_Q_3_RX_NUM_BYTES_RCVD_REG: %u\n", val);
	readReg(&nf2, CPU_REG_Q_3_TX_NUM_BYTES_SENT_REG, &val);
	printf("CPU_REG_Q_3_TX_NUM_BYTES_SENT_REG: %u\n\n", val);

	readReg(&nf2, IN_ARB_NUM_PKTS_SENT_REG, &val);
	printf("IN_ARB_NUM_PKTS_SENT_REG                  %u\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_WORD_0_LO_REG, &val);
	printf("IN_ARB_LAST_PKT_WORD_0_LO_REG             0x%08x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_WORD_0_HI_REG, &val);
	printf("IN_ARB_LAST_PKT_WORD_0_HI_REG             0x%08x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_CTRL_0_REG, &val);
	printf("IN_ARB_LAST_PKT_CTRL_0_REG                0x%02x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_WORD_1_LO_REG, &val);
	printf("IN_ARB_LAST_PKT_WORD_1_LO_REG             0x%08x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_WORD_1_HI_REG, &val);
	printf("IN_ARB_LAST_PKT_WORD_1_HI_REG             0x%08x\n", val);
	readReg(&nf2, IN_ARB_LAST_PKT_CTRL_1_REG, &val);
	printf("IN_ARB_LAST_PKT_CTRL_1_REG                0x%02x\n", val);
	readReg(&nf2, IN_ARB_STATE_REG, &val);
	printf("IN_ARB_STATE_REG                          %u\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_0, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_0                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_0, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_0             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_0, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_0        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_0, &val);
	printf("OQ_NUM_PKTS_STORED_REG_0                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_0, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_0                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_0, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_0            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_0, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_0       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_0, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_0                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_0, &val);
	printf("OQ_ADDRESS_HI_REG_0                       0x%08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_0, &val);
	printf("OQ_ADDRESS_LO_REG_0                       0x%08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_0, &val);
	printf("OQ_WR_ADDRESS_REG_0                       0x%08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_0, &val);
	printf("OQ_RD_ADDRESS_REG_0                       0x%08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_0, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_0                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_0, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_0                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_0, &val);
	printf("OQ_CONTROL_REG_0                          0x%08x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_1, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_1                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_1, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_1             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_1, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_1        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_1, &val);
	printf("OQ_NUM_PKTS_STORED_REG_1                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_1, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_1                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_1, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_1            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_1, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_1       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_1, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_1                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_1, &val);
	printf("OQ_ADDRESS_HI_REG_1                       0x%08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_1, &val);
	printf("OQ_ADDRESS_LO_REG_1                       0x%08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_1, &val);
	printf("OQ_WR_ADDRESS_REG_1                       0x%08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_1, &val);
	printf("OQ_RD_ADDRESS_REG_1                       0x%08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_1, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_1                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_1, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_1                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_1, &val);
	printf("OQ_CONTROL_REG_1                          0x%08x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_2, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_2                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_2, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_2             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_2, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_2        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_2, &val);
	printf("OQ_NUM_PKTS_STORED_REG_2                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_2, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_2                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_2, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_2            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_2, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_2       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_2, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_2                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_2, &val);
	printf("OQ_ADDRESS_HI_REG_2                       0x%08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_2, &val);
	printf("OQ_ADDRESS_LO_REG_2                       0x%08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_2, &val);
	printf("OQ_WR_ADDRESS_REG_2                       0x%08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_2, &val);
	printf("OQ_RD_ADDRESS_REG_2                       0x%08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_2, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_2                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_2, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_2                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_2, &val);
	printf("OQ_CONTROL_REG_2                          0x%08x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_3, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_3                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_3, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_3             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_3, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_3        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_3, &val);
	printf("OQ_NUM_PKTS_STORED_REG_3                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_3, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_3                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_3, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_3            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_3, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_3       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_3, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_3                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_3, &val);
	printf("OQ_ADDRESS_HI_REG_3                       0x%08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_3, &val);
	printf("OQ_ADDRESS_LO_REG_3                       0x%08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_3, &val);
	printf("OQ_WR_ADDRESS_REG_3                       0x%08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_3, &val);
	printf("OQ_RD_ADDRESS_REG_3                       0x%08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_3, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_3                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_3, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_3                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_3, &val);
	printf("OQ_CONTROL_REG_3                          0x%08x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_4, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_4                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_4, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_4             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_4, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_4        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_4, &val);
	printf("OQ_NUM_PKTS_STORED_REG_4                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_4, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_4                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_4, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_4            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_4, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_4       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_4, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_4                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_4, &val);
	printf("OQ_ADDRESS_HI_REG_4                       0x%08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_4, &val);
	printf("OQ_ADDRESS_LO_REG_4                       0x%08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_4, &val);
	printf("OQ_WR_ADDRESS_REG_4                       0x%08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_4, &val);
	printf("OQ_RD_ADDRESS_REG_4                       0x%08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_4, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_4                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_4, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_4                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_4, &val);
	printf("OQ_CONTROL_REG_4                          0x%08x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_5, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_5                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_5, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_5             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_5, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_5        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_5, &val);
	printf("OQ_NUM_PKTS_STORED_REG_5                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_5, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_5                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_5, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_5            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_5, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_5       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_5, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_5                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_5, &val);
	printf("OQ_ADDRESS_HI_REG_5                       0x%08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_5, &val);
	printf("OQ_ADDRESS_LO_REG_5                       0x%08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_5, &val);
	printf("OQ_WR_ADDRESS_REG_5                       0x%08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_5, &val);
	printf("OQ_RD_ADDRESS_REG_5                       0x%08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_5, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_5                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_5, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_5                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_5, &val);
	printf("OQ_CONTROL_REG_5                          0x%08x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_6, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_6                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_6, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_6             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_6, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_6        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_6, &val);
	printf("OQ_NUM_PKTS_STORED_REG_6                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_6, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_6                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_6, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_6            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_6, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_6       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_6, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_6                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_6, &val);
	printf("OQ_ADDRESS_HI_REG_6                       0x%08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_6, &val);
	printf("OQ_ADDRESS_LO_REG_6                       0x%08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_6, &val);
	printf("OQ_WR_ADDRESS_REG_6                       0x%08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_6, &val);
	printf("OQ_RD_ADDRESS_REG_6                       0x%08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_6, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_6                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_6, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_6                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_6, &val);
	printf("OQ_CONTROL_REG_6                          0x%08x\n\n", val);

	readReg(&nf2, OQ_NUM_WORDS_LEFT_REG_7, &val);
	printf("OQ_NUM_WORDS_LEFT_REG_7                   %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_STORED_REG_7, &val);
	printf("OQ_NUM_PKT_BYTES_STORED_REG_7             %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_STORED_REG_7, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_STORED_REG_7        %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_STORED_REG_7, &val);
	printf("OQ_NUM_PKTS_STORED_REG_7                  %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_DROPPED_REG_7, &val);
	printf("OQ_NUM_PKTS_DROPPED_REG_7                 %u\n", val);
	readReg(&nf2, OQ_NUM_PKT_BYTES_REMOVED_REG_7, &val);
	printf("OQ_NUM_PKT_BYTES_REMOVED_REG_7            %u\n", val);
	readReg(&nf2, OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_7, &val);
	printf("OQ_NUM_OVERHEAD_BYTES_REMOVED_REG_7       %u\n", val);
	readReg(&nf2, OQ_NUM_PKTS_REMOVED_REG_7, &val);
	printf("OQ_NUM_PKTS_REMOVED_REG_7                 %u\n", val);
	readReg(&nf2, OQ_ADDRESS_HI_REG_7, &val);
	printf("OQ_ADDRESS_HI_REG_7                       0x%08x\n", val);
	readReg(&nf2, OQ_ADDRESS_LO_REG_7, &val);
	printf("OQ_ADDRESS_LO_REG_7                       0x%08x\n", val);
	readReg(&nf2, OQ_WR_ADDRESS_REG_7, &val);
	printf("OQ_WR_ADDRESS_REG_7                       0x%08x\n", val);
	readReg(&nf2, OQ_RD_ADDRESS_REG_7, &val);
	printf("OQ_RD_ADDRESS_REG_7                       0x%08x\n", val);
	readReg(&nf2, OQ_NUM_PKTS_IN_Q_REG_7, &val);
	printf("OQ_NUM_PKTS_IN_Q_REG_7                    %u\n", val);
	readReg(&nf2, OQ_MAX_PKTS_IN_Q_REG_7, &val);
	printf("OQ_MAX_PKTS_IN_Q_REG_7                    %u\n", val);
	readReg(&nf2, OQ_CONTROL_REG_7, &val);
	printf("OQ_CONTROL_REG_7                          0x%08x\n\n", val);

	readReg(&nf2, OQ_FULL_THRESH_REG_0, &val);
	printf("OQ_FULL_THRESH_REG_0                      %u\n",val);
	readReg(&nf2, OQ_FULL_THRESH_REG_1, &val);
	printf("OQ_FULL_THRESH_REG_1                      %u\n",val);
	readReg(&nf2, OQ_FULL_THRESH_REG_2, &val);
	printf("OQ_FULL_THRESH_REG_2                      %u\n",val);
	readReg(&nf2, OQ_FULL_THRESH_REG_3, &val);
	printf("OQ_FULL_THRESH_REG_3                      %u\n",val);
	readReg(&nf2, OQ_FULL_THRESH_REG_4, &val);
	printf("OQ_FULL_THRESH_REG_4                      %u\n",val);
	readReg(&nf2, OQ_FULL_THRESH_REG_5, &val);
	printf("OQ_FULL_THRESH_REG_5                      %u\n",val);
	readReg(&nf2, OQ_FULL_THRESH_REG_6, &val);
	printf("OQ_FULL_THRESH_REG_6                      %u\n",val);
	readReg(&nf2, OQ_FULL_THRESH_REG_7, &val);
	printf("OQ_FULL_THRESH_REG_7                      %u\n\n",val);

	readReg(&nf2, DELAY_ENABLE_REG, &val);
	printf("DELAY_ENABLE_REG                          0x%08x\n",val);
	readReg(&nf2, DELAY_1ST_WORD_HI_REG, &val);
	printf("DELAY_1ST_WORD_HI_REG                     0x%08x\n",val);
	readReg(&nf2, DELAY_1ST_WORD_LO_REG, &val);
	printf("DELAY_1ST_WORD_LO_REG                     0x%08x\n",val);
	readReg(&nf2, DELAY_LENGTH_REG, &val);
	printf("DELAY_LENGTH_REG                          0x%08x\n\n",val);

	readReg(&nf2, RATE_LIMIT_ENABLE_REG, &val);
	printf("RATE_LIMIT_ENABLE_REG                     0x%08x\n",val);
	readReg(&nf2, RATE_LIMIT_SHIFT_REG, &val);
	printf("RATE_LIMIT_SHIFT_REG                      0x%08x\n\n",val);

	readReg(&nf2, OPENFLOW_WILDCARD_TABLE_SIZE, &val);
	printf("OPENFLOW_WILDCARD_TABLE_SIZE              0x%08x\n",val);
	readReg(&nf2, OPENFLOW_WILDCARD_NUM_DATA_WORDS_USED, &val);
	printf("OPENFLOW_WILDCARD_NUM_DATA_WORDS_USED     0x%08x\n",val);
	readReg(&nf2, OPENFLOW_WILDCARD_NUM_CMP_WORDS_USED, &val);
	printf("OPENFLOW_WILDCARD_CMP_WORDS_USED          0x%08x\n\n",val);

	readReg(&nf2, OPENFLOW_LOOKUP_WILDCARD_MISSES_REG, &val);
	printf("OPENFLOW_LOOKUP_WILDCARD_MISSES_REG       0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_WILDCARD_HITS_REG, &val);
	printf("OPENFLOW_LOOKUP_WILDCARD_HITS_REG         0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_EXACT_MISSES_REG, &val);
	printf("OPENFLOW_LOOKUP_EXACT_MISSES_REG          0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_EXACT_HITS_REG, &val);
	printf("OPENFLOW_LOOKUP_EXACT_HITS_REG            0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_0_REG, &val);
	printf("OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_0_REG    0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_1_REG, &val);
	printf("OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_1_REG    0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_2_REG, &val);
	printf("OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_2_REG    0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_3_REG, &val);
	printf("OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_3_REG    0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_4_REG, &val);
	printf("OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_4_REG    0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_5_REG, &val);
	printf("OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_5_REG    0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_6_REG, &val);
	printf("OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_6_REG    0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_7_REG, &val);
	printf("OPENFLOW_LOOKUP_NUM_PKTS_DROPPED_7_REG    0x%08x\n",val);
	readReg(&nf2, OPENFLOW_WILDCARD_NUM_DATA_WORDS_USED, &val);
	printf("OPENFLOW_WILDCARD_NUM_DATA_WORDS_USED     0x%08x\n",val);
	readReg(&nf2, OPENFLOW_LOOKUP_TIMER_REG, &val);
	printf("OPENFLOW_LOOKUP_TIMER_REG                 0x%08x\n\n",val);

	printf("#  tr_d tr_s pr ip_dst          ip_src          type eth_dst      eth_src      sp vlan\n");
	for(i=0; i<OPENFLOW_WILDCARD_TABLE_SIZE; i=i+1){
	  
	  
	  //Read the Header data from the table
	  read_openflow_wildcard_table(i, &entry_not_zero, &openflow_wildcard_entry, &openflow_wildcard_mask,
				       &openflow_wildcard_actions);

	  if (entry_not_zero == 1) 
	  {
	    printf("%02u", i);
	    //Print the entry
	    print_openflow_table(openflow_wildcard_entry, openflow_wildcard_mask,
				 openflow_wildcard_actions);
	  }
	}
	printf("\n");	
}

//
// printMAC: print a MAC address as a : separated value. eg:
//    00:11:22:33:44:55
//
void printMAC(unsigned char* mac)
{
  int j;

  for(j = 0; j < 6; ++j) {
    printf("%02x", mac[j]);
  }
}


//
// printIP: print an IP address in dotted notation. eg: 192.168.0.1
//
void printIP(unsigned ip)
{
	printf("%03u.%03u.%03u.%03u", 
			((ip>>24)&0xff), ((ip>>16)&0xff), ((ip>>8)&0xff), ((ip>>0)&0xff)
		);
}

void write_openflow_wildcard_table(int index, nf2_of_entry_wrap *wildcard, nf2_of_entry_wrap *wildcard_mask, 
				    nf2_of_action_wrap *wildcard_actions)
{
  int j;
  
  //Write the Header data from the table
  for(j=0; j<OPENFLOW_WILDCARD_NUM_CMP_WORDS_USED; j=j+1){
    writeReg(&nf2, OPENFLOW_WILDCARD_LOOKUP_CMP_BASE_REG + j * 4, wildcard->raw[j]);
    //writeReg(&nf2, OPENFLOW_WILDCARD_LOOKUP_CMP_MASK_BASE_REG + j * 4, &wildcard_mask->raw[j]);	    
  }
    
  //Write the Action data from the table
  for (j=0; j<OPENFLOW_WILDCARD_NUM_CMP_WORDS_USED; j=j+1){
    writeReg(&nf2, OPENFLOW_WILDCARD_LOOKUP_ACTION_BASE_REG + j * 4, wildcard_actions->raw[j]);
  }

  writeReg(&nf2, OPENFLOW_WILDCARD_LOOKUP_WRITE_ADDR_REG, index);   
}

void read_openflow_wildcard_table(int index, int *entry_not_zero, nf2_of_entry_wrap *wildcard, nf2_of_entry_wrap *wildcard_mask, 
				    nf2_of_action_wrap *wildcard_actions)
{
  int j;
  
  *entry_not_zero = 0;
  
  writeReg(&nf2, OPENFLOW_WILDCARD_LOOKUP_READ_ADDR_REG, index);

  //Read the Header data from the table
  for(j=0; j<OPENFLOW_WILDCARD_NUM_CMP_WORDS_USED; j=j+1)
    {
      readReg(&nf2, OPENFLOW_WILDCARD_LOOKUP_CMP_BASE_REG + j * 4, &wildcard->raw[j]);
      if (wildcard->raw[j] != 0) 
	*entry_not_zero = 1;
      readReg(&nf2, OPENFLOW_WILDCARD_LOOKUP_CMP_MASK_BASE_REG + j * 4, &wildcard_mask->raw[j]);
      if (wildcard_mask->raw[j] != 0)
	*entry_not_zero = 1;
    }
  
  //Read the Action data from the table
  for (j=0; j<OPENFLOW_WILDCARD_NUM_CMP_WORDS_USED; j=j+1)
    {
      readReg(&nf2, OPENFLOW_WILDCARD_LOOKUP_ACTION_BASE_REG + j * 4, &wildcard_actions->raw[j]);
      if (wildcard_actions->raw[j] != 0)
	*entry_not_zero = 1;
    }   
}

void print_openflow_table(nf2_of_entry_wrap wildcard, nf2_of_entry_wrap wildcard_mask, 
			   nf2_of_action_wrap wildcard_actions)
{
  int j;
  
  printf(" %04x %04x", wildcard.entry.transp_dst, wildcard.entry.transp_src);
  printf(" %02x ",wildcard.entry.ip_proto); //%08x  %08x",  wildcard.entry.ip_proto,  
	// wildcard.entry.ip_dst,  wildcard.entry.ip_src);
	printIP(wildcard.entry.ip_dst);
	printf(" ");
	printIP(wildcard.entry.ip_src);
  printf(" %04x ", wildcard.entry.eth_type);
  printMAC(wildcard.entry.eth_dst);
  printf(" ");
  printMAC(wildcard.entry.eth_src);

  printf(" %02x %04x\n",  wildcard.entry.src_port,  
	 wildcard.entry.vlan_id);

  //print mask 
  printf("   %04x %04x", wildcard_mask.entry.transp_dst, wildcard_mask.entry.transp_src);
  printf(" %02x ",wildcard_mask.entry.ip_proto); //%08x  %08x",  wildcard_mask.entry.ip_proto,  
	// wildcard_mask.entry.ip_dst,  wildcard_mask.entry.ip_src);
	printIP(wildcard_mask.entry.ip_dst);
	printf(" ");
	printIP(wildcard_mask.entry.ip_src);
  printf(" %04x ", wildcard_mask.entry.eth_type);
  printMAC(wildcard_mask.entry.eth_dst);
  printf(" ");
  printMAC(wildcard_mask.entry.eth_src);


  printf(" %02x %04x\n",  wildcard_mask.entry.src_port,  
	 wildcard_mask.entry.vlan_id);
  //-- old print
  //Print the Header 
/*   printf("     transp_dst 0x%04x transp_src 0x%04x\n", wildcard.entry.transp_dst,  */
/* 	 wildcard.entry.transp_src); */
/*   printf("     ip_proto   0x%02x   ip_dst     0x%08x ip_src  0x%08x\n",  wildcard.entry.ip_proto,   */
/* 	 wildcard.entry.ip_dst,  wildcard.entry.ip_src); */
/*   printf("     eth_type   0x%04x eth_dst    0x%02x eth_src 0x%02x\n",  wildcard.entry.eth_type,   */
/* 	 wildcard.entry.eth_dst,  wildcard.entry.eth_src); */
/*   printf("     src_port   0x%02x   vlan_id    0x%04x\n\n",  wildcard.entry.src_port,   */
/* 	 wildcard.entry.vlan_id); */
  
  //Print the Actions
  printf("   ");
  for(j=0; j<8; ++j) {
    printf("%i", ((*((char*)wildcard_actions.raw)) >> j) & 0x1);
  }
  printf(" ");
  for (j=0; j<OPENFLOW_WILDCARD_NUM_CMP_WORDS_USED; j=j+1){
    printf("%08x", wildcard_actions.raw[j]);
  }
  printf("\n\n");
}

