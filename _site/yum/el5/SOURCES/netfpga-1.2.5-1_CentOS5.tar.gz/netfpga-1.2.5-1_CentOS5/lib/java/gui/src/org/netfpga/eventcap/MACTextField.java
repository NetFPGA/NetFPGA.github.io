package org.netfpga.eventcap;
import javax.swing.JTextField;

public class MACTextField extends JTextField {

}
