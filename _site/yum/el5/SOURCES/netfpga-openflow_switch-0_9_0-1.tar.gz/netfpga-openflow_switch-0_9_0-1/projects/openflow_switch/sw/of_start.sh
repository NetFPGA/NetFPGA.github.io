#!/bin/bash

# Execute this shell on your home directory as a super user

# 1. Download OpenFlow bitfile.
# 2. Insert OpenFlow kernel module and NetFPGA kernel module
# 3. Setup datapath and interface

nf2_download openflow-git/datapath/hwtable_nf2/openflow_switch.bit

# If you want to activate link status checking, use following:
#nf2_download -r openflow-git/datapath/hwtable_nf2/openflow_switch.bit

/sbin/insmod openflow-git/datapath/linux-2.6/ofdatapath.ko
/sbin/insmod openflow-git/datapath/linux-2.6/ofdatapath_netfpga.ko
openflow-git/utilities/dpctl adddp nl:0
openflow-git/utilities/dpctl addif nl:0 nf2c0
openflow-git/utilities/dpctl addif nl:0 nf2c1
openflow-git/utilities/dpctl addif nl:0 nf2c2
openflow-git/utilities/dpctl addif nl:0 nf2c3
openflow-git/utilities/dpctl show nl:0

openflow-git/secchan/ofprotocol nl:0 tcp:$1 --out-of-band
