#!/bin/bash

# Execute this shell as a super user on your home directory

# 1. Tear down interface and datapath
# 2. Remove NetFPGA kernel module and OpenFlow kernel module

#killall ofprotocol
openflow-git/utilities/dpctl delif nl:0 nf2c0
openflow-git/utilities/dpctl delif nl:0 nf2c1
openflow-git/utilities/dpctl delif nl:0 nf2c2
openflow-git/utilities/dpctl delif nl:0 nf2c3
openflow-git/utilities/dpctl deldp nl:0
/sbin/rmmod ofdatapath_netfpga
/sbin/rmmod ofdatapath

