#!/usr/local/bin/perl -w
# make_pkts.pl
#
#
# 

$delay = '@12us';
$batch = 0;

use NF2::PacketGen;
use NF2::PacketLib;
#use CPCI_21Lib;
use SimLib;
#use NF21RouterLib;

use OpenFlowLib;
use NFUtils::SimplePacket;
use NFOpenFlowTester;

use reg_defines_openflow_switch;

nf_set_environment( { PORT_MODE => 'PHYSICAL', MAX_PORTS => 4 } );
nf_add_port_rule(1, 'UNORDERED');
nf_add_port_rule(2, 'UNORDERED');
nf_add_port_rule(3, 'UNORDERED');
nf_add_port_rule(4, 'UNORDERED');

# use strict AFTER the $delay, $batch and %reg are declared
use strict;
use vars qw($delay $batch %reg);

#my %cpci_regs = CPCI_21Lib::get_register_addresses();

# write 0 to CPCI_INTERRUPT_MASK_REG()
#nf_PCI_write32(0, $batch, CPCI_INTERRUPT_MASK_REG(), 0);

# Prepare the DMA and enable interrupts
prepare_DMA('@3.9us');
enable_interrupts(0);

####################################################################
# Setup the fields
#
my $outports = [0x40, 0x04, 0x10, 0x1];

my $fields =
  {NFUtils::SimplePacket::TRANSP_DST() => [0x1111],
   NFUtils::SimplePacket::TRANSP_SRC() => [0x2222, 0x2332],
   NFUtils::SimplePacket::IP_PROTO() => [NFUtils::SimplePacket::IP_PROTO_UDP],
   NFUtils::SimplePacket::IP_DST() => [0x44444444],
   NFUtils::SimplePacket::IP_SRC() => [NFOpenFlowTester::WILDCARD],
   NFUtils::SimplePacket::IP_OPTS() => [[], [1..12], [1..8]],
   NFUtils::SimplePacket::ETH_TYPE() => [NFUtils::SimplePacket::ETH_TYPE_IP],
   NFUtils::SimplePacket::ETH_DST() => ["88:88:88:88:88:88"],
   NFUtils::SimplePacket::ETH_SRC() => ["77:77:77:77:77:77"],
   NFUtils::SimplePacket::SRC_PORT() => [0, 2, 4, 6],
   NFUtils::SimplePacket::VLAN_TAG() => [0xffff],
   NFUtils::SimplePacket::PKT_TYPE() => [NFUtils::SimplePacket::PKT_TYPE_UDP]};

my $table = OpenFlowTable->new('simulation' => 1);

my $delay_us = 8;
$delay = '@8us';

my $num_iter = 1;
my $num_pkts = 100;
my $num_table_entries = 4;

####################################################################
# execute the simulation
#
$delay_us += NFOpenFlowTester::runRandomSim(NFOpenFlowTester::START_DELAY() => $delay_us,
					    NFOpenFlowTester::NUM_ITERATIONS() => $num_iter,
					    NFOpenFlowTester::NUM_PKTS() => $num_pkts,
					    NFOpenFlowTester::NUM_FLOW_ENTRIES() => $num_table_entries,
					    NFOpenFlowTester::TABLE() => $table,
					    NFOpenFlowTester::FLOW_ENTRY_FIELDS() => $fields,
					    NFOpenFlowTester::PKT_FIELDS() => $fields,
					    NFOpenFlowTester::OUTPUT_PORTS() => $outports);

# *********** Finishing Up - need this in all scripts ! **********************
my $t = nf_write_sim_files();
print  "--- make_pkts.pl: Generated all configuration packets.\n";
printf "--- make_pkts.pl: Last packet enters system at approx %0d microseconds.\n",($t/1000);
if (nf_write_expected_files()) {
  die "Unable to write expected files\n";
}

nf_create_hardware_file('LITTLE_ENDIAN');
nf_write_hardware_file('LITTLE_ENDIAN');


