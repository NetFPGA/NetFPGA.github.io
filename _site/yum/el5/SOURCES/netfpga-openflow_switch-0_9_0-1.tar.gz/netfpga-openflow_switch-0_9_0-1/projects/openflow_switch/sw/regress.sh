#!/bin/bash

# Execute this shell as a super user on your home directory
# You will need a four-port GigE NIC for the test

#nf2_download openflow-git/datapath/hwtable_nf2/openflow_switch.bit
source env_vars
of_nf2_test.pl

