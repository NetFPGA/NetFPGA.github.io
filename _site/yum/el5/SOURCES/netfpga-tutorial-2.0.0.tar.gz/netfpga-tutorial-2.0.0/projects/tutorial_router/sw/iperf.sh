iperf -c 192.168.x.y -t 1000000 -i 1
